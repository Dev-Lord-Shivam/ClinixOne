﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ClinixOne.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountRepository _accountRepository;
        private readonly IConfiguration _configuration;
        public AccountController(IAccountRepository _accountRepository, IConfiguration configuration)
        {
            this._accountRepository = _accountRepository;
            this._configuration = configuration;
        }

        #region Hospital Users
        private async Task<EmployeeDetails> AuthenticateUser(LoginModel account)
        {
            //LoginModel _login = null;
            var checkUser = await _accountRepository.Authenticateuser(account);
            EmployeeDetails details = null;
            if (checkUser != null)
            {
                details = new EmployeeDetails()
                {
                    EmpId = checkUser.EmpId,
                    EmpName = checkUser.EmpName,
                    EmpPhoto = checkUser.EmpPhoto,
                    EmailId = checkUser.EmailId,
                    RoleId = checkUser.RoleId,
                    DeptId = checkUser.DeptId,
                    RoleName = checkUser.RoleName,
                    DeptName = checkUser.DeptName,
                    IsActive = checkUser.IsActive
                };
                //_login = new LoginModel { LoginId = "Admin" };
            }
            return details;
        }

        private string GenerateToken(EmployeeDetails master)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                    new Claim(ClaimTypes.Name, master.EmpId),
                    new Claim("EmpId",master.EmpId),
                    new Claim("EmpName",master.EmpName),
                    new Claim("RoleId",master.RoleId.ToString()),
                    new Claim("DeptId",master.DeptId.ToString()),
                    new Claim("EmailId", master.EmailId),
                    new Claim("role", "Hospital")
                    // You can add more claims as needed.
            };

            //HttpContext.Session.SetString("EmpId", master.EmpId);
            //HttpContext.Session.SetString("RoleId", master.RoleId.ToString());

            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: credentials
            );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Login")]
      //  [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> LogIn([FromBody] LoginModel login)
        {
            IActionResult response = Unauthorized();

            var _user = await AuthenticateUser(login);
            if (_user != null)
            {
                if (_user.IsActive == true)
                {
                    var token = GenerateToken(_user);
                    response = Ok(new 
                    { 
                        token = token,
                        user = _user
                    });
                }
                else
                {
                    response = Unauthorized(new
                    {
                        error_code = "001",
                        error_Msg = "User Is InActive, Please contact admin"
                    });
                }
            }
            else
            {
                response = Unauthorized(new { error_code = "002", error_Msg = "User does not exist, Please contact Admin" });
            }
            return response;
        }
        [HttpPost]
        [Route("Logout")]
        public IActionResult Logout()
        {
            return Ok(new { message = "Logged out successfully" });
        }

        #endregion

        #region Patients

        [AllowAnonymous]
        [HttpPost]
        [Route("PatientLogin")]
        //  [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> PatientLogIn([FromBody] LoginModel login)
        {
            IActionResult response = Unauthorized();

            var _user = await AuthenticatePatient(login);
            if (_user != null)
            {
                if (_user.IsActive == true)
                {
                    var token = GenerateTokenForPatient(_user);
                    response = Ok(new
                    {
                        token = token,
                        user = _user
                    });
                }
                else
                {
                    response = Unauthorized(new
                    {
                        error_code = "001",
                        error_Msg = "User Is InActive"
                    });
                }
            }
            else
            {
                response = Unauthorized(new { error_code = "002", error_Msg = "User does not exist, Please contact Admin" });
            }
            return response;
        }

        private async Task<PatientDetails> AuthenticatePatient(LoginModel account)
        {
            //LoginModel _login = null;
            var checkUser = await _accountRepository.AuthenticatePatients(account);
            PatientDetails details = null;
            if (checkUser != null)
            {
                details = new PatientDetails()
                {
                    PatientId = checkUser.PatientId,
                    FullName = checkUser.FullName,
                    ProfilePic = checkUser.ProfilePic,
                    Email = checkUser.Email,
                    RoleId = checkUser.RoleId,
                    RoleName = checkUser.RoleName,
                    IsActive = checkUser.IsActive
                };
                //_login = new LoginModel { LoginId = "Admin" };
            }
            return details;
        }

        private string GenerateTokenForPatient(PatientDetails master)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                    new Claim(ClaimTypes.Name, master.PatientId),
                    new Claim("PatientId",master.PatientId),
                    new Claim("PatientName",master.FullName),
                    new Claim("role", "Patient")
                    // You can add more claims as needed.
            };

            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: credentials
            );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [HttpPost]
        [Route("Logoutpatient")]
        public IActionResult Logoutpatient()
        {
            return Ok(new { message = "Logged out successfully" });
        }
        #endregion

    }
}
