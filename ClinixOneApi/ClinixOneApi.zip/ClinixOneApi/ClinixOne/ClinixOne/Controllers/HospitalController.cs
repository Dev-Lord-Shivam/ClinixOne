﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;
using static System.Net.Mime.MediaTypeNames;

namespace ClinixOne.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HospitalController : ControllerBase
    {
        private readonly IMasterRepository masterrepo;
        private readonly IHospitalRepository hospitalrepo;
        private readonly IPatientRepository patientrepo;
        public HospitalController(IMasterRepository masterRepository, IHospitalRepository hospitalRepository, IPatientRepository patientRepository)
        {
            masterrepo = masterRepository;
            hospitalrepo = hospitalRepository;
            patientrepo = patientRepository;
        }

        [HttpGet]
        [Route("GetPatientList")]
        [Authorize(Policy = "HospitalOnly")]
        public async Task<IActionResult> GetPatient(string Type, string Id = null)
        {
            var res = await hospitalrepo.GetPatientList(Type, Id);
            return Ok(res);
        }
        [HttpGet]
        [Route("GetAppointment")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetAppointment([FromQuery] Appointments appointments)
        {
            var res = await patientrepo.Get_AppointmentLetter(appointments);
            return Ok(res);
        }
        [HttpGet]
        [Route("UpdateAptStatus")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> UpdateAptStatus([FromQuery] Appointments appointments)
        {
            appointments.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await hospitalrepo.Update_AptStatus(appointments);

            if (res == 3 && appointments.Type == "Cancel_Appointment")
            {
                return Ok(new { message = "Appointment cancelled successfully", Result = res });
            }
            else if (res == 4 && appointments.Type == "CheckIn_Patient")
            {
                return Ok(new { message = "Patient Checked in successfully", Result = res });
            }
            else if(res == 5 && appointments.Type == "Undo_CheckIn")
            {
                return Ok(new { message = "Patient check-in has been undone", Result = res });
            }
            else if (res == 6 && appointments.Type == "Not_Visited")
            {
                return Ok(new { message = "Patient marked as not visited", Result = res });
            }
            else if (res == 6 && appointments.Type == "Not_Visited")
            {
                return Ok(new { message = "Patient marked as not visited", Result = res });
            }
            else if (res == 7 && appointments.Type == "Call_Patient")
            {
                return Ok(new { message = "Calling Patients", Result = res });
            }
            else if (res == 8 && appointments.Type == "Under_Observation")
            {
                return Ok(new { message = "Patient Marked As Under Observation", Result = res });
            }
            else if (res == 9 && appointments.Type == "Complete")
            {
                return Ok(new { message = "Appointment has been closed", Result = res });
            }
            else
            {
                return StatusCode(500, new { message = "Internal Server Error" });
            }
        }

        [HttpGet]
        [Route("GetDoctorsByShift")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetDoctorsByShift([FromQuery] DoctorsByShift doctors)
        {
            var res = await patientrepo.GetDoctorsByShift(doctors);
            return Ok(res);
        }

        [HttpPost]
        [Route("AptInsertUpdate")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> CnfAptBooking(Appointments apt)
        {
            apt.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await patientrepo.CnfAptBooking(apt);

            if (res == 2 && apt.Type == "Reschedule_Appointment")
            {
                return Ok(new { message = "Appointment Reschedule Successfully"});
            }
            else
            {
                // For updates or other operation types
                return Ok(new { message = "Operation completed successfully.", Result = res });
            }

        }

        [HttpGet]
        [Route("GetPatientCaseStudy")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> PatientCaseStudy(string AptId)
        {
            var res = await hospitalrepo.GetPatientCaseStudy(AptId, "GetPatientCaseStudy");
            return Ok(res);
        }

        [HttpPost]
        [Route("CaseStudySave")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> CaseStudyInsertUpdate(Consultation consultation)
        {
            consultation.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await hospitalrepo.CaseStudyInsertUpdate(consultation);
            if (res == 1)
            {
                return Ok(new { message = "Save successfully", Result = res });
            } 
            else if(res == 2)
            {
                return Ok(new { message = "Saved as Draft", Result = res });
            }
            else if (res == 3)
            {
                return Ok(new { message = "Updated Successfully", Result = res });
            }
            else
            {
                return StatusCode(500, new { message = "Internal Server Error" });
            }
        }

        [HttpGet]
        [Route("GetAppointmentHistory")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetAppointmentHistory(string patientId)
        {
            var res = await hospitalrepo.GetAppointmentHistoryById(patientId, "GetAppointmentHistory");
            return Ok(res);
        }

        [HttpGet]
        [Route("GetMadicalTest&Cat")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetCombineMedicalTestandCate()
        {
            var medicaltest = await masterrepo.Get_MedicalTestMaster();
            var testcategory = await masterrepo.Get_TestCategory();

            return Ok(new
            {
                MedicalTest = medicaltest,
                TestCategory = testcategory
            });
        }

        [HttpPost]
        [Route("ScheduleTest")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> ScheduleTest(ScheduleTest test)
        {
            test.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await hospitalrepo.ScheduleTest(test);
            if (res.Result == 1)
            {
                return Ok(new { message = res.StatusMessage, Result = "1" });
            }
            else if (res.Result == -1)
            {
                return Ok(new { message = res.StatusMessage, Result = "-1" });
            }
            else if (res.Result == 2)
            {
                return Ok(new { message = "Test cancelled successfully", Result = "2" });
            }
            else if (res.Result == 3)
            {
                return Ok(new { message = res.StatusMessage, Result = "3" });
            }
            else if (res.Result == 6)
            {
                return Ok(new { message = res.StatusMessage, Result = "6" });
            }
            else if (res.Result == 7)
            {
                return Ok(new { message = res.StatusMessage, Result = "7" });
            }
            else
            {
                return StatusCode(500, new { message = "Internal Server Error" });
            }
        }

        [HttpGet]
        [Route("GetTestHistory")]
       // [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetPatientTestHistory(string patientId, string Type)
        {
            var res = await hospitalrepo.Get_PatientTestHistory(Type, patientId);

            foreach (var item in res)
            {
                if (!string.IsNullOrEmpty(item.FileName))
                {
                    var fullPath = Path.Combine("FileUpload/Pdf/TestReport", item.FileName);

                    if (System.IO.File.Exists(fullPath))
                    {
                        var bytes = await System.IO.File.ReadAllBytesAsync(fullPath);
                        item.FileBase64 = Convert.ToBase64String(bytes);
                    }
                }
            }

            return Ok(res);
        }


        [HttpGet]
        [Route("GetPatientById")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetPatientById(string patientId)
        {
            var res = await patientrepo.Get_PatientById(patientId, "Get_PatientProfileById");
            PatientDetails patientDetails = new PatientDetails()
            {
                PatientId = res.PatientId,
                FullName = res.FullName,
                ProfilePic = res.ProfilePic,
                MobNumber = res.MobNumber,
                Email = res.Email,
                Gender = res.Gender,
                DOB = res.DOB,
                BloodGroup = res.BloodGroup,
                Religion = res.Religion,
                MaritalStatus = res.MaritalStatus
            };
            return Ok(patientDetails);
        }

        [HttpPost]
        [Route("UploadTestReport")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> UploadReport([FromForm] UploadTest test)
        {
            test.CreatedBy = User.FindFirst("EmpId")?.Value;
            if (test.File == null || test.File.Length == 0)
                return BadRequest("No file uploaded");

            if (Path.GetExtension(test.File.FileName).ToLower() != ".pdf")
                return BadRequest("Only PDF files are allowed");

            // build folder path
            var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "FileUpload", "Pdf", "TestReport");

            // create folder if not exists
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);

            // generate unique filename
            var safeTestName = Regex.Replace(test.TestName.Trim(), @"\s+", "_");

            var fileName = $"{safeTestName}_{test.PatientId}_{DateTime.Now:yyyyMMddHHmmss}.pdf";
            var filePath = Path.Combine(folderPath, fileName);

            // save file to server
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await test.File.CopyToAsync(stream);
            }

            // check file exists
            if (!System.IO.File.Exists(filePath))
                return StatusCode(500, "File failed to save");

            test.FilePath = filePath;
            test.FileName = fileName;
            test.Type = "uploadreport";

            var res = await hospitalrepo.UploadTestReport(test);

            // If DB save failed → delete file
            if (res.Result != 4)
            {
                if (System.IO.File.Exists(filePath))
                    System.IO.File.Delete(filePath);

                return StatusCode(500, new
                {
                    message = "DB update failed, file removed from server"
                });
            }

            // success
            return Ok(new
            {
                message = "File uploaded successfully",
                fileName
            });
        }

        [HttpPost]
        [Route("DeleteTestReport")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> DeleteReport([FromBody] UploadTest report)
        {
            report.CreatedBy = User.FindFirst("EmpId")?.Value;
            report.Type = "deletereport";

            var basePath = Directory.GetCurrentDirectory();
            var fullPath = Path.Combine(basePath, "FileUpload", "Pdf", "TestReport", report.FileName);

            bool fileExists = System.IO.File.Exists(fullPath);

            var res = await hospitalrepo.UploadTestReport(report);

            if (res.Result != 5)
            {
                return StatusCode(500, new
                {
                    message = "DB update failed, file not removed"
                });
            }

            if (fileExists)
            {
                try
                {
                    System.IO.File.Delete(fullPath);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new
                    {
                        message = "DB updated but failed to delete file from server",
                        error = ex.Message
                    });
                }
            }

            return Ok(new
            {
                message = "Report deleted successfully"
            });
        }


        #region OrderMedicines

        [HttpGet]
        [Route("GetPharmacyInventory")]
        [Authorize("HospitalOnly")]
        
        public async Task<IActionResult> GetPharmacyInventory()
        {
            var pharmainventory = (await masterrepo.Get_PharmacyInventory()).Where(m => m.IsActive == true);
            var drugcategory = (await masterrepo.Get_DrugCategory()).Where(m => m.IsActive == true);

            return Ok(new
            {
                pharmainventory,
                drugcategory
            });
        }

        [HttpPost]
        [Route("PrescriptionManage")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> PrescriptionManage(PharmacyInventory prescription)
        {
            prescription.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await hospitalrepo.PrescriptionManage(prescription);
            if (res.Result == 1)
            {
                return Ok(new { message = res.StatusMessage, Result = "1" });
            }
            else if (res.Result == -1)
            {
                return Ok(new { message = res.StatusMessage, Result = "-1" });
            }
            else if (res.Result == 2)
            {
                return Ok(new { message = "Prescription cancelled successfully", Result = "2" });
            }
            else if (res.Result == 3)
            {
                return Ok(new { message = res.StatusMessage, Result = "3" });
            }
            else
            {
                return StatusCode(500, new { message = "Internal Server Error" });
            }
        }

        [HttpGet]
        [Route("GetPatientMedicineHistory")]
        [Authorize("HospitalOnly")]
        public async Task<IActionResult> GetPatientMedicineHistory(string patientId, string Type)
        {
            var res = await hospitalrepo.Get_PatientMedicineHistory(Type, patientId);
            return Ok(res);
        }
        #endregion
    }
}
