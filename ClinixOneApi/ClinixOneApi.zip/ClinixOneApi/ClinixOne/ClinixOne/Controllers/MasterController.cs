﻿using ClinixOne.CustomAttributes;
using ClinixOne.Interface;
using ClinixOne.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ClinixOne.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        private readonly IMasterRepository masterrepo;
        public MasterController(IMasterRepository masterRepository)
        {
            masterrepo = masterRepository;
           // var claims = (System.Security.Claims.ClaimsIdentity)User.Identity;
           
        }

        #region Country_State_City
        [HttpGet]
        [Route("GetCountryStateCity")]
        public async Task<IActionResult> GetCountryStateCity(string Type, string Id = null, string Id2 = null)
        {
            var res = await masterrepo.Get_TextValueDD(Type, Id, Id2);
            return Ok(res);
        }

        #endregion

        #region Users

        [HttpGet]
        [Route("GetUsersList")]
        [Authorize(Policy = "HospitalOnly")]
        public IActionResult GetUserList()
        {
             var res = masterrepo.Get_RegisterUserLists("UserMaster_GetList");
             return Ok(res);
        }

        [HttpGet]
        [Authorize(Policy = "HospitalOnly")]
        [Route("GetMasterById")]
        public IActionResult GetMasterById(string Type, string Id = "")
        {
            dynamic res;
            if (Type == "Get_EmployeeDetailsById")
            {
                res = masterrepo.Get_RegisterUserLists(Type, Id).FirstOrDefault();
                return Ok(res);
            }
            else
            {
                res = masterrepo.Get_RegisterUserLists(Type, Id);
                return Ok(res);
            }
        }
        [Authorize(Policy = "HospitalOnly")]
        [HttpPost]
        [Route("RegisterUser")]
        public IActionResult RegisterHospitalUser(EmployeeDetails employee)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid model data.");
            }
            var userId = User.FindFirst("EmpId")?.Value;
            var res = masterrepo.InsertUpdate_HospitalUser(employee, userId);

            return res switch
            {
                1 => Ok(new {msg_code = "1", message = "User registered successfully." }),
                2 => Ok(new { msg_code = "2", message = "User updated successfully." }),
                _ => StatusCode(500, new { msg_code = "0", message = "Internal server error. Please try again later." })
            };
        }


        [Authorize(Policy = "HospitalOnly")]
        [HttpPost]
        [Route("UpdateUserPassword")]
        public async Task<IActionResult> UpdateUserPassword(UserPassword employee)
        {
            employee.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await masterrepo.UpdateUserPassword(employee);

            return res switch
            {
                1 => Ok(new { msg_code = "1", message = "Password Updated Successfully" }),
                _ => StatusCode(500, new { msg_code = "0", message = "Internal server error. Please try again later." })
            };
        }


        [HttpGet]
        [Route("GetRolesDD")]
        public IActionResult GetRoleDD()
        {
            var res = masterrepo.GetRolesDD();
            return Ok(res);
        }

        [HttpGet]
        [Route("GetDeptDD")]
       // [Authorize(Policy = "HospitalOrPatient")]
        public IActionResult GetDeptDD()
        {
            var res = masterrepo.GetDeptDD();
            return Ok(res);
        }

        #endregion

        #region RoleMaster

        [Authorize(Policy = "HospitalOnly")]
        [HttpPost]
        [Route("RoleAddUpdate")]
        public async Task<IActionResult> RoleAddUpdate(RoleMaster role)
        {
            role.CreatedBy = User.FindFirst("EmpId")?.Value;
            var res = await masterrepo.RoleMaster_InsertUpdate(role);
            return Ok(new
            {
                msg_code = res.Result,
                message = res.ResultMessage
            });


        }

        #endregion

        #region Shift Management
        [Authorize(Policy = "HospitalOnly")]
        [HttpPost]
        [Route("AddShift")]
        public async Task<IActionResult> AddShift(WorkPlanner planner)
        {
            var claims = (System.Security.Claims.ClaimsIdentity)User.Identity;
            string UserId = claims.Claims.Where(m => m.Type == "EmpId").FirstOrDefault().Value;
            var res = await masterrepo.CreateShiftBasedOnEmpId(planner, UserId);
            if(res > 0)
            {
                return Ok(new { msg_code = "1", message = "Shift registered successfully." });
            }
            else
            {
                return Ok(new { msg_code = "2", message = "User updated successfully." });
            }
        }

        [Authorize(Policy = "HospitalOnly")]
        [HttpGet]
        [Route("GetShift")]
        public async Task<IActionResult> GetShift(string EmpId, string Type)
        {
            var res = await masterrepo.GetShiftById(EmpId, Type);
            return Ok(res);
        }

        [Authorize(Policy = "HospitalOnly")]
        [HttpGet]
        [Route("GetDropDown")]
        public async Task<IActionResult> GetDropDownByType(string Type, string Id = null, string Id2 = null)
        {
            var res = await masterrepo.Get_TextValueDD(Type, Id, Id2);
            return Ok(res);
        }
        #endregion

        #region Menu Master

        [HttpGet]
        [Route("GetMenus")]
        public async Task<IActionResult> GetMenus(string Type, string Portal = "", string Id = "")
        {
            var res = await masterrepo.GetMenuById(Type, Portal ,Id);
            return Ok(res);
        }

        [Authorize(Policy = "HospitalOnly")]
        [HttpPost]
        [Route("UpdateMenus")]
        public async Task<IActionResult> UpdateMenus(MenuMaster menu)
        {
            var userId = User.FindFirst("EmpId")?.Value;
            var res = await masterrepo.update_Usermenus(menu ,userId);
            return res switch
            {
                1 => Ok(new { msg_code = "1", message = "Menus Updated Successfully." }),
                2 => Ok(new { msg_code = "2", message = "User updated successfully." }),
                _ => StatusCode(500, new { msg_code = "0", message = "Internal server error. Please try again later." })
            };
        }
        #endregion
    }
}
