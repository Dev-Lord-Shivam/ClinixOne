﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SelectPdf;
using System.Linq;

namespace ClinixOne.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IPatientRepository patientrepo;
        private readonly IMasterRepository masterrepo;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public PatientController(IPatientRepository patientRepository, IMasterRepository masterRepository, IWebHostEnvironment webHost)
        {
            patientrepo = patientRepository;
            masterrepo = masterRepository;
            _webHostEnvironment = webHost;
        }
        [HttpPost]
        [Route("RegisterPatient")]
        //[Authorize("PatientOnly")]
        public async Task<IActionResult> RegisterPatient(PatientDetails patient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid model data.");
            }
            var userId = User.FindFirst("EmpId")?.Value;
            var res = await patientrepo.Register_Patient(patient, userId ?? patient.PatientId);

            return res.Result switch
            {
                1 => Ok(new { msg_code = "1", PatientId = res.StatusMessage ,message = "User registered successfully." }),
                2 => Ok(new { msg_code = "2", message = "User updated successfully." }),
                3 => Ok(new {msg_code = "3", message = res.StatusMessage}),
                _ => StatusCode(500, new { msg_code = "0", message = "Internal server error. Please try again later." })
            };
        }
        [HttpGet]
        [Route("GetDoctorsByShift")]
        [Authorize("PatientOnly")]
        public async Task<IActionResult> GetDoctorsByShift([FromQuery] DoctorsByShift doctors)
        {
            var res = await patientrepo.GetDoctorsByShift(doctors);
            return Ok(res);
        }

        [HttpPost]
        [Route("AptInsertUpdate")]
        [Authorize("PatientOnly")]
        public async Task<IActionResult> CnfAptBooking(Appointments apt)
        {
            var res = await patientrepo.CnfAptBooking(apt);

            if (res >= 1 && apt.Type == "Book_Appointment")
            {
                Appointments appoint = new Appointments()
                {
                    AptId = res,
                    Type = "GetPatientAptById"
                };
                var AptLetter = await patientrepo.Get_AppointmentLetter(appoint);
                return Ok(AptLetter.FirstOrDefault());
            }
            else if(res == 2 && apt.Type == "Reschedule_Appointment")
            {
                Appointments appoint = new Appointments()
                {
                    PatientId = apt.PatientId,
                    Type = "GetUpcomingAppointment"
                };
                var latestData = await patientrepo.Get_AppointmentLetter(appoint);
                return Ok(latestData);
            }
            else if(res == 3 && apt.Type == "Cancel_Appointment")
            {
                var upcoming = await patientrepo.Get_AppointmentLetter(new Appointments()
                {
                    PatientId = apt.PatientId,
                    Type = "GetUpcomingAppointment"
                });
                var past = await patientrepo.Get_AppointmentLetter(new Appointments()
                {
                    PatientId = apt.PatientId,
                    Type = "GetAppointmentHistory"
                });
                return Ok(new
                {
                    upcoming,
                    past
                });
            }
            else if (res == -1)
            {
                // Doctor fully booked (as per SQL logic)
                return BadRequest(new { message = "Doctor is fully booked for the selected date." });
            }
            else if (res == 0)
            {
                // SQL transaction failed or exception occurred
                return StatusCode(500, new { message = "Error occurred while booking appointment." });
            }
            else
            {
                // For updates or other operation types
                return Ok(new { message = "Operation completed successfully.", Result = res });
            }

        }

        [HttpGet]
        [Route("GetAppointment")]
        [Authorize("PatientOnly")]
        public async Task<IActionResult> GetAppointment([FromQuery] Appointments appointments)
        {
            var res = await patientrepo.Get_AppointmentLetter(appointments);
            return Ok(res);
        }

        [HttpGet]
        [Route("GetPatientById")]
        [Authorize("PatientOnly")]
        public async Task<IActionResult> GetPatientById(string PatientId)
        {
            var res = await patientrepo.Get_PatientById(PatientId, "Get_PatientProfileById");
            return Ok(res);
        }

        [HttpGet]
        [Route("DnldAptLetters")]
        [Authorize("PatientOnly")]
        public async Task<IActionResult> DownloadLetter(int aptid)
        {
            Appointments appoint = new Appointments()
            {
                AptId = aptid,
                Type = "GetPatientAptById"
            };
            var res = await patientrepo.Get_AppointmentLetter(appoint);
            var letter = res.FirstOrDefault();
            // Read the HTML template from file
            string templatePath = Path.Combine(_webHostEnvironment.WebRootPath, "Templates", "PdfTemplates", "AppointmentLetter.html");
            string htmlTemplate = await System.IO.File.ReadAllTextAsync(templatePath);

            // Convert images to base64
            string logoPath = Path.Combine(_webHostEnvironment.WebRootPath, "Images", "medical-logo.png");
            string qrCodePath = Path.Combine(_webHostEnvironment.WebRootPath, "Images", "qr-code.png"); // Your QR code image

            string logoBase64 = "";
            string qrCodeBase64 = "";

            if (System.IO.File.Exists(logoPath))
            {
                byte[] logoBytes = await System.IO.File.ReadAllBytesAsync(logoPath);
                logoBase64 = $"data:image/png;base64,{Convert.ToBase64String(logoBytes)}";
            }

            if (System.IO.File.Exists(qrCodePath))
            {
                byte[] qrBytes = await System.IO.File.ReadAllBytesAsync(qrCodePath);
                qrCodeBase64 = $"data:image/jpg;base64,{Convert.ToBase64String(qrBytes)}";
            }

            // Replace placeholders with actual data
            string htmlContent = htmlTemplate
                .Replace("{{LogoImage}}", logoBase64)
                .Replace("{{QRCodeImage}}", qrCodeBase64)
                .Replace("{{PatientId}}", letter.PatientId ?? "N/A")
                .Replace("{{Nationality}}", letter.Nationality ?? "N/A")
                .Replace("{{Residency}}", $"{letter.Nationality ?? "N/A"} RESIDENT")
                .Replace("{{PatientName}}", letter.PatientName ?? "N/A")
                .Replace("{{Dob}}", letter.DOB ?? "N/A")
                .Replace("{{Age}}", letter.Age.ToString())
                .Replace("{{Gender}}", letter.Gender ?? "N/A")
                .Replace("{{MobNumber}}", letter.MobNumber ?? "N/A")
                .Replace("{{EmailId}}", letter.EmailId ?? "N/A")
                .Replace("{{AptDate}}", letter.AptDate ?? "N/A")
                .Replace("{{SlotStart}}", letter.SlotStart ?? "N/A")
                .Replace("{{ClinceName}}", letter.ClinicName ?? "N/A")
                .Replace("{{LocationName}}", letter.LocationName ?? "N/A")
                .Replace("{{DoctorName}}", letter.DoctorName ?? "N/A")
                .Replace("{{PaymentMode}}", letter.PaymentMode ?? "N/A")
                .Replace("{{InvoiceNo}}", "W4016217" ?? "N/A")
                .Replace("{{BillNo}}", "A003350657" ?? "N/A")
                .Replace("{{ReceiptNo}}", "WEBAPU097406" ?? "N/A")
                .Replace("{{PaidOn}}", letter.CreatedAt ?? "N/A")
                .Replace("{{Amount}}", letter.Amount.ToString() ?? "0")
                .Replace("{{Address}}", letter.Address ?? "N/A");

            HtmlToPdf converter = new HtmlToPdf();
            converter.Options.PdfPageSize = PdfPageSize.A4;
            converter.Options.PdfPageOrientation = PdfPageOrientation.Portrait;
            converter.Options.MarginTop = 10;
            converter.Options.MarginBottom = 10;
            converter.Options.MarginLeft = 10;
            converter.Options.MarginRight = 10;

            PdfDocument doc = converter.ConvertHtmlString(htmlContent);
            byte[] pdf = doc.Save();
            doc.Close();

            return File(pdf, "application/pdf", $"Appointment_Letter_{aptid}.pdf");
        }
       
    }
}
