﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ClinixOne.CustomAttributes
{
    public class SessionExpireAttribute: ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            string EmpId = context.HttpContext.Session.GetString("EmpId");

            // Example: check if a known session key is set (e.g., EmpId or UserId)
            if (string.IsNullOrEmpty(EmpId))
            {
                context.Result = new UnauthorizedObjectResult(new
                {
                    error_code = "SESSION_EXPIRED",
                    error_msg = "Your session has expired. Please log in again."
                });
                return;
            }

            base.OnActionExecuting(context);
        }
    }
}
