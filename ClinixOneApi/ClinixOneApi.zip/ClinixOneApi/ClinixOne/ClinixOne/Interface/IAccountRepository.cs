﻿using ClinixOne.Model;

namespace ClinixOne.Interface
{
    public interface IAccountRepository
    {
        Task<EmployeeDetails> Authenticateuser(LoginModel account);
        Task<PatientDetails> AuthenticatePatients(LoginModel account);
    }
}
