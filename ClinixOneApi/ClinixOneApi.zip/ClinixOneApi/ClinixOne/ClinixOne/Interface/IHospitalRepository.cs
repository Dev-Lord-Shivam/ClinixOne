﻿using ClinixOne.Model;

namespace ClinixOne.Interface
{
    public interface IHospitalRepository
    {
        Task<IEnumerable<PatientDetails>> GetPatientList(string Type, string Id = null);
        Task<int> Update_AptStatus(Appointments apt);
        Task<CaseStudy> GetPatientCaseStudy(string AptId, string Type);
        Task<int> CaseStudyInsertUpdate(Consultation consultation);
        Task<IEnumerable<AppointmentLetter>> GetAppointmentHistoryById(string Id, string Type);
        Task<(int Result, string StatusMessage)> ScheduleTest(ScheduleTest test);
        Task<IEnumerable<ScheduleTest>> Get_PatientTestHistory(string Type, string PatientId);
        Task<(int Result, string StatusMessage)> UploadTestReport(UploadTest test);
        Task<(int Result, string StatusMessage)> PrescriptionManage(PharmacyInventory prescription);
        Task<IEnumerable<PharmacyInventory>> Get_PatientMedicineHistory(string Type, string PatientId);
    }
}
