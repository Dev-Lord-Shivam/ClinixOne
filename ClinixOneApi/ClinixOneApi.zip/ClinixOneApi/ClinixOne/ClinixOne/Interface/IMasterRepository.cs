﻿using ClinixOne.Model;

namespace ClinixOne.Interface
{
    public interface IMasterRepository
    {
        int InsertUpdate_HospitalUser(EmployeeDetails details, string UserId = "");
        IEnumerable<RoleMaster> GetRolesDD();
        IEnumerable<DeptMaster> GetDeptDD();
        IEnumerable<EmployeeDetails> Get_RegisterUserLists(string Type, string Id = null);
        Task<int> CreateShiftBasedOnEmpId(WorkPlanner planner, string userId);
        Task<IEnumerable<WorkPlanner>> GetShiftById(string EmpId, string Type);
        Task<IEnumerable<TextValue>> Get_TextValueDD(string Type, string Id = null,string Id2= null);
        Task<IEnumerable<TestCategory>> Get_TestCategory();
        Task<IEnumerable<MedicalTest>> Get_MedicalTestMaster();
        Task<IEnumerable<PharmacyInventory>> Get_PharmacyInventory();
        Task<IEnumerable<DrugCategory>> Get_DrugCategory();
        Task<IEnumerable<MenuMaster>> GetMenuById(string Type, string Portal = null, string Id = null);
        Task<int> update_Usermenus(MenuMaster menu, string UserId);
        Task<(int Result, string ResultMessage)> RoleMaster_InsertUpdate(RoleMaster role);
        Task<int> UpdateUserPassword(UserPassword employee);
    }
}
