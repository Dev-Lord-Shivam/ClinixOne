﻿using ClinixOne.Model;

namespace ClinixOne.Interface
{
    public interface IPatientRepository
    {
        Task<(int Result, string StatusMessage)> Register_Patient(PatientDetails details, string EmpId = null);
        Task<IEnumerable<DoctorsByShift>> GetDoctorsByShift(DoctorsByShift doctors);
        Task<int> CnfAptBooking(Appointments apt);
        Task<IEnumerable<AppointmentLetter>> Get_AppointmentLetter(Appointments apt);
        Task<PatientDetails> Get_PatientById(string PatientId, string Type);
    }
}
