﻿using System.Net;
using System.Text.Json;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            var endpoint = context.GetEndpoint();
            string controller = endpoint?.Metadata
                .OfType<Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor>()
                .FirstOrDefault()?.ControllerName ?? "UnknownController";

            string action = endpoint?.Metadata
                .OfType<Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor>()
                .FirstOrDefault()?.ActionName ?? "UnknownAction";

            string path = context.Request.Path;
            string method = context.Request.Method;
            string time = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");

            _logger.LogError(ex,
                "Exception occurred at {Time}. Controller: {Controller}, Action: {Action}, Path: {Path}, Method: {Method}, Message: {Message}",
                time, controller, action, path, method, ex.Message);

            if (!context.Response.HasStarted)
            {
                context.Response.Clear();
                context.Response.ContentType = "application/json";
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

                var response = new
                {
                    msg_code = "0",
                    message = "An unexpected error occurred. Please try again later.",
                    error = ex.Message // ⚠ hide in production if needed
                };

                var json = JsonSerializer.Serialize(response);
                await context.Response.WriteAsync(json);
            }
        }
    }
}
