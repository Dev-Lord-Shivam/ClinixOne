﻿namespace ClinixOne.Model
{
    public class Appointments:BaseModel
    {
        public int AptId { get; set; }
        public int DptId { get; set; }
        public int ClinicId { get; set; }
        public int LocationId { get; set; }
        public string? PatientId { get; set; }
        public string? DoctorId { get; set; }
        public string? AptDate { get; set; }
        public string? AptCategory { get; set; }
        public string? AptStatus { get; set; }
        public decimal Fee { get; set; }
        public string? PaymentStatus { get; set; }
        public string? Remarks { get; set; }
    }
    public class AppointmentLetter: BaseModel
    {
        public int AptId { get; set; }
        public string AptDate { get; set; }
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string DoctorId { get; set; }
        public string DOB { get; set; }
        public string Nationality { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string EmailId { get; set; }
        public string MobNumber { get; set; }
        public string ClinicName { get; set; }
        public string LocationName { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMode { get; set; }
        public string SlotStart { get; set; }
        public string SlotEnd { get; set; }
        public string ProfilePic { get; set; }
        public string? AptStatus { get; set; }
        public string? DeptName { get; set; }
        public int DeptId { get; set; }
        public string? AptCategory { get; set; }
    }

    public class ConsultationModel
    {
        public List<string> Symptoms { get; set; }
        public string PastMedicalRecord { get; set; }
        public string PatientOverview { get; set; }
        public ConsultationDetails Consultation { get; set; }
        public string Status { get; set; }
    }

    public class ConsultationDetails
    {
        public string ChiefComplaint { get; set; }
        public string Symptoms { get; set; }
        public string Diagnosis { get; set; }
        public string Notes { get; set; }
        public string FollowUpDate { get; set; }
        public Vitals Vitals { get; set; }
    }

    public class Vitals
    {
        public string BloodPressure { get; set; }
        public string Temperature { get; set; }
        public string Pulse { get; set; }
        public string Weight { get; set; }
        public string Height { get; set; }
    }

}
