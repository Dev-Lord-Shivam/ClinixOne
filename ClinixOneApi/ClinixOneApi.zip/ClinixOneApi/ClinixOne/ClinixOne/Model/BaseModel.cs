﻿namespace ClinixOne.Model
{
    public class BaseModel
    {
        public string? CreatedAt { get; set; }
        public string? CreatedBy { get; set; }
        public string? ModifiedAt { get; set; }
        public string? ModifiedBy { get; set; }
        public string? JsonData { get; set; }
        public bool? IsActive { get; set; }
        public string? Type { get; set; }
        public string? FromDate { get; set; }
        public string? ToDate { get; set; }
    }
}
