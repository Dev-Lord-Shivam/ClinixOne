﻿namespace ClinixOne.Model
{
    public class CaseStudy
    {
        public PatientDetails PatientDetails { get; set; }
        public Consultation PatientConsultation { get; set; }
    }

    public class Consultation:BaseModel
    {
        public string AptId { get; set; }
        public string Symptoms { get; set; }
        public string? PastRecords { get; set; }
        public string Overview { get; set; }
        public string Precaution { get; set; }
        public string Diagnosis { get; set; }
        public string? BloodPressure { get; set; }
        public string? Temperature { get; set; }
        public string? PulseRate { get; set; }
        public string? Weight { get; set; }
        public string? Height { get; set; }
        public int Status { get; set; }
    }
}
