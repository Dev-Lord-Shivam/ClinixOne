﻿using System.ComponentModel.DataAnnotations;

namespace ClinixOne.Model
{
    public class EmployeeDetails:BaseModel
    {
        [Key]
        [StringLength(6)]
        public string? EmpId { get; set; }
        public string? EmpPhoto { get; set; }

        [Required]
        [StringLength(100)]
        public string EmpName { get; set; }

        [Required]
        [StringLength(10)]
        public string Gender { get; set; }

        [Required]
        [StringLength(15)]
        public string DOB { get; set; }

        [Required]
        [StringLength(15)]
        public string MaritalStatus { get; set; }

        [Required]
        [StringLength(200)]
        public string Qualification { get; set; }

        [Required]
        [StringLength(200)]
        public string EmailId { get; set; }

        [StringLength(200)]
        public string? AltEmail { get; set; }

        [Required]
        [StringLength(15)]
        public string MobNo { get; set; }

        [StringLength(15)]
        public string? AltMobNo { get; set; }

        [Required]
        [StringLength(300)]
        public string PresentStreet { get; set; }

        [Required]
        [StringLength(100)]
        public string PresentCity { get; set; }

        [Required]
        [StringLength(100)]
        public string PresentState { get; set; }

        [Required]
        [StringLength(10)]
        public string PresentZip { get; set; }

        [Required]
        [StringLength(100)]
        public string PresentCountry { get; set; }

        public bool IsAddressSame { get; set; }

        [StringLength(300)]
        public string? ParmaStreet { get; set; }

        [StringLength(100)]
        public string? ParmaCity { get; set; }

        [StringLength(100)]
        public string? ParmaState { get; set; }

        [StringLength(10)]
        public string? ParmaZip { get; set; }

        [StringLength(100)]
        public string? ParmaCountry { get; set; }

        [Required]
        public byte RoleId { get; set; }
        public string? RoleName { get; set; }

        [Required]
        public short DeptId { get; set; }
        public string? DeptName { get; set; }

        [Required]
        [StringLength(15)]
        public string DOJ { get; set; }

        [Required]
        public byte ExpInYear { get; set; }
        public string? PrmanentAddress { get; set; }
        public string? PresentAddress { get; set; }
        public string? PortalType { get; set; }
        public string? Password { get; set; }
    }
    public class DoctorsByShift : BaseModel
    {
        public string? DoctorId { get; set; }
        public string? Date { get; set; }
        public string? name { get; set; }
        public string? image { get; set; }
        public string? available { get; set; }
        public int DeptId { get; set; }
        public string? DeptName { get; set; }
        public string? Exp { get; set; }
        public string? MonthName { get; set; }
        public string? DayName { get; set; }
        public string? clinicid { get; set; }
        public string? locationid { get; set; }
        public string? ClinicName { get; set; }
        public string? LocationName { get; set; }
    }
    public class UserPassword:BaseModel
    {
        public string? EmpId { get; set; }
        public string? Password { get; set; }
    }
}
