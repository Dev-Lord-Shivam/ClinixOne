﻿using System.ComponentModel.DataAnnotations;

namespace ClinixOne.Model
{
    public class LoginModel:BaseModel
    {
        [Required]
        public string LoginId { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
