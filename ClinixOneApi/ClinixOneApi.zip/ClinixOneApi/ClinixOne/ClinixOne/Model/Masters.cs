﻿namespace ClinixOne.Model
{
    public class Masters
    {
    }
    public class RoleMaster : BaseModel
    {
        public int? RoleId { get; set; }
        public string RoleName { get; set; }
        public string? DeptType { get; set; }
        public string? PortalType { get; set; }
    }
    public class DeptMaster : BaseModel
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }
        public string DeptCode { get; set; }
        public string DeptType { get; set; }
        public string DeptDesc { get; set; }
    }
    public class TextValue
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
