﻿namespace ClinixOne.Model
{
    public class MedicalTest : BaseModel
    {
        public int TestId { get; set; }
        public string TestName { get; set; }
        public string? SampleType { get; set; }
        public string? NormalRange { get; set; }
        public string? Unit { get; set; }
        public decimal MRP { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string? Description { get; set; }
        public bool IsNABLAccredited { get; set; }
        public bool IsFastingRequired { get; set; }
    }
    public class TestCategory : BaseModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string? CategoryCode { get; set; }
        public string? Description { get; set; }
    }
    public class ScheduleTest : BaseModel
    {
        public int TestId { get; set; }
        public int ScheduleId { get; set; }
        public string? PatientId { get; set; }
        public string? ScheduleBy { get; set; }
        public string? TestName { get; set; }
        public string? TestCode { get; set; }
        public string? CategoryName { get; set; }
        public int CategoryId { get; set; }
        public decimal? MRP { get; set; }
        public string? Status { get; set; }
        public string? FileBase64 { get; set; }
        public string? FilePath { get; set; }
        public string? FileName { get; set; }
    }

    public class UploadTest : BaseModel
    {
        public int TestId { get; set; }
        public int ScheduleId { get; set; }
        public string? PatientId { get; set; }
        public string? TestName { get; set; }
        public string? FilePath { get; set; }
        public string? FileName { get; set; }
        public IFormFile? File { get; set; }
    }
}
