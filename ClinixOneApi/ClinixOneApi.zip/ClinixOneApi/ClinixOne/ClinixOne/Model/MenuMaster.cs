﻿namespace ClinixOne.Model
{
    public class MenuMaster:BaseModel
    {
        public string? MenuName { get; set; }
        public int? MenuLevel { get; set; }
        public string? MenuURL { get; set; }
        public string? Icon { get; set; }
        public string? DisplayName { get; set; }
        public int? ParentMenuId { get; set; }
        public int? MenuId { get; set; }
        public string? Status { get; set; }
        public bool? ReadAccess { get; set; }
        public bool? WriteAccess { get; set; }
        public int? RoleId { get; set; }
        public string? RoleName { get; set; }
    }
}
