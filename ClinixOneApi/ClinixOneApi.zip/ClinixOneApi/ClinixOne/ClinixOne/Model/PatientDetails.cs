﻿namespace ClinixOne.Model
{
    public class PatientDetails:BaseModel
    {
        public string? PatientId { get; set; }
        public string FullName { get; set; }
        public string? ProfilePic { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }
        public int Age { get; set; }
        public string BloodGroup { get; set; }
        public string MaritalStatus { get; set; }
        public string Religion { get; set; }
        public string Nationality { get; set; }
        public string Occupation { get; set; }
        public string Email { get; set; }
        public string MobNumber { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string CountryId { get; set; }
        public string StateId { get; set; }
        public int Pincode { get; set; }
        public string? Address { get; set; }
        public string? Password { get; set; }
        public string? RoleName { get; set; }
        public byte RoleId { get; set; }
    }
}
