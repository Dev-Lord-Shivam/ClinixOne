﻿namespace ClinixOne.Model
{
    public class Pharmacy
    {
    }
    public class PharmacyInventory:BaseModel
    {
        public string? PatientId { get; set; }
        public string? PrescriptionId { get; set; }
        public string? PrescribedBy { get; set; }
        public string? OrderId { get; set; }
        public long InventoryId { get; set; }
        public int? DrugTypeId { get; set; }
        public int? CategoryId { get; set; }
        public string? ItemCode { get; set; }
        public string? ItemName { get; set; }
        public string? GenericName { get; set; }
        public string? DrugType { get; set; }
        public string? CategoryName { get; set; }
        public int StockQty { get; set; }
        public decimal MRP { get; set; }
        public decimal MrpParQty { get; set; }
        public bool IsPrescriptionRequired { get; set; }
        public string? Image { get; set; }
        public string? Status { get; set; }
        public int Quantity { get; set; }
    }
    public class DrugCategory : BaseModel 
    {
        public int? CategoryId { get; set; }
        public string? CategoryName { get; set; }
    }

}
