﻿using System.ComponentModel.DataAnnotations;

namespace ClinixOne.Model
{
    public class WorkPlanner:BaseModel
    {
        public int? ShiftId { get; set; }
        [StringLength(500)]
        public string title { get; set; }
        [StringLength(6)]
        public string EmpId { get; set; }
        public string startTime { get; set; }
        public string endTime { get; set; }
        public string? recurringStart { get; set; }
        public string? recurringEnd { get; set; }
        public short maxPatients { get; set; }
        public bool isRecurring { get; set; }
        public string? recurrenceType { get; set; } = string.Empty;
        public string? ShiftDate { get; set; } 
        public string? DayName { get; set; }
        public string? TimeRange { get; set; }
        public string? RowType { get; set; }
        public string? clinicid { get; set; }
        public string? locationid { get; set; }
        public string? ClinicName { get; set; }
        public string? LocationName { get; set; }
        public List<int>? SelectedDays { get; set; } = new();
        public List<string>? SelectedDate { get; set; } = new();

    }
}
