﻿using ClinixOne.Interface;
using ClinixOne.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Events;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
string conn = "";
conn = builder.Configuration.GetConnectionString("DefaultConnection");
// Add services to the container.

// Add Authentication Parameters
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),
            ClockSkew = TimeSpan.Zero
        };

        options.Events = new JwtBearerEvents
        {
            OnAuthenticationFailed = context =>
            {
                if (context.Exception is SecurityTokenExpiredException)
                {
                    // Expired token
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    context.Response.ContentType = "application/json";

                    var result = System.Text.Json.JsonSerializer.Serialize(new
                    {
                        error_code = "TOKEN_EXPIRED",
                        error_msg = "Your token has expired. Please log in again."
                    });

                    // Tell the pipeline we’ve handled it
                    
                    return context.Response.WriteAsync(result);
                }

                return Task.CompletedTask;
            },
            OnChallenge = context =>
            {
                // This will fire for missing/invalid tokens
                if (!context.Response.HasStarted)
                {
                    context.HandleResponse();
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    context.Response.ContentType = "application/json";

                    var result = System.Text.Json.JsonSerializer.Serialize(new
                    {
                        error_code = "UNAUTHORIZED",
                        error_msg = "You are not authorized. Token is missing or invalid."
                    });

                    return context.Response.WriteAsync(result);
                }
                context.HandleResponse();

                return Task.CompletedTask;
            },
            OnForbidden = context =>
            {
                // When token is valid but fails [Authorize] (e.g., wrong role/policy)
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.ContentType = "application/json";

                var result = System.Text.Json.JsonSerializer.Serialize(new
                {
                    error_code = "FORBIDDEN",
                    error_msg = "You don’t have permission to access this resource."
                });

                return context.Response.WriteAsync(result);
            }
        };
    });

    // 🛡️ Authorization Policies
    builder.Services.AddAuthorization(options =>
    {
        // Patients can only access patient APIs
        options.AddPolicy("PatientOnly", policy =>
            policy.RequireRole("Patient"));

        // Hospitals can only access hospital APIs
        options.AddPolicy("HospitalOnly", policy =>
            policy.RequireRole("Hospital"));

        // Hospitals MAY access patient APIs
        options.AddPolicy("HospitalOrPatient", policy =>
            policy.RequireRole("Hospital", "Patient"));
    });

// 🔹 Configure Serilog before building app
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning) // reduce noise
    .Enrich.FromLogContext()
    .WriteTo.File(
        path: "Logs/app_log.txt",
        rollingInterval: RollingInterval.Day,
        retainedFileCountLimit: 7, // keep last 7 days
        shared: true
    )
    .CreateLogger();

// 🔹 Replace default logging with Serilog
builder.Host.UseSerilog();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddTransient<IMasterRepository>(c => new MasterRepository(conn));
builder.Services.AddTransient<IAccountRepository>(c => new AccountRepository(conn));
builder.Services.AddTransient<IPatientRepository>(c => new PatientRepository(conn));
builder.Services.AddTransient<IHospitalRepository>(c => new HospitalRepository(conn));
builder.Services.Configure<IISOptions>(options =>
{
    options.ForwardClientCertificate = false;
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("corsapp", policy =>
    {
        policy.WithOrigins(
            "http://localhost:7098",
            "http://localhost:5173",
            "https://clinixone.netlify.app"
        )
        .AllowAnyHeader()
        .AllowAnyMethod()
        .AllowCredentials();
    });
});



//builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
//{
//    builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader().AllowCredentials();
//}));

builder.Services.AddSwaggerGen(option =>
{
    option.SwaggerDoc("v1", new OpenApiInfo { Title = "CLINIXONE API", Version = "v1" });
    option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter a valid token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JWT",
        Scheme = "Bearer"
    });
    option.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id="Bearer"
                }
            },
            new string[]{}
        }
    });
});


var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}

app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseHttpsRedirection();
app.UseCors("corsapp");
app.UseStaticFiles();
//app.UseSession();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();