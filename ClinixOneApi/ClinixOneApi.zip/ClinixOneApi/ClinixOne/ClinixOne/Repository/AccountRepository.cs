﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace ClinixOne.Repository
{
    public class AccountRepository: IAccountRepository
    {
        readonly IDbConnection dbConnection;
        public AccountRepository(string connectionString)
        {
            dbConnection = new SqlConnection(connectionString);
        }

        public async Task<EmployeeDetails> Authenticateuser(LoginModel account)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();

                parameters.Add("Type", account.Type);
                parameters.Add("LoginId", account.LoginId);
                parameters.Add("Password", account.Password);

                return await dbConnection.QueryFirstOrDefaultAsync<EmployeeDetails>(
                    "Authenticate_Users",
                    parameters,
                    commandTimeout: 10200,
                    commandType: System.Data.CommandType.StoredProcedure
                );
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<PatientDetails> AuthenticatePatients(LoginModel account)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();

                parameters.Add("Type", account.Type);
                parameters.Add("LoginId", account.LoginId);
                parameters.Add("Password", account.Password);

                return await dbConnection.QueryFirstOrDefaultAsync<PatientDetails>(
                    "Authenticate_Users",
                    parameters,
                    commandTimeout: 10200,
                    commandType: System.Data.CommandType.StoredProcedure
                );
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
