﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;

namespace ClinixOne.Repository
{
    public class HospitalRepository: IHospitalRepository
    {
        private readonly IDbConnection dbConnection;
        public HospitalRepository(string connectionString)
        {
            dbConnection = new SqlConnection(connectionString);
        }

        public async Task<IEnumerable<PatientDetails>> GetPatientList(string Type, string Id = null)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("Id", Id);
            return await dbConnection.QueryAsync<PatientDetails>("Masters_GetDetails", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
        }

        public async Task<int> Update_AptStatus(Appointments apt)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", apt.Type);
            parameters.Add("AptId", apt.AptId);
            parameters.Add("UserId", apt.CreatedBy);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            await dbConnection.QueryAsync<int>("Appointments_Manage", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);

            return parameters.Get<int>("@Result");
        }

        public async Task<CaseStudy> GetPatientCaseStudy(string AptId, string Type)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("AptId", AptId);
            var multi = await dbConnection.QueryMultipleAsync("PatientCaseStudy_Manage", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
            var patientDetails = await multi.ReadFirstOrDefaultAsync<PatientDetails>();
            var consultation = await multi.ReadFirstOrDefaultAsync<Consultation>();

            return new CaseStudy
            {
                PatientDetails = patientDetails,
                PatientConsultation = consultation
            };
        }
        public async Task<int> CaseStudyInsertUpdate(Consultation consultation)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("AptId", consultation.AptId);
            parameters.Add("Symptoms", consultation.Symptoms);
            parameters.Add("PastRecords", consultation.PastRecords);
            parameters.Add("Overview", consultation.Overview);
            parameters.Add("Precaution", consultation.Precaution);
            parameters.Add("Diagnosis", consultation.Diagnosis);
            parameters.Add("BloodPressure", consultation.BloodPressure);
            parameters.Add("Temperature", consultation.Temperature);
            parameters.Add("PulseRate", consultation.PulseRate);
            parameters.Add("Weight", consultation.Weight);
            parameters.Add("Height", consultation.Height);
            parameters.Add("EmpId", consultation.CreatedBy);
            parameters.Add("Status", consultation.Status);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            await dbConnection.QueryAsync<int>("CaseStudy_InsertUpdate", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);

            return parameters.Get<int>("@Result");
        }
        public async Task<IEnumerable<AppointmentLetter>> GetAppointmentHistoryById(string Id, string Type)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("@PatientId", Id);
            return await dbConnection.QueryAsync<AppointmentLetter>("Get_Appointments", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
        }
        public async Task<(int Result, string StatusMessage)> ScheduleTest(ScheduleTest test)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("PatientId", test.PatientId);
            parameters.Add("TestId", test.TestId);
            parameters.Add("ScheduleId", test.ScheduleId);
            parameters.Add("EmpId", test.CreatedBy);
            parameters.Add("JsonData", test.JsonData);
            parameters.Add("Type", test.Type);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("StatusMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 10000);
            await dbConnection.QueryAsync<(int, string)>("ScheduleTest_InsertUpdate", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
            return (
                parameters.Get<int>("@Result"),
                parameters.Get<string>("@StatusMessage")
            );
        }

        public async Task<IEnumerable<ScheduleTest>> Get_PatientTestHistory(string Type, string PatientId)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("PatientId", PatientId);
            return await dbConnection.QueryAsync<ScheduleTest>("PatientCaseStudy_Manage", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
        }

        public async Task<(int Result, string StatusMessage)> UploadTestReport(UploadTest test)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("ScheduleId", test.ScheduleId);
            parameters.Add("FilePath", test.FilePath);
            parameters.Add("FileName", test.FileName);
            parameters.Add("Type", test.Type);
            parameters.Add("EmpId", test.CreatedBy);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("StatusMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 10000);
            await dbConnection.QueryAsync<(int, string)>("ScheduleTest_InsertUpdate", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
            return (
                parameters.Get<int>("@Result"),
                parameters.Get<string>("@StatusMessage")
            );
        }
        public async Task<(int Result, string StatusMessage)> PrescriptionManage(PharmacyInventory prescription)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("PatientId", prescription.PatientId);
            parameters.Add("PrescriptionId", prescription.PrescriptionId);
            parameters.Add("InventoryId", prescription.InventoryId);
            parameters.Add("EmpId", prescription.CreatedBy);
            parameters.Add("JsonData", prescription.JsonData);
            parameters.Add("Type", prescription.Type);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("StatusMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 10000);
            await dbConnection.QueryAsync<(int, string)>("Prescription_InsertUpdate", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
            return (
                parameters.Get<int>("@Result"),
                parameters.Get<string>("@StatusMessage")
            );
        }
        public async Task<IEnumerable<PharmacyInventory>> Get_PatientMedicineHistory(string Type, string PatientId)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("PatientId", PatientId);
            return await dbConnection.QueryAsync<PharmacyInventory>("PatientCaseStudy_Manage", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
        }
    }
}
