﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Dapper;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Numerics;

namespace ClinixOne.Repository
{
    public class MasterRepository:IMasterRepository
    {
        readonly IDbConnection dbConnection;
        public MasterRepository(string connectionString)
        {
            dbConnection = new SqlConnection(connectionString);
        }

        public IEnumerable<EmployeeDetails> Get_RegisterUserLists(string Type, string Id = null)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();

                parameters.Add("Type", Type);
                parameters.Add("Id", Id);
                return dbConnection.Query<EmployeeDetails>("Masters_GetDetails", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public int InsertUpdate_HospitalUser(EmployeeDetails details, string UserId = "")
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();

                parameters.Add("EmpId", details.EmpId);
                parameters.Add("EmpName", details.EmpName);
                parameters.Add("EmpPhoto", details.EmpPhoto);
                parameters.Add("Gender", details.Gender);
                parameters.Add("MaritalStatus", details.MaritalStatus);
                parameters.Add("Qualification", details.Qualification);
                parameters.Add("EmailId", details.EmailId);
                parameters.Add("AltEmail", details.AltEmail);
                parameters.Add("MobNo", details.MobNo);
                parameters.Add("AltMobNo", details.AltMobNo);
                parameters.Add("ParmaCity", details.ParmaCity);
                parameters.Add("ParmaCountry", details.ParmaCountry);
                parameters.Add("ParmaState", details.ParmaState);
                parameters.Add("ParmaZip", details.ParmaZip);
                parameters.Add("ParmaStreet", details.ParmaStreet);
                parameters.Add("@IsAddressSame", details.IsAddressSame);
                parameters.Add("PresentCity", details.PresentCity);
                parameters.Add("PresentCountry", details.PresentCountry);
                parameters.Add("PresentState", details.PresentState);
                parameters.Add("PresentZip", details.PresentZip);
                parameters.Add("PresentStreet", details.PresentStreet);
                parameters.Add("RoleId", details.RoleId);
                parameters.Add("DOJ", details.DOJ);
                parameters.Add("DOB", details.DOB);
                parameters.Add("DeptId", details.DeptId);
                parameters.Add("ExpInYear", details.ExpInYear);
                parameters.Add("IsActive", details.IsActive);
                parameters.Add("UserId", UserId);
                parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
               
                dbConnection.Query<int>("RegisterUser_InsertUpdate", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);

                return parameters.Get<int>("@Result");
            }
            catch(Exception)
            {
                throw;
            }
        }

        public IEnumerable<RoleMaster> GetRolesDD()
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("Type", "Get_RolesDD");
                return dbConnection.Query<RoleMaster>("Get_DropDownValue", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IEnumerable<DeptMaster> GetDeptDD()
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("Type", "Get_DeptDD");
                return dbConnection.Query<DeptMaster>("Get_DropDownValue", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<int> CreateShiftBasedOnEmpId(WorkPlanner planner, string userId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@EmpId", planner.EmpId);  // or employee id if available
            parameters.Add("@IsRecurring", planner.isRecurring);
            parameters.Add("@RecurrenceType", planner.recurrenceType);
            parameters.Add("@RecurringStart", planner.recurringStart);
            parameters.Add("@RecurringEnd", planner.recurringEnd);
            parameters.Add("@MaxPatients", planner.maxPatients);
            parameters.Add("@Title", planner.title);
            parameters.Add("@startTime", planner.startTime);
            parameters.Add("@endTime", planner.endTime);
            parameters.Add("@clinicid", planner.clinicid);
            parameters.Add("@locationid", planner.locationid);
            parameters.Add("@Type", planner.Type);
            parameters.Add("@SelectedDays", planner.SelectedDays != null
                ? string.Join(",", planner.SelectedDays)
                : null);

            parameters.Add("@SelectedDates", planner.SelectedDate != null
                ? string.Join(",", planner.SelectedDate)
                : null);

            parameters.Add("@CreatedBy", userId);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await dbConnection.ExecuteScalarAsync<int>(
                "CreateShiftBasedOnEmpId",
                parameters,
                commandType: CommandType.StoredProcedure
            );

            return parameters.Get<int>("@Result");
        }

        public async Task<IEnumerable<WorkPlanner>> GetShiftById(string EmpId, string Type)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", EmpId);
            parameters.Add("Type", Type);
            return await dbConnection.QueryAsync<WorkPlanner>("Masters_GetDetails", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<TextValue>> Get_TextValueDD(string Type,string Id = null, string Id2 = null)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", Id);
            parameters.Add("Id2", Id2);
            parameters.Add("Type", Type);
            return await dbConnection.QueryAsync<TextValue>("Get_DropDownValue", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }
        public async Task<IEnumerable<TestCategory>> Get_TestCategory()
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", "GetAllTestCategoryMaster");
            return await dbConnection.QueryAsync<TestCategory>("Masters_GetDetails", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }
        public async Task<IEnumerable<MedicalTest>> Get_MedicalTestMaster()
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", "GetAllMedicalTestMaster");
            return await dbConnection.QueryAsync<MedicalTest>("Masters_GetDetails", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<PharmacyInventory>> Get_PharmacyInventory()
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", "GetAllMedicines");
            return await dbConnection.QueryAsync<PharmacyInventory>("Masters_GetDetails", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<DrugCategory>> Get_DrugCategory()
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", "GetAllPharmacyCategoryMaster");
            return await dbConnection.QueryAsync<DrugCategory>("Masters_GetDetails", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<MenuMaster>> GetMenuById(string Type, string Portal = null,string Id = null)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("Portal", Portal);
            parameters.Add("Id", Id);
            return await dbConnection.QueryAsync<MenuMaster>("Get_Menus", parameters, commandTimeout: 10200, commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task<int> update_Usermenus(MenuMaster menu, string UserId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@JsonData", menu.JsonData);  // or employee id if available
            parameters.Add("@UserId", UserId);
            parameters.Add("@RoleId", menu.RoleId);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await dbConnection.ExecuteScalarAsync<int>(
                "MenuAccessRights_InsertUpdate",
                parameters,
                commandType: CommandType.StoredProcedure
            );

            return parameters.Get<int>("@Result");
        }
        public async Task<(int Result, string ResultMessage)> RoleMaster_InsertUpdate(RoleMaster role)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@RoleId", role.RoleId); 
            parameters.Add("@RoleName", role.RoleName);
            parameters.Add("@PortalType", role.PortalType);
            parameters.Add("@IsActive", role.IsActive);
            parameters.Add("@CreatedBy", role.CreatedBy);
            parameters.Add("@Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@ResultMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 10000);
            await dbConnection.QueryAsync<(int, string)>(
                "RoleMaster_InsertUpdate",
                parameters,
                commandType: CommandType.StoredProcedure
            );

            return (
                parameters.Get<int>("@Result"),
                parameters.Get<string>("@ResultMessage")
            );
        }

        public async Task<int> UpdateUserPassword(UserPassword employee)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Password", employee.Password);
            parameters.Add("@EmpId", employee.EmpId);
            parameters.Add("@ModifiedBy", employee.CreatedBy);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await dbConnection.ExecuteScalarAsync<int>(
                "UpdateUser_Password",
                parameters,
                commandType: CommandType.StoredProcedure
            );

            return parameters.Get<int>("@Result");
        }
    }
}
