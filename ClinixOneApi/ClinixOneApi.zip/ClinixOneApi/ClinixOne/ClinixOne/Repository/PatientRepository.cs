﻿using ClinixOne.Interface;
using ClinixOne.Model;
using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;

namespace ClinixOne.Repository
{
    public class PatientRepository: IPatientRepository
    {
        private readonly IDbConnection dbConnection;    
        public PatientRepository(string connectionString)
        {
            dbConnection = new SqlConnection(connectionString);
        }

        public async Task<(int Result, string StatusMessage)> Register_Patient(PatientDetails details, string EmpId = null)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("PatientId", details.PatientId);
            parameters.Add("FullName", details.FullName);
            parameters.Add("PatientPhoto", details.ProfilePic);
            parameters.Add("Gender", details.Gender);
            parameters.Add("DOB", details.DOB);
            parameters.Add("MaritialStatus", details.MaritalStatus);
            parameters.Add("BloodGroup", details.BloodGroup);
            parameters.Add("Email", details.Email);
            parameters.Add("MobNumber", details.MobNumber);
            parameters.Add("Religion", details.Religion);
            parameters.Add("Occupation", details.Occupation);
            parameters.Add("Street", details.Street);
            parameters.Add("State", details.StateId);
            parameters.Add("Country", details.CountryId);
            parameters.Add("Nationality", details.Nationality);
            parameters.Add("City", details.City);
            parameters.Add("Pincode", details.Pincode);
            parameters.Add("Password", details.Password);
            parameters.Add("IsActive", details.IsActive);
            parameters.Add("UserId", EmpId);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("StatusMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 10000);
            await dbConnection.QueryAsync<(int, string)>("RegisterPatient_InsertUpdate", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);

            return (
                    parameters.Get<int>("Result"),
                    parameters.Get<string>("StatusMessage")
            );
        }
        public async Task<IEnumerable<DoctorsByShift>> GetDoctorsByShift(DoctorsByShift doctors)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@date", doctors.Date);
            parameters.Add("@deptid", doctors.DeptId);
            parameters.Add("@Type", doctors.Type);
            parameters.Add("@monthname", doctors.MonthName);
            parameters.Add("@empid", doctors.DoctorId);
            return await dbConnection.QueryAsync<DoctorsByShift>("Get_DoctorsByShift", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
        }
        public async Task<int> CnfAptBooking(Appointments apt)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("AptId", apt.AptId);
            parameters.Add("PatientId", apt.PatientId);
            parameters.Add("DptId", apt.DptId);
            parameters.Add("ClinicId", apt.ClinicId);
            parameters.Add("LocationId", apt.LocationId);
            parameters.Add("DoctorId", apt.DoctorId);
            parameters.Add("AptDate", apt.AptDate);
            parameters.Add("Fee", apt.Fee);
            parameters.Add("Remark", apt.Remarks);
            parameters.Add("Type", apt.Type);
            parameters.Add("UserId", apt.CreatedBy);
            parameters.Add("Result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            await dbConnection.ExecuteScalarAsync<int>("Appointments_Manage",parameters,commandType: CommandType.StoredProcedure);

            return parameters.Get<int>("@Result");
        }
        public async Task<IEnumerable<AppointmentLetter>> Get_AppointmentLetter(Appointments apt)
        {
            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("@AptId", apt.AptId);
            parameters.Add("@Type", apt.Type);
            parameters.Add("@PatientId", apt.PatientId);
            parameters.Add("@DoctorId", apt.DoctorId);
            parameters.Add("@FromDate", apt.FromDate);
            parameters.Add("@ToDate", apt.ToDate);
            return await dbConnection.QueryAsync<AppointmentLetter>("Get_Appointments", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);

        }
        public async Task<PatientDetails> Get_PatientById(string PatientId, string Type)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Type", Type);
            parameters.Add("Id", PatientId);
            return await dbConnection.QueryFirstAsync<PatientDetails>("Masters_GetDetails", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 1200);
        }
    }
}
