import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LandingPage from "./pages/Landing/LandingPage"
import LandingLayout from "./Layouts/LandingLayout";
import PatientPortal from "./pages/Landing/PatientPortal";
import HospitalPortal from "./pages/Landing/HospitalPortal";
import RegisterPatient from "./pages/Landing/RegisterPatient";
import 'react-datepicker/dist/react-datepicker.css';
import DashboardPage from "./pages/Hospital/DashboardPage";
import { default as PatientDash } from "./pages/Patient/DashboardPage";
import HospitalLayout from "./Layouts/HospitalLayout";
import CasestudyPage from "./pages/Hospital/CasestudyPage";
import UserMaster from "./pages/Hospital/UserMaster";
import RegisterUser from "./pages/Hospital/RegisterUser";
import { LoaderProvider } from "./Context/LoaderProvider";
import { CustomAlertProvider } from "./Context/CustomAlertProvider";
import ConfirmProvider from "./Context/ConfirmProvider";
import { Toaster } from "sonner";
import ProtectedRoute from "./Redux/ProtectedRoute";
import WorkManagement from "./pages/Hospital/WorkManagement";
import ScheduleWork from "./pages/Hospital/ScheduleWork";
import TestPage from "./pages/Hospital/TestPage";
import PatientLayout from "./Layouts/PatientLayout";
import BookappointmentPage from "./pages/Patient/BookappointmentPage";
import MyAppointments from "./pages/Patient/MyAppointments";
import PatientProfile from "./pages/Patient/PatientProfiel";
import PatientList from "./pages/Hospital/PatientList";
import TodayAppointmentsPage from "./pages/Hospital/TodayAppointmentsPage";
import ApptManagement from "./pages/Hospital/ApptManagement";
import ConsultationPage from "./pages/Hospital/ConsultationPage";
import Billing from "./pages/Hospital/Billing";
import Labtest from "./pages/Hospital/Labtest";
import RoleMaster from "./pages/Hospital/RoleMaster";
import MenuAccessPage from "./pages/Hospital/MenuAccessPage";
import LabReportPage from "./pages/Patient/LabReportPage";
import UserProfile from "./pages/Hospital/UserProfile";

function App() {
  return (
    <LoaderProvider>
      <ConfirmProvider>
      <CustomAlertProvider>
        <Toaster richColors position="top-right" />
        <Router>
          <Routes>
            {/* Landing Pages */}
            <Route path="/" element={<LandingLayout />}>
              <Route index element={<LandingPage />} />
              <Route path="/patientportal" element={<PatientPortal />} />
              <Route path="/hospitalportal" element={<HospitalPortal />} />
              <Route path="/RegisterPatient" element={<RegisterPatient />} />
            </Route>

            {/* Hospital Portal */}
            <Route path="/hospital" element={<ProtectedRoute Type={'Hospital'} />}>
              <Route element={<HospitalLayout />}>
                <Route index element={<DashboardPage />} />
                <Route path="dashboard" element={<DashboardPage />} />
                <Route path="appointments/case-study/:id" element={<CasestudyPage />} />
                <Route path="usermaster" element={<UserMaster />} />
                <Route path="rolemaster" element={<RoleMaster />} />
                <Route path="menuaccess/:roleId/:portalType/:roleName" element={<MenuAccessPage />} />
                <Route path="registeruser" element={<RegisterUser />} />
                <Route path="registeruser/edit/:id" element={<RegisterUser />} />
                <Route path="planner" element={<WorkManagement />} />
                <Route path="scheulework/:empId" element={<ScheduleWork />} />
                <Route path="testpage" element={<TestPage />} />
                <Route path="patients" element={<PatientList />} />
                <Route path="todayappointment" element={<TodayAppointmentsPage />} />
                <Route path="manageappt" element={<ApptManagement />} />
                <Route path="consultation" element={<ConsultationPage />} />
                <Route path="billing" element={<Billing />} />
                <Route path="labtest" element={<Labtest />} />
                <Route path="userprofile" element={<UserProfile />} />
              </Route>
            </Route>

            {/* Patient Portal */}
            <Route path="/patient" element={<ProtectedRoute Type={'Patient'} />}>
              <Route element={<PatientLayout />}>
                <Route index element={<PatientDash />} />
                <Route path="dashboard" element={<PatientDash />} />
                <Route path="bookappointment" element={<BookappointmentPage />} />
                <Route path="myappointment" element={<MyAppointments />} />
                <Route path="myprofile" element={<PatientProfile />} />
                <Route path="labreports" element={<LabReportPage />} />
              </Route>
            </Route>
          </Routes>
        </Router>

      </CustomAlertProvider>
      </ConfirmProvider>
    </LoaderProvider>
  )
}

export default App
