import { createContext, useState, useContext, useCallback } from "react";
import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const ConfirmContext = createContext(null);

export function useConfirm() {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error("useConfirm must be used within ConfirmProvider");
  return ctx;
}

export default function ConfirmProvider({ children }) {
  const [open, setOpen] = useState(false);
  const [resolver, setResolver] = useState(null);
  const [options, setOptions] = useState({
    title: "Are you sure?",
    description: "This action cannot be undone.",
    confirmText: "Confirm",
    cancelText: "Cancel",
    intent: "default",
  });

  const confirm = useCallback((opts = {}) => {
    return new Promise((resolve) => {
      setOptions((prev) => ({ ...prev, ...opts }));
      setResolver(() => resolve);
      setOpen(true);
    });
  }, []);

  const handleConfirm = () => {
    resolver?.(true);
    setOpen(false);
  };

  const handleCancel = () => {
    resolver?.(false);
    setOpen(false);
  };

  const handleOpenChange = (val) => {
    if (!val) setTimeout(() => setResolver(null), 200);
    setOpen(val);
  };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}

      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-md p-0 overflow-hidden
        fixed top-40">
          <motion.div
            initial={{ opacity: 0, scale: 0.98, y: 6 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.98, y: 6 }}
            transition={{ duration: 0.15 }}
            className="flex flex-col space-y-4 p-6 bg-background"
          >
            {/* Header */}
            <div className="flex items-start justify-between">
              <DialogHeader className="p-0">
                <DialogTitle className="text-lg font-semibold">
                  {options.title}
                </DialogTitle>
                {options.description && (
                  <DialogDescription className="text-sm text-muted-foreground mt-1">
                    {options.description}
                  </DialogDescription>
                )}
              </DialogHeader>
            </div>

            {/* Footer */}
            <DialogFooter className="flex justify-end gap-2 pt-4">
              <Button variant="ghost" onClick={handleCancel}
                className={'bg-yellow-400'}
              >
                {options.cancelText}
              </Button>
              <Button
                onClick={handleConfirm}
                className={
                  options.intent === "danger"
                    ? "bg-red-400 text-destructive-foreground hover:bg-destructive/90"
                    : ""
                }
              >
                {options.confirmText}
              </Button>
            </DialogFooter>
          </motion.div>
        </DialogContent>
      </Dialog>
    </ConfirmContext.Provider>
  );
}
