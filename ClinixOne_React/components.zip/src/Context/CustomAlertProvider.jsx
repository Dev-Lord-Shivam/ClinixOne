import { createContext, useContext, useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogOverlay,
} from "@/components/ui/dialog"; // adjust path as needed

const CustomAlertContext = createContext(null);

export const CustomAlertProvider = ({ children }) => {
  const [alertProps, setAlertProps] = useState({
    isOpen: false,
    title: "",
    description: "",
    content: null,
  });

  const showAlert = useCallback(({ title, description, content = null }) => {
    setAlertProps({
      isOpen: true,
      title,
      description,
      content,
    });
  }, []);

  const closeAlert = () => {
    setAlertProps(prev => ({ ...prev, isOpen: false }));
  };

  return (
    <CustomAlertContext.Provider value={showAlert}>
      {children}

      <Dialog open={alertProps.isOpen} onOpenChange={closeAlert}>
        <DialogOverlay className="fixed inset-0 bg-black/40 z-50" />
        <DialogContent className="max-w-sm rounded shadow-lg bg-white p-6">
          <DialogHeader>
            <DialogTitle>{alertProps.title}</DialogTitle>
            <DialogDescription className='text-md'>{alertProps.description}</DialogDescription>
          </DialogHeader>

          {alertProps.content && (
            <div className="mt-4">{alertProps.content}</div>
          )}
        </DialogContent>
      </Dialog>
    </CustomAlertContext.Provider>
  );
};

export const useCustomAlert = () => {
  const context = useContext(CustomAlertContext);
  if (!context) {
    throw new Error("useCustomAlert must be used within a CustomAlertProvider");
  }
  return context;
};
