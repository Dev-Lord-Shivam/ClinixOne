// axiosInstance.js
import axios from "axios";

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  withCredentials: true
});
   // const dispatch = useDispatch()
// 🔹 Add interceptor for responses
axiosInstance.interceptors.response.use(
  (response) => response, // success → pass through
  (error) => {
    if (error.response) {
      const { status, data } = error.response;

      // Handle token expired
      if (status === 401 && data?.error_code === "TOKEN_EXPIRED") {
        // Clear token
        // dispatch(clearAuth());
        localStorage.removeItem("token");
        window.location.href = "/hospitalportal";
        
      }

      // Handle unauthorized (no token/invalid)
      if (status === 401 && data?.error_code === "UNAUTHORIZED") {
       // dispatch(clearAuth());  
        localStorage.removeItem("token");
        window.location.href = "/hospitalportal";
      }
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;
