import { toast } from "sonner";
import { useCallback } from "react";

const useShowToast = () => {
  const showToast = useCallback((variant, title, description) => {
    // variant: "default", "success", "error", "warning"
    if (toast[variant]) {
      toast[variant](title, { description });
    } else {
      toast(title, { description });
    }
  }, []);

  return showToast;
};

export default useShowToast;
