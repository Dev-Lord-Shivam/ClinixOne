import { Outlet, Link, useNavigate } from "react-router-dom";
import {
    NavigationMenu,
    NavigationMenuList,
    NavigationMenuItem,
    NavigationMenuTrigger,
    NavigationMenuContent,
    NavigationMenuLink
} from '@/components/ui/navigation-menu';

import {
    Avatar,
    AvatarImage,
    AvatarFallback,
} from '@/components/ui/avatar';
import {
    DropdownMenu,
    DropdownMenuTrigger,
    DropdownMenuContent,
    DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { Bell } from "lucide-react";
import { Input } from "@/components/ui/input"; // make sure input is added via ShadCN
import { useDispatch } from "react-redux";
import axios from "axios";
import { clearAuth } from "../Redux/slices/authSlice";
import { useEffect, useState } from "react";
import { fetchDepartments } from "../Redux/slices/departmentSlice";
import { useLoader } from "../Context/LoaderProvider";
import useShowToast from "../Context/useShowToast";
import axiosInstance from "../Context/axiosInstance";

// const menuConfig = [
//     {
//         title: 'Dashboard',
//         link: '/hospital/dashboard',
//     },
//     {
//         title: 'Admin',
//         submenu: [
//             { label: 'Users', link: '/hospital/usermaster' },
//             { label: 'Roles', link: '/hospital/rolemaster' },
//             { label: 'Departments', link: '/hospital/admin/departments' },
//             { label: 'Pharmacy', link: '/hospital/admin/units' },
//             { label: 'Shift Management', link: '/hospital/planner' },
//             { label: 'Lab', link: '/hospital/admin/units' },
//             { label: 'Units & Block', link: '/hospital/admin/units' },
//         ]
//     },
//     {
//         title: 'Appointments',
//         submenu: [
//             { label: 'Today\'s Appointments', link: '/hospital/todayappointment' },
//             { label: 'All Appointments', link: '/hospital/appointments/all' },
//             { label: 'Appointment Management', link: '/hospital/manageappt' },
//         ],
//     },
//     {
//         title: 'Patients',
//         submenu: [
//             { label: 'Patients Management', link: '/hospital/patients' },
//             { label: 'Add New Patient', link: '/hospital/patients/new' },
//         ],
//     },
//     {
//         title: 'Hospital',
//         submenu: [
//             { label: 'Billing', link: '/hospital/billing' },
//         ],
//     },
//     {
//         title: 'Laboratory',
//         submenu: [
//             { label: 'Reports & Tests', link: '/hospital/labtest' },
//         ],
//     },
// ];



const HospitalLayout = () => {

    const dispatch = useDispatch()
    const navigate = useNavigate()
    const showToast = useShowToast()
    const [menuConfig, setMenuConfig] = useState(null);
    const { showLoader, hideLoader } = useLoader()
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const userInfo = JSON.parse(localStorage.getItem('user'))
    const token = localStorage.getItem("token");

    const user = {
        name: userInfo.empName,
        role: userInfo.roleName,
        avatarUrl: userInfo.empPhoto, // Optional: link to user's profile picture
    };

    const LogoutUser = async () => {
        try {
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Account/Logout`
            const response = await axios.post(url);

            if (response.status == 200) {
                // Clear Redux store and localStorage
                dispatch(clearAuth());
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                navigate("/hospitalportal");
            }
            else {
                dispatch(clearAuth());
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                navigate("/hospitalportal");
            }
        } catch (error) {
            console.log(error)
            dispatch(clearAuth());
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            navigate("/hospitalportal");
        }
    }

    useEffect(() => {
        getUserMenus()
    }, [userInfo.roleId])

    useEffect(() => {
        dispatch(fetchDepartments())
    }, [dispatch])

    const getUserMenus = async () => {
        try {
            showLoader();

            const url = `${baseUrl}/api/Master/GetMenus`;
            const res = await axiosInstance.get(url, {
                params: {
                    Type: "Get_UserMenusByRole",
                    Id: userInfo.roleId,
                },
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            });
       
            if (res.status === 200) {
                console.log(res)
                const menuLevel1 = res.data.filter(
                    m => m.menuLevel === 1 && m.isActive === true
                );

                const menuLevel2 = res.data.filter(
                    m => m.menuLevel === 2 && m.isActive === true
                );

                setMenuConfig({
                    menuLevel1,
                    menuLevel2
                });

                console.log(menuLevel1, menuLevel2);

            }
            else {
                showToast("error", "Error!", "Failed to fetch menus");
            }

        } catch (error) {
            showToast("error", "Error!", error.message || "Something went wrong");
        } finally {
            hideLoader();
        }
    };


    return (
        <div className="min-h-screen flex flex-col">
            {/* Top Header */}
            <header className="fixed top-0 left-0 right-0 z-50 bg-blue-100 shadow px-6 py-2 flex justify-between items-center">
                <div className="text-xl font-bold text-blue-600">ClinixOne</div>
                <div className="flex items-center gap-6">
                    {/* Search bar */}
                    <Input
                        type="search"
                        placeholder="Search..."
                        className="w-64 bg-white rounded border border-gray-300"
                    />

                    {/* Notification icon */}
                    <button className="relative">
                        <Bell className="w-5 h-5 text-gray-600" />
                        <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-red-500"></span>
                    </button>

                    {/* User menu */}
                    <DropdownMenu>
                        <DropdownMenuTrigger className="flex items-center space-x-2">
                            <Avatar>
                                <AvatarImage src={user.avatarUrl} />
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm font-medium">{user.name} | {user.role}</span>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => navigate('/hospital/userprofile')}>Profile</DropdownMenuItem>
                            <DropdownMenuItem onClick={LogoutUser}>Logout</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </header>

            {/* Sub Navigation Bar */}
            <nav className="shadow px-2 bg-blue-700 fixed top-[50px] left-0 right-0 z-40 shadow px-2 bg-blue-600">
                <NavigationMenu viewport={false}>
                    <NavigationMenuList>
                        {menuConfig?.menuLevel1?.map(level1 => {

                            const children = menuConfig?.menuLevel2?.filter(
                                m => m.parentMenuId === level1.menuId
                            );

                            return (
                                <NavigationMenuItem key={level1?.menuId}>
                                    {children.length > 0 ? (
                                        <>
                                            <NavigationMenuTrigger className='!bg-blue-700 text-white hover:!bg-blue-700 !text-white'>
                                                {level1?.displayName}
                                            </NavigationMenuTrigger>

                                            <NavigationMenuContent className="!bg-blue-700 !text-white !text-xs rounded shadow-lg z-40">
                                                <ul className="grid w-[220px] gap-2 p-2">
                                                    {children.map(child => (
                                                        <li key={child?.menuId}>
                                                            <NavigationMenuLink asChild>
                                                                <Link
                                                                    to={child?.menuURL}
                                                                   
                                                                >
                                                                    {child?.displayName}
                                                                </Link>
                                                            </NavigationMenuLink>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </NavigationMenuContent>
                                        </>
                                    ) : (
                                        <Link
                                            to={level1?.menuURL}
                                            className="text-white font-bold hover:bg-blue-600 rounded px-3 py-2 text-sm"
                                        >
                                            {level1?.displayName}
                                        </Link>
                                    )}
                                </NavigationMenuItem>
                            );
                        })}
                    </NavigationMenuList>
                </NavigationMenu>
            </nav>

            {/* Page Content */}
            <main className="flex-1 p-4 bg-gray-200 pt-25">
                <Outlet />
            </main>
        </div>
    );
};

export default HospitalLayout;
