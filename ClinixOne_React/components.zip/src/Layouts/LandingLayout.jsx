import { Button } from "@/components/ui/button";
import { Outlet, NavLink } from "react-router-dom";
import {
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  MapPin,
  Phone,
  Mail,
} from "lucide-react";

const LandingLayout = () => (
  <div className="min-h-screen bg-gradient-to-r from-blue-100 via-white to-blue-300">
    <nav className="h-10 px-4 flex items-center justify-between shadow">
      <div className="text-xl font-bold text-blue-700">ClinixOne</div>
      <div className="space-x-2">
        <NavLink
          to="/"
            className={({ isActive }) =>
            isActive ? "text-blue-800" : ""
          }
        >
          <Button variant="ghost" size="sm">Home</Button>
        </NavLink>
        <NavLink
          to="/patientportal"
          className={({ isActive }) =>
            isActive ? "text-blue-800" : ""
          }
        >
          <Button variant="ghost" size="sm">Patient Portal</Button>
        </NavLink>
        <NavLink
          to="/hospitalportal"
          className={({ isActive }) =>
            isActive ? "text-blue-800" : ""
          }
        >
          <Button variant="ghost" size="sm">Hospital Portal</Button>
        </NavLink>
        <NavLink
          to="/about"
          className={({ isActive }) =>
            isActive ? "text-blue-800" : ""
          }
        >
          <Button variant="ghost" size="sm">About Us</Button>
        </NavLink>
      </div>
    </nav>

    <main className="">
      <Outlet />
    </main>
    <Footar />
  </div>
);

const Footar = () => {
  return (
    <footer className="bg-blue-900 text-white py-10">
      <div className="container mx-auto px-6 grid md:grid-cols-4 gap-10">
        {/* Company Info */}
        <div>
          <h3 className="text-2xl font-bold mb-4">MediSphare</h3>
          <p className="text-sm text-gray-300">
            Your trusted partner for seamless hospital management and patient care.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-lg font-semibold mb-3">Quick Links</h4>
          <ul className="space-y-2 text-sm text-gray-300">
            <li>
              <a href="/" className="hover:underline">Home</a>
            </li>
            <li>
              <a href="/Appointments/Create" className="hover:underline">Book Appointment</a>
            </li>
            <li>
              <a href="#Specialities" className="hover:underline">Specialities</a>
            </li>
            <li>
              <a href="#services" className="hover:underline">Services</a>
            </li>
          </ul>
        </div>

        {/* Contact Info */}
        <div>
          <h4 className="text-lg font-semibold mb-3">Contact Us</h4>
          <ul className="text-sm text-gray-300 space-y-2">
            <li className="flex items-center gap-2">
              <MapPin className="w-4 h-4" /> 123 Health Street, Wellness City
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4" /> +1 234 567 890
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-4 h-4" /> info@medisphare.com
            </li>
          </ul>
        </div>

        {/* Social Media */}
        <div>
          <h4 className="text-lg font-semibold mb-3">Follow Us</h4>
          <div className="flex space-x-4">
            <a href="#" className="text-gray-300 hover:text-white">
              <Facebook className="w-5 h-5" />
            </a>
            <a href="#" className="text-gray-300 hover:text-white">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="text-gray-300 hover:text-white">
              <Linkedin className="w-5 h-5" />
            </a>
            <a href="#" className="text-gray-300 hover:text-white">
              <Instagram className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="mt-10 text-center text-gray-400 text-sm border-t border-gray-700 pt-4">
        &copy; {new Date().getFullYear()} MediSphare. All rights reserved.
      </div>
    </footer>
  )
}

export default LandingLayout;
