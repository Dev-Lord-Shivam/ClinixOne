import { Outlet, Link, useNavigate } from "react-router-dom";
import {
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuTrigger,
  NavigationMenuContent,
  NavigationMenuLink,
} from "@/components/ui/navigation-menu";

import {
  Avatar,
  AvatarImage,
  AvatarFallback,
} from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Bell } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useDispatch } from "react-redux";
import axios from "axios";
import { clearPatientAuth } from "../Redux/slices/authPatientSlice";
import { useEffect, useState } from "react";
import { fetchDepartments } from "../Redux/slices/departmentSlice";
import { useLoader } from "../Context/LoaderProvider";
import useShowToast from "../Context/useShowToast";
import axiosInstance from "../Context/axiosInstance";

// const menuConfig = [
//   {
//     title: "Dashboard",
//     link: "/patient/dashboard",
//   },
//   {
//     title: "My Profile",
//     link: "/patient/myprofile",
//   },
//   {
//     title: "Appointments",
//     submenu: [
//       { label: "Book Appointments", link: "/patient/bookappointment" },
//       { label: "My Appointments", link: "/patient/myappointment" },
//     ],
//   },
//   {
//     title: "Reports",
//     submenu: [
//       { label: "Lab Reports", link: "/patient/reports/lab" },
//       { label: "Discharge Summary", link: "/patient/reports/discharge" },
//     ],
//   },
// ];

const PatientLayout = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const showToast = useShowToast()
  const [menuConfig, setMenuConfig] = useState(null);
  const { showLoader, hideLoader } = useLoader()
  const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
  const userInfo = JSON.parse(localStorage.getItem("patient"));
  const token = localStorage.getItem("token");

  useEffect(() => {
    getUserMenus()
  }, [userInfo.roleId])

  const getUserMenus = async () => {
    try {
      showLoader();
      console.log(userInfo.roleId)
      const url = `${baseUrl}/api/Master/GetMenus`;
      const res = await axiosInstance.get(url, {
        params: {
          Type: "Get_UserMenusByRole",
          Id: userInfo.roleId,
        },
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      if (res.status === 200) {
        console.log(res)
        const menuLevel1 = res.data.filter(
          m => m.menuLevel === 1 && m.isActive === true
        );

        const menuLevel2 = res.data.filter(
          m => m.menuLevel === 2 && m.isActive === true
        );

        setMenuConfig({
          menuLevel1,
          menuLevel2
        });

        console.log(menuLevel1, menuLevel2);

      }
      else {
        showToast("error", "Error!", "Failed to fetch menus");
      }

    } catch (error) {
      showToast("error", "Error!", error.message || "Something went wrong");
    } finally {
      hideLoader();
    }
  };

  const LogoutUser = async () => {
    try {
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Account/Logoutpatient`;
      const response = await axios.post(url);

      if (response.status === 200) {
        dispatch(clearPatientAuth());
        localStorage.removeItem("patienttoken");
        localStorage.removeItem("patient");
        navigate("/patientportal");
      } else {
        dispatch(clearPatientAuth());
        localStorage.removeItem("patienttoken");
        localStorage.removeItem("patient");
        navigate("/patientportal");
      }
    } catch (error) {
      console.log(error);
      dispatch(clearPatientAuth());
      localStorage.removeItem("patienttoken");
      localStorage.removeItem("patient");
      navigate("/patientportal");
    }
  };

  useEffect(() => {
    dispatch(fetchDepartments());
  }, [dispatch]);

  const user = {
    patientId: userInfo.patientId,
    name: userInfo.fullName,
    role: "Patient",
    email: userInfo.email,
    avatarUrl: userInfo.profilePic,
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-green-100 shadow px-6 py-2 flex justify-between items-center">
        <div className="text-xl font-bold text-green-700">ClinixOne - Patient Portal</div>
        <div className="flex items-center gap-6">
          {/* Search bar */}
          <Input
            type="search"
            placeholder="Search..."
            className="w-64 bg-white rounded border border-gray-300"
          />

          {/* Notification icon */}
          <button className="relative">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-red-500"></span>
          </button>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center space-x-2">
              <Avatar>
                <AvatarImage src={user.avatarUrl} />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">
                {user.name} | {user.role}
              </span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => navigate('/patient/myprofile')}>Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={LogoutUser}>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Sub Navigation Bar */}
      <nav className="shadow px-2 bg-green-700 fixed top-[50px] left-0 right-0 z-40">
        <NavigationMenu viewport={false}>
          <NavigationMenuList>
            {menuConfig?.menuLevel1?.map(level1 => {

              const children = menuConfig?.menuLevel2?.filter(
                m => m.parentMenuId === level1.menuId
              );

              return (
                <NavigationMenuItem key={level1?.menuId}>
                  {children.length > 0 ? (
                    <>
                      <NavigationMenuTrigger className='!bg-green-700 text-white hover:!bg-green-700 !text-white'>
                        {level1?.displayName}
                      </NavigationMenuTrigger>

                      <NavigationMenuContent className="!bg-green-700 !text-white !text-xs rounded shadow-lg z-40">
                        <ul className="grid w-[220px] gap-2 p-2">
                          {children.map(child => (
                            <li key={child?.menuId}>
                              <NavigationMenuLink asChild>
                                <Link
                                  to={child?.menuURL}

                                >
                                  {child?.displayName}
                                </Link>
                              </NavigationMenuLink>
                            </li>
                          ))}
                        </ul>
                      </NavigationMenuContent>
                    </>
                  ) : (
                    <Link
                      to={level1?.menuURL}
                      className="text-white font-bold hover:bg-green-600 rounded px-3 py-2 text-sm"
                    >
                      {level1?.displayName}
                    </Link>
                  )}
                </NavigationMenuItem>
              );
            })}
          </NavigationMenuList>
        </NavigationMenu>
        {/* <NavigationMenu viewport={false}>
          <NavigationMenuList>
            {menuConfig.map((item, index) => (
              <NavigationMenuItem key={index}>
                {item.submenu ? (
                  <>
                    <NavigationMenuTrigger className="!bg-green-700 text-white hover:!bg-green-700 !text-white">
                      {item.title}
                    </NavigationMenuTrigger>
                    <NavigationMenuContent className="!bg-green-700 !text-white !text-xs rounded shadow-lg z-40">
                      <ul className="grid w-[200px] gap-2">
                        {item.submenu.map((subItem, idx) => (
                          <li key={idx}>
                            <NavigationMenuLink asChild>
                              <Link to={subItem.link}>{subItem.label}</Link>
                            </NavigationMenuLink>
                          </li>
                        ))}
                      </ul>
                    </NavigationMenuContent>
                  </>
                ) : (
                  <Link
                    to={item.link}
                    className="text-white font-bold hover:bg-green-600 rounded px-3 py-2 text-sm"
                  >
                    {item.title}
                  </Link>
                )}
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu> */}
      </nav>

      {/* Page Content */}
      <main className="flex-1 p-4 bg-gray-100 pt-24">
        <Outlet />
      </main>
    </div>
  );
};

export default PatientLayout;
