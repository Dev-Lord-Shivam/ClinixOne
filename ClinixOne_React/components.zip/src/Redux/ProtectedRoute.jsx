import { useSelector } from 'react-redux';
import { Navigate, Outlet } from 'react-router-dom';

const ProtectedRoute = ({Type}) => {
  if(Type == 'Hospital'){
    const token = useSelector((state) => state.auth.token);
    return token ? <Outlet /> : <Navigate to="/hospitalportal" replace />;
  }

  if(Type == 'Patient'){
    const token = useSelector((state) => state.authPatient.patienttoken);
    return token ? <Outlet /> : <Navigate to="/patientportal" replace />;
  }

};

export default ProtectedRoute;
