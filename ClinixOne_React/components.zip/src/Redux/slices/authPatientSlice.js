import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    patient: JSON.parse(localStorage.getItem('patient')) || null,
    patienttoken: localStorage.getItem('patienttoken') || null,
};

const authPatientSlice = createSlice({
    name: 'patientauth',
    initialState,
    reducers: {
        setPatientAuth: (state, action) => {
            console.log(action)
            const { patienttoken, patient } = action.payload;
            localStorage.setItem("patienttoken", patienttoken);
            localStorage.setItem("patient", JSON.stringify(patient));
            state.patienttoken = patienttoken;
            state.patient = patient;
        },
        clearPatientAuth: (state) => {
            localStorage.removeItem("patienttoken");
            localStorage.removeItem("patient");
            state.patienttoken = null;
            state.patient = null;
        },
    },
});

export const { setPatientAuth, clearPatientAuth } = authPatientSlice.actions;
export default authPatientSlice.reducer;
