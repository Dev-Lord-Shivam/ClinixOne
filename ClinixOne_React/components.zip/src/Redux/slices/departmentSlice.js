import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async thunk to fetch departments
export const fetchDepartments = createAsyncThunk('departments/fetchDepartments', async () => {
  const token = localStorage.getItem("token");
  const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/Master/GetDeptDD`); // API endpoint
  console.log(response)
  return response.data;
});

const departmentSlice = createSlice({
  name: 'departments',
  initialState: {
    deptlist: [],
    deptloading: false,
    error: null,
  },
  reducers: {
    addDepartment: (state, action) => {
      state.deptlist.push(action.payload); // Update store manually if needed
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDepartments.pending, (state) => {
        state.deptloading = true;
      })
      .addCase(fetchDepartments.fulfilled, (state, action) => {
        state.deptloading = false;
        state.deptlist = action.payload;
      })
      .addCase(fetchDepartments.rejected, (state, action) => {
        state.deptloading = false;
        state.error = action.error.message;
      });
  }
});

export const { addDepartment } = departmentSlice.actions;
export default departmentSlice.reducer;
