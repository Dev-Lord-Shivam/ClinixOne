// axiosConfig.js
import axios from 'axios';
import { toast } from 'sonner'; // or react-toastify, etc.

const api = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL,
    withCredentials: true,
});

api.interceptors.request.use((config) => {
    const token = localStorage.getItem("token");
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error) => Promise.reject(error));

api.interceptors.response.use((response) => response, (error) => {

    if (error.response?.status === 401 && error.response?.data?.error_code === 'SESSION_EXPIRED') {
        localStorage.clear();
        sessionStorage.clear();

        fetch(`${import.meta.env.VITE_API_BASE_URL}/api/Account/Logout`, {
            method: 'POST',
            credentials: 'include'
        }).finally(() => {
            toast.warning("Session expired. Please log in again."); // ✅ Use toast here
             setTimeout(() => {
                  window.location.href = "/hospitalportal";
             }, 2000);
        });
    }

    return Promise.reject(error);
});

export default api;
