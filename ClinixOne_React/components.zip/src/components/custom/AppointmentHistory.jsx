import  { useEffect, useState } from 'react'
import axiosInstance from "../../Context/axiosInstance";
import { DataTable } from "../../components/custom/DataTable";
import useShowToast from "../../Context/useShowToast";
import { useLoader } from "../../Context/LoaderProvider";
import { Phone, Check, FileText, CircleX, Undo2, RotateCcw, SquarePen, Stethoscope } from "lucide-react";

const AppointmentHistory = ({ patientId }) => {

    const userInfo = JSON.parse(localStorage.getItem('user'))
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast()
    const [history, setHistory] = useState([]);
    const token = localStorage.getItem("token");

    const columns = [
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const patient = row.original;
                return (
                    <div className="flex items-center gap-2">

                        {( patient.aptStatus === 'Completed') && (
                            <button className="p-2 rounded bg-orange-200 text-orange-600 hover:bg-white cursor-pointer"
                                onClick={() => navigate(`/hospital/appointments/case-study/${patient.aptId}`)}
                            >
                                <SquarePen size={16} />
                            </button>
                        )}
                        
                    </div>
                );
            },
        },
        { accessorKey: "aptDate", header: "Apt Date" },
        { accessorKey: "doctorName", header: "Doctor" },
        { accessorKey: "doctorId", header: "DoctorId", hidden: true },
        { accessorKey: "patientId", header: "Patient ID" },
        { accessorKey: "patientName", header: "Name" },
        { accessorKey: "deptId", header: "Dept Id", hidden: true },
        { accessorKey: "aptId", header: "Apt Id", hidden: true },
        { accessorKey: "deptName", header: "Department" },
        { accessorKey: "clinicName", header: "Clinic" },
        { accessorKey: "locationName", header: "Location" },
        {
            accessorKey: "aptStatus",
            header: "Status",
            cell: ({ row }) => {
                const status = row.original.aptStatus;
                let color = ''
                switch (status) {
                    case "Confirm":
                        color = "bg-blue-100 text-blue-700"
                        break;
                    case "Completed":
                        color = "bg-green-100 text-green-700"
                        break;
                    case "Not Visited":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Checked In":
                        color = "bg-yellow-100 text-yellow-700"
                        break;
                    case "Under Oveservation":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Proceed":
                        color = "bg-pink-100 text-pink-700"
                        break;
                    case "Cancelled":
                        color = "bg-red-700 text-white"
                        break;
                    case "Saved as Draft":
                        color = "bg-yellow-600 text-white"
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700"
                        break;
                }
                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },

    ];

    useEffect(() => {
       fetchHistory();
    }, [])

    const fetchHistory = async () => {
        try {
            showLoader()
            const res = await axiosInstance.get(`${baseUrl}/api/Hospital/GetAppointmentHistory?patientId=${patientId}`, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })
            if (res.status === 200 && res.data.length > 0) {
                setHistory(res.data);
            }

        } catch (error) {
           showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    return (
        <div className="p-4 bg-blue-100 rounded-md">
            <div className="flex justify-between item-center">
                <div>
                    <h1 className="text-2xl font-bold mb-4 text-blue-700">
                        Appointment's history
                    </h1>
                </div>
            </div>
            {/* Legend / Action Guide */}

            <DataTable
                columns={columns}
                data={history}
                pageSize={50}
                headerBgColor="bg-blue-800"
                headerTextColor="text-white"
            />
        </div>
    )
}

export default AppointmentHistory
