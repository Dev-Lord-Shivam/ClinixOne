import React, { useState, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileDown, QrCode } from 'lucide-react';
import MedicalLogo from '/Images/medical-logo.png' ;

const AppointmentLetter = ({apt}) => {
  const printRef = useRef();

  const appointmentData = {
    patientId: apt?.patientId,
    nationality: apt?.nationality,
    residency: `${apt?.nationality} RESIDENT`,
    name: apt?.patientName,
    dob: apt?.dob,
    age: apt?.age,
    gender: apt?.gender,
    mobile: apt?.mobNumber,
    email: apt?.emailId,
    appointmentDate: apt?.aptDate,
    reportTime: apt?.slotStart,
    clinic: apt?.clinceName,
    location: apt?.locationName,
    doctor: apt?.doctorName,
    paymentMode: apt?.paymentMode,
    invoiceNo: 'W4016217',
    billNo: 'A003350657',
    receiptNo: 'WEBAPU097406',
    paidOn: '19/05/2022 10:09 PM',
    amount: `Rs. ${apt?.amount}/-`,
    address: apt?.address
  };

  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-area, #printable-area * {
            visibility: visible;
          }
          #printable-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>
      
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 flex justify-end no-print">
          <Button 
            onClick={handleExportPDF}
            className="bg-indigo-600 rounded-sm hover:bg-indigo-700 text-white"
          >
            <FileDown className="mr-2 h-4 w-4" />
            Export as PDF
          </Button>
        </div>

        <Card className="shadow-2xl" id="printable-area" ref={printRef}>
          <CardContent className="p-8">
            {/* Header */}
            <div className="text-center border-b-4 border-indigo-600 pb-6 mb-6">
              <div className="flex justify-between items-start mb-4">
                <div className="text-left">
                  <div className="text-xs text-gray-500 space-y-1">
                    <img src={MedicalLogo}
                      className="w-24 h-24 object-cover"
                    />
                  </div>
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold text-indigo-900 tracking-wider">
                    CLINIXONE HOSPITAL
                  </h1>
                  <p className="text-sm text-gray-600 mt-1">
                    VELLORE - 632 004, TAMIL NADU, INDIA
                  </p>
                </div>
                <div className="text-right">
                  <div className="w-16 h-16 border-2 border-gray-300 flex items-center justify-center">
                    <QrCode className="w-12 h-12 text-gray-400" />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">SCAN TO VERIFY</p>
                </div>
              </div>
              
              <h2 className="text-lg font-semibold text-indigo-800">
                Patient Appointment
              </h2>
              <p className="text-sm font-medium text-gray-700 mt-1">
                I N D I A N - P A T I E N T
              </p>
            </div>

            {/* Patient Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-4">
                <InfoRow label="Patient ID" value={appointmentData.patientId} highlight />
                <InfoRow label="Nationality" value={appointmentData.nationality} />
                <InfoRow label="Residency" value={appointmentData.residency} />
                <InfoRow label="Name" value={appointmentData.name} highlight />
                <InfoRow 
                  label="DOB / Age / Gender" 
                  value={`${appointmentData.dob} / ${appointmentData.age} - ${appointmentData.gender}`} 
                />
                <InfoRow label="Mobile No" value={appointmentData.mobile} />
                <InfoRow label="Email ID" value={appointmentData.email} />
              </div>
              
              <div className="space-y-4">
                <InfoRow label="Appointment Date" value={appointmentData.appointmentDate} highlight />
                <InfoRow label="Report Time" value={`Report to MRO at: ${appointmentData.reportTime}`} highlight />
                <InfoRow label="Token No" value="__________" />
                <InfoRow label="Room No" value="__________" />
                <InfoRow label="Clinic" value={appointmentData.clinic} />
                <InfoRow label="Location" value={appointmentData.location} />
                <InfoRow label="Doctor" value={appointmentData.doctor} highlight />
              </div>
            </div>

            {/* Payment Information */}
            <div className="bg-indigo-50 p-4 rounded-lg mb-6">
              <h3 className="font-semibold text-indigo-900 mb-3 text-lg">Payment Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <InfoRow label="Mode of Payment" value={appointmentData.paymentMode} compact />
                <InfoRow label="Invoice No" value={appointmentData.invoiceNo} compact />
                <InfoRow label="Bill No" value={appointmentData.billNo} compact />
                <InfoRow label="Receipt No" value={appointmentData.receiptNo} compact />
                <InfoRow label="Paid on" value={appointmentData.paidOn} compact />
                <InfoRow label="Amount" value={appointmentData.amount} compact highlight />
              </div>
            </div>

            {/* Address */}
            <div className="mb-6">
              <p className="text-sm">
                <span className="font-semibold text-gray-700">Address: </span>
                <span className="text-gray-600">{appointmentData.address}</span>
              </p>
            </div>

            {/* General Instructions */}
            <div className="border-t-2 border-gray-200 pt-6">
              <h3 className="font-semibold text-indigo-900 mb-3 text-lg">General Instructions</h3>
              <ol className="space-y-2 text-sm text-gray-700">
                <li>1. If the patient requires in-patient admission a female attendant is mandatory.</li>
                <li>2. Appointment booked online will Not be refunded.</li>
                <li>3. Change of Department/Unit Not allowed.</li>
                <li>4. Change in appointment Date will be allowed only once, upto one day prior to the appointment Date.</li>
                <li>5. Please provide atleast Government Related ID proof when you present yourself at the Entrance / MRO counter.</li>
                <li>6. Please contact Counter No: 2, 3, 4 (General) OR 402 (Private) in ISSCC Building Ground Floor to collect your Hospital Number Card.</li>
                <li>7. Request for appointments via post / phone will Not be accepted.</li>
                <li>8. Demand Drafts will only be accepted at cash counters, Not via post.</li>
              </ol>
            </div>

            {/* Footer */}
            <div className="mt-8 text-center text-xs text-gray-500">
              <p>This is a computer-generated document. No signature is required.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

const InfoRow = ({ label, value, highlight, compact }) => {
  return (
    <div className={compact ? "" : ""}>
      <p className="text-xs text-gray-500 font-medium mb-1">{label}</p>
      <p className={`text-sm ${highlight ? 'font-semibold text-indigo-900' : 'text-gray-700'}`}>
        {value}
      </p>
    </div>
  );
};

export default AppointmentLetter;