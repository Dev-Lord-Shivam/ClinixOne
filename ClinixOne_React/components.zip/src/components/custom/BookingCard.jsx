import React from "react";

const BookingCard = ({date, location,setStep}) => {
  return (
    <div className="h-[16em] w-[18em] border-2 border-green-600/40 rounded-2xl bg-gradient-to-br from-green-800 to-green-300 text-white font-nunito p-6 flex flex-col justify-between shadow-lg backdrop-blur-md">
      {/* Title & Details */}
      <div className="space-y-3">
        <h1 className="text-2xl font-semibold">Confirm Slot</h1>
        <div className="text-sm space-y-1 text-green-50">
          <h5>
            <span className="font-medium">Date:</span> {date}
          </h5>
          <h5>
            <span className="font-medium">Location:</span> {location}
          </h5>
          <h5>
            <span className="font-bold text-red-500">NOTE: </span>
             culsulting timing will be auto allocated
            {/* <span className="font-medium">Time:</span> 07:00 AM */}
          </h5>
        </div>
      </div>

      {/* Button */}
      <button 
          onClick={() => {setStep(2)}}
          className="w-fit px-5 py-2 border border-white/60 rounded-full flex items-center gap-2 
                         text-green-800 bg-white font-medium cursor-pointer hover:bg-red-600 
                         hover:text-white hover:border-white hover:scale-105 transition-all duration-300">
        <span>Confirm</span>
        <svg
          className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300"
          stroke="currentColor"
          strokeWidth={2}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
        </svg>
      </button>
    </div>
  );
};

export default BookingCard;
