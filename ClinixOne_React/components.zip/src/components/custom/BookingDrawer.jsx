import React, { useEffect, useState } from 'react';
import { Calendar, ChevronRight } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select"
import BookingCard from './BookingCard';
import { useLoader } from '../../Context/LoaderProvider';
import useShowToast from '../../Context/useShowToast';
import axiosInstance from '../../Context/axiosInstance';
import DefaultProfilePic from '/Images/DefaultProfile.jpg';
import AppointmentLetter from './AppointmentLetter';
import { useCustomAlert } from '../../Context/CustomAlertProvider';

export default function BookingDrawer({ isOpen, onClose, doctor, dateparam }) {
  const { showLoader, hideLoader } = useLoader();
  const showToast = useShowToast();
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [availableDates, setAvailableDates] = useState([])
  const [monthDD, setMonthDD] = useState([])
  const [selectedMonth, setSelectedMonth] = useState('');
  const [aptLetter, setAptLetter] = useState(null);
  const patientInfo = JSON.parse(localStorage.getItem("patient"));
  const alert = useCustomAlert();

  const timeSlots = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
    '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM',
    '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM'
  ];

  useEffect(() => {
    if (!doctor?.doctorId) return;
    const fetchShift = async () => {

      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=Get_BookingOpenMonth`;
      const res = await axiosInstance.get(url)
      if (res.status === 200 && res.data) {
        setMonthDD(res.data.map(item => ({
          label: item.text,
          value: item.value
        })));
      }
      else {
        showToast('error', 'error!', res.error || 'something went wrong')
        return
      }
      setSelectedMonth(res.data[0].value)
      const [year, month, day] = dateparam.split("-");
      const formattedDateObj = `${day}/${month}/${year}`;
      setSelectedDate(formattedDateObj)
      await getShiftByIdAndMonth(res.data[0].value);
    };
    fetchShift();
  }, [doctor]);


  const getShiftByIdAndMonth = async (month) => {
    try {
      showLoader();
      const token = localStorage.getItem("patienttoken");
      let url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/GetDoctorsByShift`;
      const res = await axiosInstance.get(url, {
        params: {
          doctorId: doctor.doctorId,
          monthName: month,
          type: 'GetDoctorShiftByID'
        },
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
      if (res.status === 200 && res.data) {
        console.log(res.data)
        setAvailableDates(res.data);
      }
      else {
        showToast('error', 'error!', res.error)
      }
    } catch (error) {

    } finally {
      hideLoader()
    }
  }

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    //setStep(2);
  };

  const handleConfirmBooking = async () => {
    try {
      showLoader()
      const payload = {
        PatientId: patientInfo?.patientId,
        DoctorId: doctor.doctorId,
        LocationId: doctor.locationid,
        ClinicId: doctor.clinicid,
        DptId: doctor.deptId,
        AptDate: selectedDate,
        Fee: 550.00,
        Type: 'Book_Appointment'
      }
      
      const token = localStorage.getItem("patienttoken");
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/AptInsertUpdate`;
      const res = await axiosInstance.post(url, payload, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      })

      if (res.status === 200) {
        console.log(res.date)
        setAptLetter(res.data)
        alert({
          title: 'Appointmet Schedule Successfully',
          description: `we have schedule your appointmetn on ${selectedDate}, 
                               please download the Appointment Letter`})
        setStep(3)
      }
      else {
        console.log(res)
        showToast('error', 'error!', res.error || 'Something Went Wrong')
      }
    } catch (error) {
      showToast('error', 'error!', error.message || 'Internal Server Error')
    } finally {
      hideLoader()
    }
  };

  const resetBooking = () => {
    setStep(1);
    setSelectedDate('');
    setSelectedTime('');
    setSelectedMonth('');
    setMonthDD([])
    setAvailableDates([]);
    onClose();
  };

  return (
    <Sheet open={isOpen} onOpenChange={resetBooking}>
      <SheetContent side="bottom" className="h-[90vh] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-xl text-center">Book Appointment</SheetTitle>
          <SheetDescription className='text-center'>
            Complete the booking process in a few simple steps
          </SheetDescription>
        </SheetHeader>

        <div className="mt-2 w-full px-2 sm:px-4">
          {/* Doctor Info + Progress */}
          <div className="flex flex-col md:flex-row gap-6">
            {/* Doctor Card */}
            <div className="md:w-1/4 bg-green-100 shadow-sm rounded-xl p-4 border border-gray-200 max-h-100">
              <div className="flex flex-col items-center text-center space-y-3">
                <img
                  src={doctor?.image || DefaultProfilePic}
                  alt={doctor?.name}
                  className="w-32 h-32 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">Dr. {doctor?.name}</h3>
                  <p className="text-sm text-gray-600 font-semibold">{doctor?.deptName} | Exp: {doctor?.exp} years</p>
                  <br />
                  <p className='text-xs text-gray-600 text-justify'>Dr. {doctor?.name} is a dedicated {doctor?.deptName} with {doctor?.exp} years of clinical experience in
                    diagnosing and managing a wide spectrum of cardiovascular conditions. Known for a
                    patient-centered approach and a commitment to evidence-based care, Dr. {doctor?.name}
                    combines clinical acumen with compassion to deliver personalized treatment plans
                    that improve heart health and overall well-being.
                  </p>
                </div>
              </div>
            </div>

            {/* Progress + Steps */}
            <div className="flex-1">
              {/* Progress Bar */}
              <div className="flex items-center justify-between mb-8">
                {[1, 2, 3].map((s) => (
                  <div key={s} className="flex items-center flex-1">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${step >= s
                        ? "bg-green-600 text-white"
                        : "bg-gray-200 text-gray-500"
                        }`}
                    >
                      {s}
                    </div>
                    {s < 3 && (
                      <div
                        className={`flex-1 h-1 mx-2 rounded-full transition-colors ${step > s ? "bg-green-600" : "bg-gray-200"
                          }`}
                      />
                    )}
                  </div>
                ))}
              </div>

              {/* Steps Content */}
              <div className="bg-white shadow-sm rounded-xl p-4 border border-gray-200">
                {/* Step 1: Select Date */}
                {step === 1 && (

                  <div className='flex flex-row w-full'>
                    <div className='w-1/3'>
                      <BookingCard date={selectedDate} location={doctor?.clinicName?.concat(', ', doctor?.locationName)} setStep={setStep} />
                    </div>
                    <div className='w-2/3'>
                      <div className="flex justify-between items-center w-full mb-4">
                        {/* Heading with Icon */}
                        <h3 className="w-2/4 text-lg font-semibold flex items-center text-gray-800">
                          <Calendar className="w-5 h-5 mr-2 text-green-600" />
                          Available Dates in {selectedMonth}
                        </h3>

                        {/* Month Dropdown */}
                        <div className='w-1/4'>
                          <Select onValueChange={(val) => {
                            setSelectedMonth(val);
                            getShiftByIdAndMonth(val);
                          }} value={selectedMonth}>
                            <SelectTrigger className="form-control w-[160px]">
                              <SelectValue placeholder="Change Month" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectGroup>
                                <SelectLabel>Available Months</SelectLabel>
                                {monthDD.map((item) => (
                                  <SelectItem key={item.value} value={item.value}>
                                    {item.label}
                                  </SelectItem>
                                ))}
                              </SelectGroup>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-2">

                        {availableDates.map((dateObj) => {
                          const isActive = dateObj.isActive === true; // assuming 1=available, 0=unavailable
                          const isSelected = selectedDate === dateObj.date && isActive; // only allow selection if active

                          return (
                            <button
                              key={dateObj.date}
                              onClick={() => isActive && handleDateSelect(dateObj.date)}
                              disabled={!isActive}
                              className={`w-full p-2 text-left text-sm border rounded-sm flex items-center justify-between transition-all
                                ${!isActive
                                  ? 'bg-gray-200 text-gray-400 border-gray-300 cursor-not-allowed opacity-70' // disabled style
                                  : isSelected
                                    ? 'bg-red-400 text-white border-red-700 hover:bg-red-600' // selected style
                                    : 'bg-green-200 border-gray-200 hover:border-green-600 hover:bg-green-50' // normal style
                                }`}
                            >
                              <span className="font-medium">
                                {`${dateObj.dayName.slice(0, 3)}, ${dateObj.monthName.slice(0, 3)} ${dateObj.date.slice(0, 2)}`}
                              </span>
                              <ChevronRight
                                className={`w-5 h-5 ${isSelected ? 'text-white' : isActive ? 'text-gray-400' : 'text-gray-300'
                                  }`}
                              />
                            </button>
                          );
                        })}


                      </div>
                    </div>
                  </div>
                )}

                {/* Step 2: Select Time */}
                {step === 2 && (
                  <div className="flex flex-col gap-6">
                    <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                      💳 Payment Gateway
                    </h2>

                    {/* Static Payment Details */}
                    <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Consultation Fee</span>
                        <span className="font-medium text-gray-900">₹500</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Service Charges</span>
                        <span className="font-medium text-gray-900">₹50</span>
                      </div>
                      <div className="border-t border-gray-200 pt-3 flex justify-between font-semibold text-green-600">
                        <span>Total</span>
                        <span>₹550</span>
                      </div>
                    </div>

                    {/* Payment Options (static) */}
                    <div className="flex flex-row gap-6">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="payment" defaultChecked />
                        <span>UPI</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="payment" />
                        <span>Credit / Debit Card</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="payment" />
                        <span>Net Banking</span>
                      </label>
                    </div>

                    {/* Buttons */}
                    <div className="flex justify-between">
                      <button
                        onClick={() => setStep(1)}
                        className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition"
                      >
                        Back
                      </button>
                      <button
                        onClick={() => handleConfirmBooking()}
                        className="cursor-pointer px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition"
                      >
                        Pay ₹550
                      </button>
                    </div>
                  </div>
                )}
                {step === 3 && (
                  <AppointmentLetter apt={aptLetter} />
                )}
              </div>
            </div>
          </div>
        </div>

      </SheetContent>
    </Sheet>
  );
};
