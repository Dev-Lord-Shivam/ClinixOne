import { Button } from "@/components/ui/button"
import {
    Dialog,
    DialogClose,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogOverlay
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { useLoader } from "../../Context/LoaderProvider";
import axiosInstance from "../../Context/axiosInstance";
import { useState } from "react";

const CancelAptDialog = ({ isOpen, onClose, aptId, showToast, setUpcomingApt, setPastApt }) => {
    const token = localStorage.getItem("patienttoken");
    const userInfo = JSON.parse(localStorage.getItem("patient"));
    const { showLoader, hideLoader } = useLoader();
    const [remarks, setRemarks] = useState('');
    const [validationerror, setValidationError] = useState(false)

    const cancelApt = async () => {
        try {
            if (remarks.trim() === '') {
                setValidationError(true)
                return;
            }
            setValidationError(false)
            showLoader();
            const payload = {
                PatientId: userInfo?.patientId,
                AptId: aptId,
                Remarks: remarks,
                Type: 'Cancel_Appointment'
            }
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/patient/AptInsertUpdate`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
            })
            if (res.status === 200) {
                let upcoming = res.data.upcoming
                let past = res.data.past
                setUpcomingApt(upcoming)
                setPastApt(past)
                showToast("success", "Success!", "Appointment cancelled successfully.")
                onClose(false)
            } else {
                showToast('error', 'error!', res.error || 'Failed to cancel the appointment')
            }
        } catch (error) {
            showToast('error', 'error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader();
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogOverlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center" />
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>Are you sure you want to cancel?</DialogTitle>
                    <DialogDescription>
                        This action cannot be undone after confirmation.
                    </DialogDescription>
                </DialogHeader>

                <div className="flex items-center gap-2">
                    <div className="grid flex-1 gap-2">
                        <Textarea
                            value={remarks}
                            id="reason"
                            className='form-control'
                            placeholder="Please Enter enter reason"
                            onChange={(e) => setRemarks(e.target.value)}
                        />
                        {validationerror &&
                            <span className="text-xs text-red-700">Please enter remarks</span>
                        }
                    </div>
                </div>

                <DialogFooter className="sm:justify-end mt-4">
                    <DialogClose asChild>
                        <Button type="button" className='bg-green-700 text-white text-xs rounded-xs h-8 cursor-pointer'>
                            Close
                        </Button>
                    </DialogClose>
                    <Button className='rounded-xs h-8 text-xs cursor-pointer' type="button" variant="destructive"
                        onClick={cancelApt}
                    >
                        Confirm Cancel
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

export default CancelAptDialog
