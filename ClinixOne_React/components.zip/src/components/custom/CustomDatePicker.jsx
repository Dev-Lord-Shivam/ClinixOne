// CustomDatePicker.jsx
import {React, useState, useEffect, useMemo} from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { format, parse, isSameMonth } from "date-fns";

const CustomDatePicker = ({
  selected,
  onChange,
  placeholder = "Select a date",
  dateFormat = "dd/MM/yyyy",
  className = "",
  disabled = false,
  disableFuture = false,
  disablePast = false,
  multiSelect = false,
  onlyCurrentMonth = false,
  ...props
}) => {
  const today = new Date();
  const minDate = disablePast ? today : undefined;
  const maxDate = disableFuture ? today : undefined;

  // Convert selected string to Date object safely
  let parsedSelected = null;
  if (selected instanceof Date) {
    parsedSelected = selected;
  } else if (typeof selected === "string" && selected.trim()) {
    try {
      parsedSelected = parse(selected, dateFormat, new Date());
      if (isNaN(parsedSelected)) parsedSelected = null;
    } catch {
      parsedSelected = null;
    }
  }

  // Convert selected to array of Dates if multi-select
  const initialSelected = useMemo(() => {
    if (multiSelect) {
      if (Array.isArray(selected)) {
        return selected.map((s) =>
          s instanceof Date
            ? s
            : typeof s === "string"
            ? parse(s, dateFormat, new Date())
            : null
        ).filter(Boolean);
      }
      return [];
    } else {
      if (selected instanceof Date) return selected;
      if (typeof selected === "string") {
        const parsed = parse(selected, dateFormat, new Date());
        return isNaN(parsed) ? null : parsed;
      }
    }
  }, [selected, dateFormat, multiSelect]);

    const [selectedDates, setSelectedDates] = useState(
    multiSelect ? initialSelected : initialSelected || null
  );

  useEffect(() => {
    setSelectedDates(multiSelect ? initialSelected : initialSelected || null);
  }, [selected, initialSelected, multiSelect]);

   const handleChange = (date) => {
    if (multiSelect) {
      const exists = selectedDates.some((d) => d.getTime() === date.getTime());
      const updatedDates = exists
        ? selectedDates.filter((d) => d.getTime() !== date.getTime())
        : [...selectedDates, date];
      setSelectedDates(updatedDates);
      onChange(updatedDates.map((d) => format(d, dateFormat)));
    } else {
      setSelectedDates(date);
      onChange(format(date, dateFormat));
    }
  };

  const filterDate = (date) => {
    if (onlyCurrentMonth) {
      return isSameMonth(date, today);
    }
    return true;
  };


  return (
    <DatePicker
      selected={multiSelect ? null : selectedDates}
      onChange={handleChange}
      placeholderText={placeholder}
      dateFormat={dateFormat}
      className={`w-full px-3 py-2 border rounded bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${className}`}
      disabled={disabled}
      showMonthDropdown
      showYearDropdown
      dropdownMode="select"
      minDate={minDate}
      maxDate={maxDate}
      highlightDates={multiSelect ? selectedDates : []}
      includeDates={multiSelect ? undefined : undefined}
      filterDate={filterDate}
      inline={multiSelect}
      onKeyDown={(e) => e.preventDefault()} // prevent typing
      {...props}
    />
  );
};

export default CustomDatePicker;
