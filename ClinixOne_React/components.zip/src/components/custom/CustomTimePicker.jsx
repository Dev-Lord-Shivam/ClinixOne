import React, { useState, useRef, useEffect } from "react";

const generateTimeOptions = (interval = 5) => {
  const times = [];
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += interval) {
      times.push(`${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`);
    }
  }
  return times;
};

const isValidTime = (time) => {
  const regex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  return regex.test(time);
};

const formatTime = (input) => {
  const parts = input.split(":");
  if (parts.length !== 2) return input;
  const [h, m] = parts;
  const hh = h.padStart(2, "0");
  const mm = m.padStart(2, "0");
  return `${hh}:${mm}`;
};

const CustomTimePicker = ({ value, onChange, className = "", placeholder = "HH:mm" }) => {
  const timeOptions = generateTimeOptions(15);
  const [showDropdown, setShowDropdown] = useState(false);
  const [inputValue, setInputValue] = useState(value || "");
  const ref = useRef(null);

  useEffect(() => {
    setInputValue(value || "");
  }, [value]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  const handleInputChange = (e) => {
    const input = e.target.value;
    console.log(input.length)
    if(input.length == 2){
        setInputValue(input.concat(':'))
    }
    else if (input.length > 5){
        return;
    }
    else{
        setInputValue(input);
    }

    if (isValidTime(input)) {
      const formatted = formatTime(input);
      onChange(formatted);
    } else {
      onChange("");
    }
  };
  
  const handleBlur = () => {
    if (isValidTime(inputValue)) {
      const formatted = formatTime(inputValue);
      onChange(formatted);
    } else {
      onChange("");
      setInputValue("");
    }
  }

  const handleSelectTime = (time) => {
    setInputValue(time);
    onChange(time);
    setShowDropdown(false);
  };

  const filteredOptions = timeOptions.filter((time) =>
    time.startsWith(inputValue)
  );

  return (
    <div ref={ref} className="relative w-full">
      <input
        type="text"
        placeholder={placeholder}
        value={inputValue}
        onChange={handleInputChange}
        onFocus={() => setShowDropdown(true)}
        onBlur={handleBlur}
        className={`w-full px-3 py-2 border rounded bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${className}`}
      />
      {showDropdown && (
        <div className="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded border bg-white shadow-lg text-sm">
          {(filteredOptions.length ? filteredOptions : timeOptions).map((time) => (
            <div
              key={time}
              onClick={() => handleSelectTime(time)}
              className={`cursor-pointer px-3 py-2 hover:bg-blue-100 ${
                time === value ? "bg-blue-500 text-white font-semibold" : ""
              }`}
            >
              {time}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomTimePicker;
