import React from 'react';
import DatePicker from 'react-datepicker';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';

export function DOBPicker({ value, onChange }) {
  return (
    <div className="relative w-full">
      <div className="flex items-center border rounded px-2 py-1 w-full h-8 border-gray-400 border-1">
        <CalendarIcon className="mr-2 h-4 w-4 text-gray-500" />
        <DatePicker
          selected={value}
          onChange={onChange}
          dateFormat="dd/MM/yyyy"
          showYearDropdown
          scrollableYearDropdown
          yearDropdownItemNumber={100}
          placeholderText="Select DOB"
          className="w-full bg-transparent outline-none"
          maxDate={new Date()}
          readOnly
        />
      </div>
    </div>
  );
}
