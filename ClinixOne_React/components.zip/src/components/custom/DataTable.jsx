import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { useState, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function DataTable({
  columns,
  data,
  pageSize = 5,
  enableMultiSelect = false,
  onSelectRow,
  headerBgColor = "bg-blue-500",
  headerTextColor = "text-white",
  rowClassName = "bg-white",
}) {

  const [columnFilters, setColumnFilters] = useState([]);
  const [rowSelection, setRowSelection] = useState({});

  // Reset row selection when data changes
  useEffect(() => {
    setRowSelection({});
  }, [data]);

  // Apply multi-select checkbox column only if enabled
  const visibleColumns = useMemo(() => {
    const filteredColumns = columns.filter((col) => !col.hidden);

    if (!enableMultiSelect) return filteredColumns;

    return [
      {
        id: "select",
        header: ({ table }) => (
          <input
            type="checkbox"
            checked={table.getIsAllPageRowsSelected()}
            onChange={table.getToggleAllPageRowsSelectedHandler()}
          />
        ),
        cell: ({ row }) => (
          <input
            type="checkbox"
            checked={row.getIsSelected()}
            disabled={!row.getCanSelect()}
            onChange={row.getToggleSelectedHandler()}
          />
        ),
        size: 40,
      },
      ...filteredColumns,
    ];
  }, [columns, enableMultiSelect]);

  const table = useReactTable({
    data,
    columns: visibleColumns,
    state: {
      columnFilters,
      rowSelection,
    },
    enableRowSelection: enableMultiSelect,
    onRowSelectionChange: setRowSelection,
    onColumnFiltersChange: setColumnFilters,
    enableColumnResizing: true,
    columnResizeMode: "onChange",
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: {
      pagination: {
        pageSize,
      },
    },
  });

// Use useEffect to call onSelectRow when rowSelection changes
  useEffect(() => {
    if (onSelectRow && enableMultiSelect) {
      const selectedRows = table
        .getSelectedRowModel()
        .rows.map((r) => r.original);
      onSelectRow(selectedRows);
    }
  }, [rowSelection, enableMultiSelect]);

  return (
    <div className="rounded-md border shadow bg-white p-4 w-full overflow-x-auto">
      <div className="max-h-[500px] overflow-auto">
        <table className="min-w-full table-fixed border-collapse">
          <thead className={`${headerBgColor} sticky top-0 z-10`}>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  const canFilter = header.column.getCanFilter();
                  return (
                    <th
                      key={header.id}
                      className={`${headerTextColor} text-xs text-start font-medium p-2 border-2 border-gray-300 relative group`}
                      style={{
                        width: header.getSize(),
                        minWidth: header.getSize() || 100,
                        maxWidth: 400,
                      }}
                    >
                      {flexRender(header.column.columnDef.header, header.getContext())}

                      {canFilter ? (
                        <Input
                          className="mt-1 w-full h-5 text-xs rounded-xs bg-white text-black"
                          placeholder="Filter..."
                          value={header.column.getFilterValue() ?? ""}
                          onChange={(e) =>
                            header.column.setFilterValue(e.target.value)
                          }
                        />
                      ) : null}

                      {header.column.getCanResize() && (
                        <div
                          onMouseDown={header.getResizeHandler()}
                          onTouchStart={header.getResizeHandler()}
                          className="absolute right-0 top-0 h-full w-1 cursor-col-resize bg-gray-400 opacity-0 group-hover:opacity-100"
                          style={{
                            transform: "translateX(50%)",
                            touchAction: "none",
                            userSelect: "none",
                          }}
                        />
                      )}
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>

          <tbody>
            {table.getRowModel().rows.length ? (
              table.getRowModel().rows.map((row) => (
                <tr key={row.id} className={`${rowClassName} hover:bg-blue-100`}>
                  {row.getVisibleCells().map((cell) => (
                    <td
                      key={cell.id}
                      className="p-3 text-xs border-2 border-gray-300"
                    >
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={visibleColumns.length} className="h-24 text-center">
                  No results.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Footer Pagination + Row Count */}
      <div className="flex flex-wrap items-center justify-between mt-4 text-sm gap-3">
        <div className="text-gray-500">
          Showing {table.getRowModel().rows.length} of{" "}
          {table.getFilteredRowModel().rows.length} rows
        </div>

        <div className="flex items-center gap-4">

          {/* Page Dropdown */}
          <div className="flex items-center gap-2">
            <span>Page:</span>
            <select
              className="border rounded px-2 py-1 text-sm"
              value={table.getState().pagination.pageIndex}
              onChange={(e) => table.setPageIndex(Number(e.target.value))}
            >
              {Array.from({ length: table.getPageCount() }).map((_, i) => (
                <option key={i} value={i}>
                  {i + 1}
                </option>
              ))}
            </select>
          </div>

          {/* Manual Page Input */}
          <div className="flex items-center gap-2">
            <span>Go to page:</span>
            <Input
              type="number"
              min={1}
              max={table.getPageCount()}
              className="w-16 h-8"
              onChange={(e) => {
                const value = e.target.value ? Number(e.target.value) - 1 : 0;
                if (value >= 0 && value < table.getPageCount()) {
                  table.setPageIndex(value);
                }
              }}
            />
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
            >
              Previous
            </Button>

            <Button
              size="sm"
              variant="outline"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
            >
              Next
            </Button>
          </div>
        </div>
        <div className="text-gray-500">
          Page {table.getState().pagination.pageIndex + 1} of{" "}
          {table.getPageCount()}
        </div>
      </div>
    </div>
  );
}