
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ShoppingCart, Trash2, CheckCircle2, Plus, Search } from 'lucide-react';
import useShowToast from "../../Context/useShowToast";
import { useLoader } from "../../Context/LoaderProvider";
import axiosInstance from "../../Context/axiosInstance";
import { useConfirm } from "../../Context/ConfirmProvider";
import { DataTable } from "../../components/custom/DataTable";
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useCustomAlert } from "../../Context/CustomAlertProvider";

export default function DiagnosticTestBill({ patientid }) {

    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const token = localStorage.getItem("token");
    const confirm = useConfirm()
    const alert = useCustomAlert()
    const showToast = useShowToast()
    const { showLoader, hideLoader } = useLoader()
    const [testList, setTestList] = useState([]);
    const [cart, setCart] = useState([]);
    const columns = [
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const patient = row.original;
                return (
                    <div className="flex items-center gap-2">

                        {(patient.status === 'Pending') && (
                            <button onClick={() => cancelTest(patient.scheduleId)} className="p-2 rounded bg-red-300 text-black hover:bg-white cursor-pointer">
                                <Trash2 size={16} />
                            </button>
                        )}

                    </div>
                );
            },
        },
        { accessorKey: "testName", header: "Test Name" },
        { accessorKey: "createdAt", header: "Date" },
        { accessorKey: "testId", header: "testId", hidden: true },
        { accessorKey: "scheduleId", header: "scheduleId", hidden: true },
        { accessorKey: "createdBy", header: "Doctor", hidden: true },
        { accessorKey: "categoryName", header: "Category" },
        { accessorKey: "mrp", header: "MRP (₹)" },
        {
            accessorKey: "status",
            header: "Status",
            cell: ({ row }) => {
                const status = row.original.status;
                let color = ''
                switch (status) {
                    case "Completed":
                        color = "bg-green-100 text-green-700"
                        break;
                    case "Pending":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Cancelled":
                        color = "bg-red-600 text-white"
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700"
                        break;
                }
                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },

    ];

    useEffect(() => {
        fetchTestByPatient()
    }, [patientid])

    const fetchTestByPatient = async () => {
        try {
            if(!patientid) return
            showLoader()
            const url = `${baseUrl}/api/Hospital/GetTestHistory?patientId=${patientid}&Type=${'PatientTestHistory'}`
            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })
            if (res.status == 200 && res.data.length > 0) {
                setTestList(res.data.filter(m => m.status === 'Pending'));
            } else {
                setTestList([])
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const handleBillingSubmit = async () => {
        let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want schedule test",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };
        
        const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

        try {
            showLoader();
            
            const payload = {
                JsonData: JSON.stringify(cart),
                Type: 'testpayment'
            }

            const url = `${baseUrl}/api/Hospital/ScheduleTest`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '3') {
                showToast('success', 'Success!', 'Diagnostic test schedule successfully');
                setCart([])
                setTestList([])
                await fetchTestByPatient()
            } 
            else 
            {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader();
        }
    }

     const cancelTest = async (scheduleId) => {
       try {
          const exists = cart.find(m => m.scheduleId === scheduleId)?.testName
          if(exists){
            alert({
                title: 'Alert',
                description: `Remove ${exists} from cart before cancelling test`
            })
            return;
          }
           
          let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want to cancel this test",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            showLoader()
   
            const payload = {
                patientId: patientid,
                scheduleId: scheduleId,
                type: "canceltest",
            }

            const url = `${baseUrl}/api/Hospital/ScheduleTest`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '2') {
                showToast('success', 'Success!', 'Test cancelled successfully');
                await fetchTestByPatient()
            }
            else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
       } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
       } finally {
           hideLoader()
       }
    }


    return (
        <div className="min-h-screen bg-blue-100 rounded-md p-4">

            <div className={`flex flex-row gap-4`}>
                <div className="w-2/3">
                    <DataTable
                        columns={columns}
                        data={testList}
                        pageSize={50}
                        headerBgColor="bg-blue-700"
                        headerTextColor="text-white"
                        enableMultiSelect={true}
                        onSelectRow={(rows) => setCart(rows)}
                    />
                </div>
                <div className={"w-2/3"}>
                    {/* Shopping Cart */}
                    <Card className={`border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-50`}>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <ShoppingCart className="h-5 w-5 text-purple-600" />
                                Test Cart ({cart.length})
                            </CardTitle>
                            <CardDescription>Tests to be ordered</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {cart.length === 0 ? (
                                <div className="text-center py-8 text-gray-500">
                                    <ShoppingCart className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                                    <p>No items in cart</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <ScrollArea className="h-[200px]">
                                        <div className="space-y-2 pr-4">
                                            {cart.map((item) => (
                                                <div key={item.id} className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm border border-purple-100 hover:border-purple-300 transition-colors">
                                                    <div className="flex-1">
                                                        <p className="font-medium text-sm text-gray-800">{item.testName}</p>
                                                        <p className="text-sm text-purple-600 font-semibold mt-1">₹{item.mrp}</p>
                                                    </div>
                                                    
                                                </div>
                                            ))}
                                        </div>
                                    </ScrollArea>

                                    <Separator className="my-4" />

                                    {/* Grand Total Section */}
                                    <div className="bg-gradient-to-r from-purple-200 to-purple-300 rounded-md p-2 space-y-2">
                                        <div className="flex justify-between items-center">
                                            <span className="text-md font-bold text-gray-800">Grand Total</span>
                                            <span className="text-xl font-bold text-purple-700">₹{cart.reduce((sum, item) => sum + parseFloat(item.mrp), 0).toFixed(2)}</span>
                                        </div>
                                    </div>

                                    <Button
                                        size='sm'
                                        className="w-full bg-gradient-to-r from-purple-300 to-purple-600 hover:from-purple-700 hover:to-purple-700 text-black font-semibold py-6 shadow-md hover:shadow-lg transition-all"
                                        onClick={handleBillingSubmit}
                                    >
                                        <CheckCircle2 className="mr-2 h-5 w-5" />
                                        Checkin Tests ({cart.length})
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    )
}
