
import { User, Phone, Mail, Calendar, Droplet, Heart, Users } from 'lucide-react';

const PatientCard = ({ patientDetails }) => {


  // Default avatar if no profile pic
  const defaultAvatar = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Crect fill='%23e5e7eb' width='100' height='100'/%3E%3Ctext x='50' y='50' font-size='40' text-anchor='middle' dy='.3em' fill='%239ca3af'%3E%3F%3C/text%3E%3C/svg%3E";
  
  const profileImage = patientDetails?.profilePic 
    ? `${patientDetails.profilePic}`
    : defaultAvatar;

  const calculateAge = (dob) => {
    if (!dob) return 'N/A';
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
      {/* Header with Profile Picture */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 rounded-full border-4 border-white overflow-hidden bg-gray-200 mb-3">
            <img 
              src={profileImage}
              alt={patientDetails?.fullName || 'Patient'}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.target.src = defaultAvatar;
              }}
            />
          </div>
          <h2 className="text-xl font-bold text-center">
            {patientDetails?.fullName || 'N/A'}
          </h2>
          <p className="text-blue-100 text-sm">
            ID: {patientDetails?.patientId || 'N/A'}
          </p>
        </div>
      </div>

      {/* Patient Details */}
      <div className="p-4 grid grid-cols-2 space-y-3">
        {/* Contact Information */}
        <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
          <Phone className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Phone</p>
            <p className="text-sm font-medium text-gray-900 break-words">
              {patientDetails?.mobNumber || 'N/A'}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
          <Mail className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Email</p>
            <p className="text-sm font-medium text-gray-900 break-words">
              {patientDetails?.email || 'N/A'}
            </p>
          </div>
        </div>

        {/* Personal Information */}
        <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
          <User className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Gender</p>
            <p className="text-sm font-medium text-gray-900">
              {patientDetails?.gender || 'N/A'}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
          <Calendar className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Date of Birth</p>
            <p className="text-sm font-medium text-gray-900">
              {formatDate(patientDetails?.dob)}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Age: {calculateAge(patientDetails?.dob)} years
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
          <Droplet className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Blood Group</p>
            <p className="text-sm font-medium text-gray-900">
              {patientDetails?.bloodGroup || 'N/A'}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
          <Heart className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Religion</p>
            <p className="text-sm font-medium text-gray-900">
              {patientDetails?.religion || 'N/A'}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Users className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs text-gray-500 uppercase tracking-wide">Marital Status</p>
            <p className="text-sm font-medium text-gray-900">
              {patientDetails?.maritalStatus || 'N/A'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientCard;