import { useState, useCallback, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Stethoscope } from "lucide-react";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import axiosInstance from "../../Context/axiosInstance";

const PatientCaseStudy = ({ caseStudy }) => {

    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast();
    const token = localStorage.getItem("token");
    const [formData, setFormData] = useState({
        aptId: caseStudy?.aptId || "",
        symptoms: caseStudy?.symptoms || "",
        symptomInput: "",
        pastRecords: caseStudy?.pastRecords || "",
        overview: caseStudy?.overview || "",
        precaution: caseStudy?.precaution || "",
        diagnosis: caseStudy?.diagnosis || "",
        bloodPressure: caseStudy?.bloodPressure || "",
        temperature: caseStudy?.temperature || "",
        pulseRate: caseStudy?.pulseRate || "",
        weight: caseStudy?.weight || "",
        height: caseStudy?.height || ""
    });

    useEffect(() => {
        if (caseStudy) {
            setFormData(prev => ({
                ...prev,
                aptId: caseStudy.aptId || prev.aptId,
                symptoms: caseStudy.symptoms || prev.symptoms,
                pastRecords: caseStudy.pastRecords || prev.pastRecords,
                overview: caseStudy.overview || prev.overview,
                precaution: caseStudy.precaution || prev.precaution,
                diagnosis: caseStudy.diagnosis || prev.diagnosis,
                bloodPressure: caseStudy?.bloodPressure || prev.bloodPressure,
                temperature: caseStudy?.temperature || prev.temperature,
                pulseRate: caseStudy?.pulseRate || prev.pulseRate,
                weight: caseStudy?.weight || prev.weight,
                height: caseStudy?.height || prev.height
            }));
        }
    }, [caseStudy]);


    // Convert comma-separated string to array for display
    const symptomsArray = formData.symptoms ? formData.symptoms.split(',').map(s => s.trim()).filter(Boolean) : [];

    const updateFormData = useCallback((updates) => {
        setFormData(prev => ({ ...prev, ...updates }));
    }, []);

    const updateVital = useCallback((field, value) => {
        setFormData(prev => ({
            ...prev,
            vitals: { ...prev.vitals, [field]: value }
        }));
    }, []);

    const handleKeyDown = useCallback((e) => {
        if (e.key === "Enter" && formData.symptomInput.trim()) {
            e.preventDefault();
            const newSymptom = formData.symptomInput.trim();
            const currentSymptoms = formData.symptoms ? formData.symptoms.split(',').map(s => s.trim()).filter(Boolean) : [];

            if (!currentSymptoms.includes(newSymptom)) {
                const updatedSymptoms = [...currentSymptoms, newSymptom].join(', ');
                setFormData(prev => ({
                    ...prev,
                    symptoms: updatedSymptoms,
                    symptomInput: ""
                }));
            } else {
                setFormData(prev => ({ ...prev, symptomInput: "" }));
            }
        }
    }, [formData.symptomInput, formData.symptoms]);

    const removeSymptom = useCallback((index) => {
        const currentSymptoms = formData.symptoms.split(',').map(s => s.trim()).filter(Boolean);
        const updatedSymptoms = currentSymptoms.filter((_, i) => i !== index).join(', ');
        setFormData(prev => ({
            ...prev,
            symptoms: updatedSymptoms
        }));
    }, [formData.symptoms]);

    const handleSave = useCallback(() => {
        const { symptomInput, ...dataToSave } = formData;

        const payload = {
            ...dataToSave,
            status: 10, // Save = 10
        };

        (async () => {
            await saveCaseStudy(payload);
        })();


    }, [formData]);

    const handleSaveComplete = useCallback(() => {
        const { symptomInput, ...dataToSave } = formData;

        const payload = {
            ...dataToSave,
            status: 6, // Save = 10
        };

        (async () => {
            await saveCaseStudy(payload);
        })();

    }, [formData]);


    const saveCaseStudy = async (payload) => {
        try {
            showLoader()
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Hospital/CaseStudySave`;
            const response = await axiosInstance.post(url, payload, {
                headers: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true
            });

            if (response.status == 200) {
                if (response.data.result == '1')
                    showToast("success", "Success!", "Saved & Completed successfully.")
                else if (response.data.result == '3')
                    showToast("success", "Success!", "Updated successfully.")
                else if (response.data.result == '2')
                    showToast("warning", "Draft!", "Saved as Draft.")
                else
                    showToast("error", "Error!", "Something went wrong");
            } else {
                showToast("error", "Error!", "Something went wrong");
            }
        } catch (error) {
            showToast("error", "Error!", error?.message || "Something went wrong");
            console.log(error?.message)
        } finally {
            hideLoader();
        }

    };

    const handleCancel = useCallback(() => {
        setFormData({
            symptoms: "",
            symptomInput: "",
            pastMedicalRecord: "",
            patientOverview: "",
            precaution: "",
            diagnosis: "",
            vitals: {
                bloodPressure: "",
                temperature: "",
                pulseRate: "",
                weight: "",
                height: ""
            }
        });
    }, []);

    const isFormValid = useMemo(() => {
        return formData.symptoms.trim().length > 0 &&
            formData.overview.trim() &&
            formData.precaution.trim();
    }, [formData.symptoms, formData.overview, formData.precaution]);

    return (
        <div className="min-h-screen bg-blue-100 rounded-md p-1 md:p-2 lg:p-8">
            <div className="max-w-9xl mx-auto">
                <div className="mb-4">
                    <h1 className="text-3xl font-bold text-gray-800 mb-2">Patient Consultation</h1>
                    <p className="text-gray-600">Document patient symptoms, history, and vital signs</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Left Column - Main Form */}
                    <div className="lg:col-span-2 space-y-6">
                        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                            {/* Symptoms */}
                            <div className="mb-6">
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Symptoms <span className="text-red-500">*</span>
                                </label>
                                <div
                                    className="border-2 border-gray-300 rounded-lg px-3 py-2 min-h-[100px] bg-gray-50 focus-within:border-blue-500 focus-within:bg-white transition-all cursor-text"
                                    onClick={() => document.getElementById("symptomInput")?.focus()}
                                >
                                    <div className="flex flex-wrap gap-2 mb-2">
                                        {symptomsArray.map((symptom, index) => (
                                            <Badge
                                                key={`${symptom}-${index}`}
                                                className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1.5 rounded-full flex items-center gap-2 text-sm"
                                            >
                                                {symptom}
                                                <button
                                                    type="button"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        removeSymptom(index);
                                                    }}
                                                    className="hover:bg-white/20 rounded-full p-0.5 transition-colors"
                                                    aria-label={`Remove ${symptom}`}
                                                >
                                                    <X className="w-3.5 h-3.5" />
                                                </button>
                                            </Badge>
                                        ))}
                                    </div>
                                    <input
                                        id="symptomInput"
                                        type="text"
                                        value={formData.symptomInput}
                                        onChange={(e) => updateFormData({ symptomInput: e.target.value })}
                                        onKeyDown={handleKeyDown}
                                        placeholder="Type a symptom and press Enter..."
                                        className="w-full outline-none bg-transparent text-sm text-gray-700 placeholder-gray-400"
                                    />
                                </div>
                                <p className="text-xs text-gray-500 mt-1">Press Enter to add each symptom</p>
                            </div>

                            {/* Past Medical Record */}
                            <div className="mb-6">
                                <label htmlFor="pastMedicalRecord" className="block text-sm font-semibold text-gray-700 mb-2">
                                    Past Medical Record
                                </label>
                                <textarea
                                    id="pastMedicalRecord"
                                    value={formData.pastRecords}
                                    onChange={(e) => updateFormData({ pastRecords: e.target.value })}
                                    placeholder="Add previous medical history, chronic conditions, surgeries, etc..."
                                    className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 min-h-[120px] text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors resize-none"
                                />
                            </div>

                            {/* Patient Overview */}
                            <div className="mb-6">
                                <label htmlFor="patientOverview" className="block text-sm font-semibold text-gray-700 mb-2">
                                    Patient Overview <span className="text-red-500">*</span>
                                </label>
                                <textarea
                                    id="patientOverview"
                                    value={formData.overview}
                                    onChange={(e) => updateFormData({ overview: e.target.value })}
                                    placeholder="Summarize patient condition, current concerns, and assessment..."
                                    className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 min-h-[120px] text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors resize-none"
                                />
                            </div>

                            {/* Precaution */}
                            <div className="mb-6">
                                <label htmlFor="precaution" className="block text-sm font-semibold text-gray-700 mb-2">
                                    Precaution <span className="text-red-500">*</span>
                                </label>
                                <textarea
                                    id="precaution"
                                    value={formData.precaution}
                                    onChange={(e) => updateFormData({ precaution: e.target.value })}
                                    placeholder="List precautions and care instructions for the patient..."
                                    className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 min-h-[120px] text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors resize-none"
                                />
                            </div>

                            {/* Diagnosis */}
                            <div>
                                <label htmlFor="diagnosis" className="block text-sm font-semibold text-gray-700 mb-2">
                                    Diagnosis
                                </label>
                                <textarea
                                    id="diagnosis"
                                    value={formData.diagnosis}
                                    onChange={(e) => updateFormData({ diagnosis: e.target.value })}
                                    placeholder="Enter diagnosis and treatment plan..."
                                    className="w-full border-2 border-gray-300 rounded-lg px-4 py-3 min-h-[120px] text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors resize-none"
                                />
                            </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="p-2">
                            <div className="flex flex-wrap justify-end gap-3">
                                <Button
                                    onClick={handleCancel}
                                    className="bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg px-6 shadow-none border border-gray-300"
                                >
                                    Cancel
                                </Button>
                                <Button
                                    onClick={handleSave}
                                    disabled={!isFormValid}
                                    className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-6 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    Save Draft
                                </Button>
                                <Button
                                    onClick={handleSaveComplete}
                                    disabled={!isFormValid}
                                    className="bg-green-600 hover:bg-green-700 text-white rounded-lg px-6 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    Save & Complete
                                </Button>
                            </div>
                        </div>
                    </div>

                    {/* Right Column - Vital Signs */}
                    <div className="lg:col-span-1">
                        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 sticky top-6">
                            <div className="flex items-center gap-2 mb-6">
                                <div className="bg-blue-100 p-2 rounded-lg">
                                    <Stethoscope size={20} className="text-blue-600" />
                                </div>
                                <h3 className="text-lg font-bold text-gray-800">Vital Signs</h3>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <label htmlFor="bloodPressure" className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                                        Blood Pressure
                                    </label>
                                    <input
                                        id="bloodPressure"
                                        type="text"
                                        placeholder="120/80 mmHg"
                                        value={formData.bloodPressure}
                                        onChange={(e) => updateFormData({ bloodPressure: e.target.value })}
                                        className="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="temperature" className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                                        Temperature
                                    </label>
                                    <input
                                        id="temperature"
                                        type="text"
                                        placeholder="98.6°F"
                                        value={formData.temperature}
                                        onChange={(e) => updateFormData({ temperature: e.target.value })}
                                        className="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="pulse" className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                                        Pulse Rate
                                    </label>
                                    <input
                                        id="pulse"
                                        type="text"
                                        placeholder="72 bpm"
                                        value={formData.pulseRate}
                                        onChange={(e) => updateFormData({ pulseRate: e.target.value })}
                                        className="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors"
                                    />
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label htmlFor="weight" className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                                            Weight
                                        </label>
                                        <input
                                            id="weight"
                                            type="text"
                                            placeholder="70 kg"
                                            value={formData.weight}
                                            onChange={(e) => updateFormData({ weight: e.target.value })}
                                            className="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors"
                                        />
                                    </div>

                                    <div>
                                        <label htmlFor="height" className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                                            Height
                                        </label>
                                        <input
                                            id="height"
                                            type="text"
                                            placeholder="175 cm"
                                            value={formData.height}
                                            onChange={(e) => updateFormData({ height: e.target.value })}
                                            className="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-sm text-gray-700 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition-colors"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PatientCaseStudy;