import { useState, useEffect } from 'react';
import { ShoppingCart, Plus, Minus, Trash2, Package, Search, Eye, Download, CheckCircle2 } from 'lucide-react';
import useShowToast from "../../Context/useShowToast";
import { useLoader } from "../../Context/LoaderProvider";
import axiosInstance from "../../Context/axiosInstance";
import { useConfirm } from "../../Context/ConfirmProvider";
import DefaultMeds from '../../../public/Images/DefaultMeds.jpg'
import { DataTable } from "../../components/custom/DataTable";
import { useCustomAlert } from '../../Context/CustomAlertProvider';

export default function PatientMedicine({ patientId }) {
    const user = localStorage.getItem('user')
    const [medicines, setMedicines] = useState([]);
    const [categories, setCategories] = useState([])
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const token = localStorage.getItem("token");
    const confirm = useConfirm()
    const alert = useCustomAlert()
    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast()
    const [cart, setCart] = useState([]);
    const [purchaseHistory, setPurchaseHistory] = useState([]);
    const [quantities, setQuantities] = useState({});
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [showHistory, setShowHistory] = useState(true);
    const columns = [
        {
            id: "actions",
            header: "Actions",
            size: 80,
            cell: ({ row }) => {
                const patient = row.original;
                return (
                    <div className="flex items-center gap-2">

                        {(patient.status === 'Completed') && (
                            <>
                                <button className="p-2 rounded bg-yellow-200 text-black hover:bg-white cursor-pointer"
                                    onClick={() => {
                                        setSelectedPdf(patient.fileBase64);
                                        setOpenPdf(true);
                                    }}
                                >
                                    <Eye size={16} />
                                </button>
                                <button className="p-2 rounded bg-green-200 text-black hover:bg-white cursor-pointer"
                                    onClick={() => downloadBase64Pdf(patient.fileBase64, patient.fileName)}
                                >
                                    <Download size={16} />
                                </button>
                            </>
                        )}
                        {(patient.status === 'Prescription Created') && (
                            <button onClick={() => cancelPrescription(patient.prescriptionId)} className="p-2 rounded-full bg-red-600 text-white hover:bg-white hover:text-black cursor-pointer">
                                <Trash2 size={16} />
                            </button>
                        )}

                    </div>
                );
            },
        },
        { accessorKey: "patientId", header: "patientId", hidden: true },
        { accessorKey: "inventoryId", header: "inventoryId", hidden: true },
        { accessorKey: "prescriptionId", header: "prescriptionId", hidden: true },
        { accessorKey: "orderId", header: "Order Id" },
        { accessorKey: "itemName", header: "Drug Name" },
        { accessorKey: "drugType", header: "Drug Type" },
        { accessorKey: "quantity", header: "Quantity", size: 80 },
        { accessorKey: "mrp", header: "MRP (₹)", size: 80 },
        { accessorKey: "prescribedBy", header: "Prescribed By" },
        {
            accessorKey: "status",
            header: "Status",
            size: 200,
            cell: ({ row }) => {
                const status = row.original.status;
                let color = ''
                switch (status) {
                    case "Prescription Created":
                        color = "bg-blue-600 text-white"
                        break;
                    case "Medicines Issued":
                        color = "bg-green-600 text-white"
                        break;
                    case "Cancelled":
                        color = "bg-red-600 text-white"
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700"
                        break;
                }
                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },

    ];

    useEffect(() => {
        getPharmacyInvtry()
        fetchPurchaseHistory()
    }, [])

    const getPharmacyInvtry = async () => {
        try {
            showLoader()
            const res = await axiosInstance.get(`${baseUrl}/api/Hospital/GetPharmacyInventory`, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200) {

                setMedicines(res.data.pharmainventory)
                setCategories([
                    {
                        categoryId: 0,
                        categoryName: "All",
                        categoryCode: "",
                        description: "",
                        createdAt: null,
                        createdBy: null,
                        modifiedAt: null,
                        modifiedBy: null,
                        jsonData: null,
                        isActive: true,
                        type: null,
                        fromDate: null,
                        toDate: null
                    },
                    ...res.data.drugcategory
                ])
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const fetchPurchaseHistory = async () => {
        try {
            showLoader()
            const url = `${baseUrl}/api/Hospital/GetPatientMedicineHistory?patientId=${patientId}&Type=${'PatientMedsHistory'}`
            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })
            if (res.status == 200 && res.data.length > 0) {
                setPurchaseHistory(res.data);
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const updateQuantity = (medicineId, change) => {
        setQuantities(prev => ({
            ...prev,
            [medicineId]: Math.max(1, (prev[medicineId] || 1) + change)
        }));
    };

    const addToCart = (medicine) => {
        
        const isPrescribed = purchaseHistory.find(item => item.inventoryId === medicine.inventoryId && medicine.status == 'Prescription Created')

        if(isPrescribed){
            alert({
                title: 'Already Prescribed',
                description: 'Prescription Already prescribed in pruchese list'
            })
            return;
        }
         
        const quantity = quantities[medicine.inventoryId] || 1;
        const existingItem = cart.find(item => item.inventoryId === medicine.inventoryId);

        if (existingItem) {
            setCart(cart.map(item =>
                item.inventoryId === medicine.inventoryId
                    ? { ...item, quantity: item.quantity + quantity }
                    : item
            ));
        } else {
            setCart([...cart, { ...medicine, quantity }]);
        }

        setQuantities(prev => ({ ...prev, [medicine.inventoryId]: 1 }));
    };

    const removeFromCart = (medicineId) => {
        setCart(cart.filter(item => item.inventoryId !== medicineId));
    };

    const updateCartQuantity = (medicineId, change) => {
        setCart(cart.map(item =>
            item.inventoryId === medicineId
                ? { ...item, quantity: Math.max(1, item.quantity + change) }
                : item
        ));
    };

    const getTotalPrice = () => {
        return cart.reduce((total, item) => total + (item.mrp * item.quantity), 0);
    };

    const checkout = async () => {
        try {
            if (cart.length === 0) return;
            let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want to prescribed selected medicines",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            showLoader()
            const payload = {
                patientId: patientId,
                JsonData: JSON.stringify(cart),
                type: "create_prescription",
            }

            const url = `${baseUrl}/api/Hospital/PrescriptionManage`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '1') {
                showToast('success', 'Success!', 'Prescription created successfully');
                setCart([])
                await fetchPurchaseHistory()

            } else if (res.status == 200 && res.data.result == '-1') {
                showToast('warning', 'Warning!', res.data.message);
            } else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    };

    const cancelPrescription = async (prescriptionId) => {
        try {
            let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want to cancel this Prescription",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            showLoader()

            const payload = {
                patientId,
                prescriptionId,
                type: "cancel_prescription",
            }

            const url = `${baseUrl}/api/Hospital/PrescriptionManage`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '2') {
                showToast('success', 'Success!', 'Prescription cancelled successfully');
                await fetchPurchaseHistory()
            }
            else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const filteredMedicines = medicines.filter(medicine => {
        const matchesSearch = medicine?.itemName?.toLowerCase().includes(searchTerm?.toLowerCase());
        const matchesCategory = selectedCategory === 'All' || medicine.categoryName === selectedCategory;
        return matchesSearch && matchesCategory;
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
            <div className="w-full mx-auto space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                            Pharmacy
                        </h1>
                        <p className="text-gray-600 mt-2">Order medicines and track your purchase history</p>
                    </div>

                    <button
                        onClick={() => setShowHistory(!showHistory)}
                        className="bg-blue-600 text-white px-4 py-2 rounded-xs hover:bg-blue-700 transition-colors text-xs font-semibold"
                    >
                        {showHistory ? 'Hide Purchase History' : 'Show Purchase History'}
                    </button>
                </div>

                {/* Dynamic Grid Layout */}
                <div className={`grid gap-6 transition-all duration-500 ${showHistory ? 'grid-cols-1 lg:grid-cols-3' : 'grid-cols-1'}`}>

                    {/* Purchase History Table */}
                    {showHistory && (
                        <div className="lg:col-span-2 bg-white rounded-lg shadow-lg p-6">
                            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <Package className="w-5 h-5 text-purple-600" />
                                Purchase History
                            </h2>

                            {purchaseHistory.length === 0 ? (
                                <div className="text-center py-12">
                                    <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                                    <p className="text-gray-500">No purchase history yet</p>
                                </div>
                            ) : (
                                <div className="overflow-x-auto">
                                    <DataTable
                                        columns={columns}
                                        data={purchaseHistory}
                                        pageSize={50}
                                        headerBgColor="bg-blue-800"
                                        headerTextColor="text-white"
                                    />
                                </div>
                            )}
                        </div>
                    )}

                    {/* Right Side - Cart and Medicines */}
                    <div className={`space-y-4 ${showHistory ? '' : 'flex flex-row-reverse gap-4'}`}>

                        {/* Shopping Cart */}
                        <div className={`bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg shadow-lg p-6 ${showHistory ? '' : 'w-1/3'}`}>
                            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <ShoppingCart className="w-5 h-5 text-purple-600" />
                                Cart ({cart.length})
                            </h2>

                            {cart.length === 0 ? (
                                <div className="text-center py-8">
                                    <ShoppingCart className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                                    <p className="text-gray-500">Your cart is empty</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <div className="max-h-80 overflow-y-auto space-y-2">
                                        {cart.map(item => (
                                            <div key={item.inventoryId} className="bg-white rounded-lg p-3 shadow-sm">
                                                <div className="flex items-start gap-3">
                                                    <img src={item.image ?? DefaultMeds} alt={item.itemName} className="w-16 h-16 rounded object-cover" />
                                                    <div className="flex-1">
                                                        <h4 className="font-semibold text-sm">{item.itemName}</h4>
                                                        <p className="text-indigo-600 font-bold text-sm">₹{item.mrp}</p>

                                                        <div className="flex items-center justify-between mt-2">
                                                            <div className="flex items-center gap-1 bg-gray-100 rounded">
                                                                <button
                                                                    onClick={() => updateCartQuantity(item.inventoryId, -1)}
                                                                    className="p-1 hover:bg-gray-200 rounded"
                                                                >
                                                                    <Minus className="w-3 h-3" />
                                                                </button>
                                                                <span className="px-2 text-sm font-semibold">{item.quantity}</span>
                                                                <button
                                                                    onClick={() => updateCartQuantity(item.inventoryId, 1)}
                                                                    className="p-1 hover:bg-gray-200 rounded"
                                                                >
                                                                    <Plus className="w-3 h-3" />
                                                                </button>
                                                            </div>

                                                            <button
                                                                onClick={() => removeFromCart(item.inventoryId)}
                                                                className="text-red-600 hover:text-red-800 p-1"
                                                            >
                                                                <Trash2 className="w-4 h-4" />
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>

                                    <div className="border-t pt-4">
                                        <div className="flex justify-between items-center mb-4">
                                            <span className="text-lg font-semibold">Total:</span>
                                            <span className="text-2xl font-bold text-indigo-600">₹{getTotalPrice()}</span>
                                        </div>

                                        <button
                                            onClick={checkout}
                                            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg hover:from-purple-700 hover:to-blue-700 transition-colors font-semibold flex items-center justify-center gap-2"
                                        >
                                            <CheckCircle2 className="w-4 h-4" />
                                            Checkout ({cart.length})
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Available Medicines */}
                        <div className={`bg-white rounded-lg shadow-lg p-6 ${showHistory ? '' : 'w-2/3'}`}>
                            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                                <Plus className="w-5 h-5 text-blue-600" />
                                Available Medicines
                            </h2>

                            <div className="space-y-4">
                                {/* Search Bar */}
                                <div className="relative">
                                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                    <input
                                        type="text"
                                        placeholder="Search medicines..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    />
                                </div>

                                {/* Category Filters */}
                                <div className="flex flex-wrap gap-2">
                                    {categories.map(category => (
                                        <button
                                            key={category.categoryName}
                                            onClick={() => setSelectedCategory(category.categoryName)}
                                            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${selectedCategory === category.categoryName
                                                ? 'bg-blue-600 text-white'
                                                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                                }`}
                                        >
                                            {category.categoryName}
                                        </button>
                                    ))}
                                </div>

                                {/* Medicine Grid */}
                                <div className={`max-h-96 overflow-y-auto ${showHistory ? 'space-y-3' : 'grid grid-cols-3 gap-3'}`}>
                                    {filteredMedicines.map(medicine => (
                                        <div key={medicine.inventoryId} className="bg-blue-50 border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                                            <img
                                                src={medicine.image ?? DefaultMeds}
                                                alt={medicine.itemName}
                                                className="w-full h-32 object-cover rounded-lg mb-3"
                                            />

                                            <div className="space-y-2">
                                                <div>
                                                    <h4 className="font-semibold text-sm">{medicine.itemName}</h4>
                                                    <p className="text-xs text-gray-500">{medicine.categoryName}</p>
                                                </div>

                                                <div className="flex items-center justify-between">
                                                    <span className="text-lg font-bold text-blue-600">₹{medicine.mrp}</span>
                                                    <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded">In Stock</span>
                                                </div>

                                                <div className="flex items-center justify-between gap-2">
                                                    <div className="flex items-center gap-1 bg-gray-100 rounded">
                                                        <button
                                                            onClick={() => updateQuantity(medicine.inventoryId, -1)}
                                                            className="p-1 hover:bg-gray-200 rounded"
                                                        >
                                                            <Minus className="w-3 h-3" />
                                                        </button>
                                                        <span className="px-2 text-sm font-semibold">{quantities[medicine.inventoryId] || 1}</span>
                                                        <button
                                                            onClick={() => updateQuantity(medicine.inventoryId, 1)}
                                                            className="p-1 hover:bg-gray-200 rounded"
                                                        >
                                                            <Plus className="w-3 h-3" />
                                                        </button>
                                                    </div>

                                                    <button
                                                        onClick={() => addToCart(medicine)}
                                                        disabled={cart.find(item => item.inventoryId === medicine.inventoryId)}
                                                        className={`px-3 py-1 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1 
                                                            ${cart.find(item => item.inventoryId === medicine.inventoryId)
                                                                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                                                                : 'bg-blue-600 text-white hover:bg-blue-700'
                                                            }`}
                                                    >
                                                        <Plus className="w-3 h-3" />
                                                        Add
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}