import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { DataTable } from "../../components/custom/DataTable";
import { motion, AnimatePresence } from "framer-motion";
import useShowToast from "../../Context/useShowToast";
import { useLoader } from "../../Context/LoaderProvider";
import axiosInstance from "../../Context/axiosInstance";
import { useConfirm } from "../../Context/ConfirmProvider";
import { Search, Plus, ShoppingCart, Download, Eye, Trash2, CheckCircle2 } from 'lucide-react';
import PdfDialogueReader from './PdfDialogueReader';

const PatientTestReport = ({ patientId }) => {

    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const token = localStorage.getItem("token");
    const confirm = useConfirm()
    const [searchTerm, setSearchTerm] = useState('');
    const [cart, setCart] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [showTable, setShowTable] = useState(true);
    const [availableTests, setAvailableTests] = useState([]);
    const [categories, setCategories] = useState([]);
    const [testHistory, setTestHistory] = useState([])
    const { showLoader, hideLoader } = useLoader()
    const [openPdf, setOpenPdf] = useState(false);
    const [selectedPdf, setSelectedPdf] = useState(null);
    const showToast = useShowToast()

    useEffect(() => {
        getMedicalTest()
        GetTestHistory()
    }, [])

    const getMedicalTest = async () => {
        try {
            showLoader()
            const res = await axiosInstance.get(`${baseUrl}/api/Hospital/GetMadicalTest&Cat`, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200) {

                setAvailableTests(res.data.medicalTest.filter(m => m.isActive == true))
                setCategories([
                    {
                        categoryId: 0,
                        categoryName: "All",
                        categoryCode: "All",
                        description: "",
                        createdAt: "",
                        createdBy: "Shivam Jaiswal",
                        modifiedAt: null,
                        modifiedBy: null,
                        jsonData: null,
                        isActive: true,
                        type: null,
                        fromDate: null,
                        toDate: null
                    },
                    ...res.data.testCategory.filter(m => m.isActive == true)
                ])
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const GetTestHistory = async () => {
        try {
            showLoader()
            const url = `${baseUrl}/api/Hospital/GetTestHistory?patientId=${patientId}&Type=${'PatientTestHistory'}`
            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })
            if (res.status == 200 && res.data.length > 0) {
                setTestHistory(res.data);
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const scheduleTest = async () => {
        try {

            let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want to schedule the test",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            showLoader()
            const payload = {
                patientId: patientId,
                JsonData: JSON.stringify(cart),
                type: "schedule",
            }

            const url = `${baseUrl}/api/Hospital/ScheduleTest`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '1') {
                showToast('success', 'Success!', 'Test schedule successfully');
                setCart([])
                await GetTestHistory()

            } else if (res.status == 200 && res.data.result == '-1') {
                showToast('warning', 'Warning!', res.data.message);
            } else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const cancelTest = async (scheduleId) => {
        try {
            let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want to cancel this test",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            showLoader()

            const payload = {
                patientId: patientId,
                scheduleId: scheduleId,
                type: "canceltest",
            }

            const url = `${baseUrl}/api/Hospital/ScheduleTest`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '2') {
                showToast('success', 'Success!', 'Test cancelled successfully');
                await GetTestHistory()
            }
            else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const columns = [
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const patient = row.original;
                return (
                    <div className="flex items-center gap-2">

                        {(patient.status === 'Completed') && (
                            <>
                                <button className="p-2 rounded bg-yellow-200 text-black hover:bg-white cursor-pointer"
                                    onClick={() => {
                                        setSelectedPdf(patient.fileBase64);
                                        setOpenPdf(true);
                                    }}
                                >
                                    <Eye size={16} />
                                </button>
                                <button className="p-2 rounded bg-green-200 text-black hover:bg-white cursor-pointer"
                                    onClick={() => downloadBase64Pdf(patient.fileBase64, patient.fileName)}
                                >
                                    <Download size={16} />
                                </button>
                            </>
                        )}
                        {(patient.status === 'Pending') && (
                            <button onClick={() => cancelTest(patient.scheduleId)} className="p-2 rounded bg-red-300 text-black hover:bg-white cursor-pointer">
                                <Trash2 size={16} />
                            </button>
                        )}

                    </div>
                );
            },
        },
        { accessorKey: "testName", header: "Test Name" },
        { accessorKey: "createdAt", header: "Date" },
        { accessorKey: "testId", header: "testId", hidden: true },
        { accessorKey: "scheduleId", header: "scheduleId", hidden: true },
        { accessorKey: "createdBy", header: "Doctor", hidden: true },
        { accessorKey: "categoryName", header: "Category" },
        { accessorKey: "fileBase64", header: "FileBase64", hidden: true },
        { accessorKey: "fileName", header: "FileName", hidden: true },
        {
            accessorKey: "status",
            header: "Status",
            cell: ({ row }) => {
                const status = row.original.status;
                let color = ''
                switch (status) {
                    case "Completed":
                        color = "bg-green-100 text-green-700"
                        break;
                    case "Pending":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Cancelled":
                        color = "bg-red-600 text-white"
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700"
                        break;
                }
                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },

    ];

    const addToCart = (test) => {
        if (!cart.find(item => item.testId === test.testId)) {
            setCart([...cart, test]);
        }
    };

    const removeFromCart = (testId) => {
        setCart(cart.filter(item => item.testId !== testId));
    };

    const filteredTests = availableTests.filter(test => {
        const matchesSearch = test.testName.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = selectedCategory === 'All' || test.categoryName === selectedCategory;
        return matchesSearch && matchesCategory;
    });

    const downloadBase64Pdf = (base64, fileName = "report.pdf") => {
        const link = document.createElement("a");
        link.href = `data:application/pdf;base64,${base64}`;
        link.download = fileName;
        link.click();
    };

    return (
        <div className="min-h-screen bg-blue-100 rounded-md p-6">
            <div className="max-w-9xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                            Patient Test Reports
                        </h1>
                        <p className="text-gray-600 mt-2">Manage and track medical test reports</p>
                    </div>

                    {/* Toggle Button */}
                    <Button
                        onClick={() => setShowTable(!showTable)}
                        className="bg-blue-600 text-white rounded-xs hover:bg-blue-700 text-xs h-8"
                    >
                        {showTable ? "Hide Test History" : "Show Test History"}
                    </Button>
                </div>

                {/* DYNAMIC GRID */}
                <div className={`grid gap-6 transition-all duration-500 
                    ${showTable ? "grid-cols-1 lg:grid-cols-3" : "grid-cols-1"}
                `}>

                    {/* Animated DataTable */}
                    <AnimatePresence>
                        {showTable && (
                            <motion.div
                                className="lg:col-span-2"
                                initial={{ opacity: 0, y: -20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -20 }}
                                transition={{ duration: 0.2 }}
                            >
                                <DataTable
                                    columns={columns}
                                    data={testHistory}
                                    pageSize={50}
                                    headerBgColor="bg-blue-800"
                                    headerTextColor="text-white"
                                />
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {/* Test Cart + Add Test (Right side) */}
                    <div className={`space-y-4 ${showTable ? "" : "flex flex-row-reverse gap-2"}`}>
                        {/* Shopping Cart */}
                        <Card className={`border-none shadow-lg bg-gradient-to-br from-purple-50 to-blue-50 ${showTable ? "" : "w-1/3"}`}>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <ShoppingCart className="h-5 w-5 text-purple-600" />
                                    Test Cart ({cart.length})
                                </CardTitle>
                                <CardDescription>Tests to be ordered</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {cart.length === 0 ? (
                                    <div className="text-center py-8 text-gray-500">
                                        <ShoppingCart className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                                        <p>No items in cart</p>
                                    </div>
                                ) : (
                                    <div className="space-y-2">
                                        <ScrollArea className="h-[200px]">
                                            {cart.map((item) => (
                                                <div key={item.id} className="flex items-center justify-between p-3 bg-green-200 rounded-lg mb-2 shadow-sm">
                                                    <div className="flex-1">
                                                        <p className="font-medium text-sm">{item.testName}</p>
                                                        <p className="text-xs text-gray-500">{item.mrp} ₹</p>
                                                    </div>
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => removeFromCart(item.testId)}
                                                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                                    >
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            ))}
                                        </ScrollArea>
                                        <Separator className="my-4" />
                                        <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                                            onClick={scheduleTest}
                                        >
                                            <CheckCircle2 className="mr-2 h-4 w-4" />
                                            Schedule Tests ({cart.length})
                                        </Button>
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {/* Available Tests */}
                        <Card className={`border-none shadow-lg ${showTable ? "" : "w-2/3"}`}>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Plus className="h-5 w-5 text-blue-600" />
                                    Add New Tests
                                </CardTitle>
                                <CardDescription>Browse and add tests to cart</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="relative">
                                        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                        <Input
                                            placeholder="Search tests..."
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                            className="pl-10"
                                        />
                                    </div>

                                    <div className="flex flex-wrap gap-2">
                                        {categories.map((category) => (
                                            <Button
                                                key={category.categoryName}
                                                variant={selectedCategory === category.categoryName ? "default" : "outline"}
                                                size="sm"
                                                onClick={() => setSelectedCategory(category.categoryName)}
                                                className={selectedCategory === category.categoryName ? "bg-blue-600" : ""}
                                            >
                                                {category.categoryName}
                                            </Button>
                                        ))}
                                    </div>

                                    <ScrollArea className="h-[400px]">
                                        <div className={showTable ? "space-y-4" : `grid grid-cols-3 gap-2`}>
                                            {filteredTests.map((test) => (
                                                <Card key={test.id} className="border border-gray-200 bg-blue-100 hover:border-blue-300 transition-colors">
                                                    <CardContent className="p-4">
                                                        <div className="flex items-start justify-between mb-2">
                                                            <div className="flex-1">
                                                                <h4 className="font-medium text-sm">{test.testName}</h4>
                                                                <p className="text-xs text-gray-500">{test.categoryName}</p>
                                                            </div>
                                                            <Badge variant="outline" className="text-xs">
                                                                Sample: {test.sampleType}
                                                            </Badge>
                                                        </div>
                                                        <div className="flex items-center justify-between">
                                                            <span className="text-lg font-bold text-blue-600">{test.mrp} ₹</span>
                                                            <Button
                                                                size="sm"
                                                                onClick={() => addToCart(test)}
                                                                disabled={cart.find(item => item.testId === test.testId)
                                                                    || testHistory.find(item => item.testId === test.testId && item.status === 'Pending')}
                                                                className={testHistory.find(item => item.testId === test.testId && item.status === 'Pending') ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"}
                                                            >
                                                                <Plus className="h-4 w-4 mr-1" />
                                                                Add
                                                            </Button>
                                                        </div>
                                                    </CardContent>
                                                </Card>
                                            ))}
                                        </div>
                                    </ScrollArea>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>

                <PdfDialogueReader
                    open={openPdf}
                    onClose={() => setOpenPdf(false)}
                    base64Pdf={selectedPdf}
                    title="Patient Report"
                />
            </div>
        </div>
    );
};

export default PatientTestReport;