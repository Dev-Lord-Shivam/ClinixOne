import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

const PdfDialogueReader = ({ open, onClose, base64Pdf, title = "View Report" }) => {
    const [pdfUrl, setPdfUrl] = useState(null);


    useEffect(() => {
        if (base64Pdf) {
            const url = `data:application/pdf;base64,${base64Pdf}`;
            setPdfUrl(url);
        }
    }, [base64Pdf]);


    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="!max-w-4xl w-full p-0 overflow-hidden">
                <DialogHeader className="flex flex-row items-center justify-between p-4 border-b">
                    <DialogTitle className="text-lg font-semibold">{title}</DialogTitle>
                </DialogHeader>


                <div className="w-full h-[80vh] bg-gray-100">
                    {pdfUrl ? (
                        <iframe
                            src={pdfUrl}
                            title="PDF Viewer"
                            className="w-full h-full border-0"
                        />
                    ) : (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            No PDF available
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}

export default PdfDialogueReader
