import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ShoppingCart, Trash2, CheckCircle2, Plus, Search } from 'lucide-react';
import useShowToast from "../../Context/useShowToast";
import { useLoader } from "../../Context/LoaderProvider";
import axiosInstance from "../../Context/axiosInstance";
import { useConfirm } from "../../Context/ConfirmProvider";
import { DataTable } from "../../components/custom/DataTable";
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useCustomAlert } from "../../Context/CustomAlertProvider";

const PharmaBilling = ({ patientid }) => {

    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const token = localStorage.getItem("token");
    const confirm = useConfirm()
    const alert = useCustomAlert()
    const showToast = useShowToast()
    const { showLoader, hideLoader } = useLoader()
    const [prescriptionList, setPrescriptionList] = useState([]);
    const [cart, setCart] = useState([]);
    const columns = [
        {
            id: "actions",
            header: "Actions",
            size: 80,
            cell: ({ row }) => {
                const patient = row.original;
                return (
                    <div className="flex items-center gap-2">

                        {(patient.status === 'Prescription Created') && (
                            <button onClick={() => cancelMeds(patient.prescriptionId)} className="p-2 rounded bg-red-300 text-black hover:bg-white cursor-pointer">
                                <Trash2 size={16} />
                            </button>
                        )}

                    </div>
                );
            },
        },
        { accessorKey: "itemName", header: "Drug Name" },
        { accessorKey: "drugType", header: "Drug Type", size: 100 },
        { accessorKey: "quantity", header: "Quantity", size: 80 },
        { accessorKey: "orderId", header: "orderId", hidden: true },
        { accessorKey: "scheduleId", header: "scheduleId", hidden: true },
        { accessorKey: "prescribedBy", header: "Prescribed By" },
        { accessorKey: "createdAt", header: "Prescribed On", size: 120 },
        { accessorKey: "mrpParQty", header: "MRP (₹)", size: 80 },
        { accessorKey: "stockQty", header: "Stock", size: 80 },
        {
            accessorKey: "status",
            header: "Status",
            size: 180,
            cell: ({ row }) => {
                const status = row.original.status;
                let color = ''
                switch (status) {
                    case "Prescription Created":
                        color = "bg-green-100 text-green-700"
                        break;
                    case "Pending":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Cancelled":
                        color = "bg-red-600 text-white"
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700"
                        break;
                }
                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },

    ];

    useEffect(() => {
        fetchPrescriptionByPatient()
    }, [patientid])

    const fetchPrescriptionByPatient = async () => {
        try {
            if (!patientid) return
            showLoader()
            const url = `${baseUrl}/api/Hospital/GetPatientMedicineHistory?patientId=${patientid}&Type=${'PatientMedsHistory'}`
            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })
            if (res.status == 200 && res.data.length > 0) {
                setPrescriptionList(res.data.filter(m => m.status === 'Prescription Created'));
            } else {
                setPrescriptionList([])
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const handleBillingSubmit = async () => {
        let confirmOptions = {
            title: "Are you sure",
            description: "Are you sure, you want to confirm payment",
            confirmText: "Yes",
            cancelText: "No",
            intent: "danger",
        };

        const confirmed = await confirm(confirmOptions);
        if (!confirmed) return;

        try {
            showLoader();

            const payload = {
                JsonData: JSON.stringify(cart),
                Type: 'medspayment'
            }

            const url = `${baseUrl}/api/Hospital/ScheduleTest`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '7') {
                showToast('success', 'Success!', 'Payment confirm successfully');
                setCart([])
                setPrescriptionList([])
                await fetchPrescriptionByPatient()
            }
            else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader();
        }
    }

    const cancelMeds = async (prescriptionId) => {
        try {
            const exists = cart.find(m => m.prescriptionId === prescriptionId)?.itemName
            if (exists) {
                alert({
                    title: 'Alert',
                    description: `Remove ${exists} from cart before cancelling`
                })
                return;
            }

            let confirmOptions = {
                title: "Are you sure",
                description: "Are you sure, you want to cancel this prescription",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            showLoader()

            const payload = {
                patientId: patientid,
                scheduleId: prescriptionId,
                type: "cancelPrescription",
            }

            const url = `${baseUrl}/api/Hospital/ScheduleTest`
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status == 200 && res.data.result == '6') {
                showToast('success', 'Success!', res.data.statusMessage);
                await fetchPrescriptionByPatient()
            }
            else {
                showToast('error', 'Error!', 'Internal Server Error')
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const grandTotal = cart.reduce(
        (sum, item) => sum + item.mrp * item.quantity,
        0
    )

    const updateQuantity = (id, qty, stockQty) => {
        if (qty < 1) return
        setCart((prev) =>
            prev.map((item) =>
                item.prescriptionId === id ? { ...item, quantity: Math.min(qty, stockQty) } : item
            )
        )
    }
    
    return (
        <div className="min-h-screen bg-blue-100 rounded-md p-4">

            <div className={`flex flex-row gap-4`}>
                <div className="w-2/3">
                    <DataTable
                        columns={columns}
                        data={prescriptionList}
                        pageSize={50}
                        headerBgColor="bg-blue-700"
                        headerTextColor="text-white"
                        enableMultiSelect={true}
                        onSelectRow={(rows) => setCart(rows)}
                    />
                </div>
                <div className={"w-2/3"}>
                    {/* Shopping Cart */}
                    <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-50">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <ShoppingCart className="h-5 w-5 text-purple-600" />
                                Drug Cart ({cart.length})
                            </CardTitle>
                            <CardDescription>Tests to be ordered</CardDescription>
                        </CardHeader>

                        <CardContent>
                            {cart.length === 0 ? (
                                <div className="text-center py-8 text-gray-500">
                                    <ShoppingCart className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                                    <p>No items in cart</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <ScrollArea className="h-[200px]">
                                        <div className="space-y-2 pr-4">
                                            {cart.map((item) => (
                                                <div
                                                    key={item.id}
                                                    className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm border border-purple-100 hover:border-purple-300 transition-colors"
                                                >
                                                    <div className="flex-1">
                                                        <p className="font-medium text-sm text-gray-800">
                                                            {item.itemName}
                                                        </p>

                                                        <div className="flex items-center gap-2 mt-2">
                                                            <span className="text-sm text-gray-600">
                                                                ₹{item.mrpParQty} ×
                                                            </span>

                                                            <input
                                                                type="number"
                                                                min="1"
                                                                value={item.quantity}
                                                                onChange={(e) =>
                                                                    updateQuantity(item.prescriptionId, Number(e.target.value), item.stockQty)
                                                                }
                                                                className="w-16 px-2 py-1 text-sm border rounded-md focus:outline-none focus:ring-1 focus:ring-purple-400"
                                                            />
                                                        </div>
                                                    </div>

                                                    <div className="text-right">
                                                        <p className="text-xs text-gray-500">Total</p>
                                                        <p className="text-md font-bold text-purple-700">
                                                            ₹{(item.mrpParQty * Math.min(item.quantity, item.stockQty)).toFixed(2)}
                                                        </p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </ScrollArea>

                                    <Separator className="my-4" />

                                    {/* Grand Total */}
                                    <div className="bg-gradient-to-r from-purple-200 to-purple-300 rounded-md p-3">
                                        <div className="flex justify-between items-center">
                                            <span className="text-md font-bold text-gray-800">
                                                Grand Total
                                            </span>
                                            <span className="text-xl font-bold text-purple-700">
                                                ₹{grandTotal.toFixed(2)}
                                            </span>
                                        </div>
                                    </div>

                                    <Button
                                        size="sm"
                                        className="w-full bg-gradient-to-r from-purple-300 to-purple-600 hover:from-purple-700 hover:to-purple-700 text-black font-semibold py-6 shadow-md hover:shadow-lg transition-all"
                                        onClick={handleBillingSubmit}
                                    >
                                        <CheckCircle2 className="mr-2 h-5 w-5" />
                                        Confirm payment ({cart.length})
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    )
}

export default PharmaBilling
