import { useState } from "react";
import {
    Dialog,
    DialogTrigger,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogOverlay
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus, Minus } from "lucide-react";
import { DataTable } from "./DataTable";

const MedicinesColumns = (quantities, updateQty) => [
    {
        accessorKey: "image",
        header: "Image",
        enableColumnFilter: false,
        cell: ({ row }) => (
            <img
                src={row.original.image}
                alt="med"
                className="w-16 h-16 rounded object-cover border"
            />
        ),
    },
    {
        accessorKey: "name",
        header: "Name",
        enableColumnFilter: true,
    },
    {
        accessorKey: "type",
        header: "Type",
        enableColumnFilter: true,
    },
    {
        accessorKey: "price",
        header: "Price",
        enableColumnFilter: true,
    },
    {
        accessorKey: "stock",
        header: "Stock",
        enableColumnFilter: false,
    },
    {
        accessorKey: "quantity",
        header: "Quantity",
        enableColumnFilter: false,
        cell: ({ row }) => (
            <div className="flex items-center gap-2">
                <Button
                    size="sm"
                    variant="outline"
                    onClick={() => updateQty(row.index, -1)}
                >
                    <Minus className="w-4 h-4" />
                </Button>
                <span className="w-6 text-center">{quantities[row.index]}</span>
                <Button
                    size="sm"
                    variant="outline"
                    onClick={() => updateQty(row.index, 1)}
                >
                    <Plus className="w-4 h-4" />
                </Button>
            </div>
        ),
    },
    {
        accessorKey: "id",
        header: "id",
        enableColumnFilter: true,
        hidden: true,
    },
];

const medicines = [
    {
        id: 1,
        name: "Paracetamol",
        type: "Analgesic",
        price: 25,
        stock: 1000,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTAOpR9KjF2kTFr4kP6e31RHPi_s0E-bUGVPg&s",
    },
    {
        id: 2,
        name: "Amoxicillin",
        type: "Antibiotic",
        price: 60,
        stock: 459,
        image: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Medicine_Drugs.svg/2560px-Medicine_Drugs.svg.png",
    },
    {
        id: 3,
        name: "Cetirizine",
        type: "Antihistamine",
        price: 15,
        stock: 690,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTAOpR9KjF2kTFr4kP6e31RHPi_s0E-bUGVPg&s",
    },
    {
        id: 4,
        name: "Ibuprofen",
        type: "Analgesic",
        price: 30,
        stock: 1200,
        image: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Medicine_Drugs.svg/2560px-Medicine_Drugs.svg.png",
    },
];

export default function QuickAdd() {
    const [quantities, setQuantities] = useState(() =>
        medicines.map(() => 0)
    );

    function updateQty(index, delta) {
        setQuantities((prev) => {
            const updated = [...prev];
            updated[index] = Math.max(0, updated[index] + delta); // prevent negative qty
            return updated;
        });
    }
    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button className="bg-blue-700 text-xs h-8 rounded hover:bg-blue-800">
                    Quick Add
                </Button>
            </DialogTrigger>
            <DialogOverlay className="fixed inset-0 bg-black/40 backdrop-blur-md z-50" />
            <DialogContent className="!max-w-5xl !w-full !h-[80vh]">
                <DialogHeader>
                    <DialogTitle>Medicine Inventory</DialogTitle>
                </DialogHeader>

                {/* Table */}
                <DataTable
                    columns={MedicinesColumns(quantities, updateQty)}
                    data={medicines}
                    pageSize={3}
                />
            </DialogContent>
        </Dialog>
    );
}
