import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button"
import {
    Dialog, DialogClose, DialogContent, DialogDescription,
    DialogFooter, DialogHeader, DialogTitle, DialogOverlay
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, ChevronRight } from 'lucide-react';
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import axiosInstance from "../../Context/axiosInstance";

const RescheduleApt = ({ isOpen, onClose, appointment, setUpcomingApt }) => {

    const token = localStorage.getItem("patienttoken");
    const userInfo = JSON.parse(localStorage.getItem("patient"));
    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast()
    const [monthDD, setMonthDD] = useState([])
    const [selectedMonth, setSelectedMonth] = useState('');
    const [selectedDate, setSelectedDate] = useState('');
    const [availableDates, setAvailableDates] = useState([]);

    useEffect(() => {
        if (!appointment?.doctorId) return;
        const fetchShift = async () => {
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=Get_BookingOpenMonth`;
            const res = await axiosInstance.get(url)
            if (res.status === 200 && res.data) {
                setMonthDD(res.data.map(item => ({
                    label: item.text,
                    value: item.value
                })));
            }
            else {
                showToast('error', 'error!', res.error || 'something went wrong')
                return
            }
            setSelectedMonth(res.data[0].value)
            const [year, month, day] = appointment.aptDate.split(" ");
            const formattedDateObj = `${day}/${month}/${year}`;
            setSelectedDate(formattedDateObj)
            await getShiftByIdAndMonth(res.data[0].value);
        };
        fetchShift();
    }, [appointment]);


    const getShiftByIdAndMonth = async (month) => {
        try {
            showLoader();
            let url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/GetDoctorsByShift`;
            const res = await axiosInstance.get(url, {
                params: {
                    doctorId: appointment.doctorId,
                    monthName: month,
                    date: appointment.aptDate,
                    type: 'GetDoctorShiftByMonthDate'
                },
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            });
            if (res.status === 200 && res.data) {
                console.log(res.data)
                setAvailableDates(res.data);
            }
            else {
                showToast('error', 'error!', res.error)
            }
        } catch (error) {

        } finally {
            hideLoader()
        }
    }

    const handleDateSelect = (date) => {
        setSelectedDate(date);
    };

    const cnfRescheduleApt = async () => {
        try {
            showLoader();
            const payload = {
                PatientId: userInfo?.patientId,
                AptId: appointment.aptId,
                DoctorId: appointment.doctorId,
                AptDate: selectedDate,
                Type: 'Reschedule_Appointment'
            }
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/AptInsertUpdate`;
            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            })
            
            if(res.status === 200 && res.data.length > 0){
                 setUpcomingApt(res.data)
                 showToast('success','Success', 'Appointment reschedule successfully')
                 onClose(false)
            }
            else {
                showToast('error','Error!', res.error || 'Failed to reschedule successfully')
            }
        } catch (error) {
             showToast('error','Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader();
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogOverlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center" />
            <DialogContent className="!max-w-4xl !w-full p-6">
                <DialogHeader>
                    <DialogTitle>Reschedule appointment</DialogTitle>
                    {/* <DialogDescription>
                        This action cannot be undone after confirmation.
                    </DialogDescription> */}
                </DialogHeader>

                <div className='flex flex-row w-full'>
                    <div className='w-full'>
                        <div className="flex justify-between items-center w-full mb-4">
                            {/* Heading with Icon */}
                            <h3 className="w-2/4 text-lg font-semibold flex items-center text-gray-800">
                                <Calendar className="w-5 h-5 mr-2 text-green-600" />
                                Next Available Date
                            </h3>

                            {/* Month Dropdown */}
                            <div className='w-1/4'>
                                <Select onValueChange={(val) => {
                                    setSelectedMonth(val);
                                    getShiftByIdAndMonth(val);
                                }} value={selectedMonth}>
                                    <SelectTrigger className="form-control w-[160px]">
                                        <SelectValue placeholder="Change Month" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectGroup>
                                            <SelectLabel>Available Months</SelectLabel>
                                            {monthDD.map((item) => (
                                                <SelectItem key={item.value} value={item.value}>
                                                    {item.label}
                                                </SelectItem>
                                            ))}
                                        </SelectGroup>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="grid grid-cols-5 gap-2">

                            {availableDates.map((dateObj) => {
                                const isActive = dateObj.isActive === true; // assuming 1=available, 0=unavailable
                                const isSelected = selectedDate === dateObj.date && isActive; // only allow selection if active

                                return (
                                    <button
                                        key={dateObj.date}
                                        onClick={() => isActive && handleDateSelect(dateObj.date)}
                                        disabled={!isActive}
                                        className={`w-full p-2 text-left text-sm border rounded-sm flex items-center justify-between transition-all
                                        ${!isActive
                                                ? 'bg-gray-200 text-gray-400 border-gray-300 cursor-not-allowed opacity-70' // disabled style
                                                : isSelected
                                                    ? 'bg-red-400 text-white border-red-700 hover:bg-red-600' // selected style
                                                    : 'bg-green-200 border-gray-200 hover:border-green-600 hover:bg-green-50' // normal style
                                            }`}
                                    >
                                        <span className="font-medium">
                                            {`${dateObj.dayName.slice(0, 3)}, ${dateObj.monthName.slice(0, 3)} ${dateObj.date.slice(0, 2)}`}
                                        </span>
                                        <ChevronRight
                                            className={`w-5 h-5 ${isSelected ? 'text-white' : isActive ? 'text-gray-400' : 'text-gray-300'
                                                }`}
                                        />
                                    </button>
                                );
                            })}


                        </div>
                        {availableDates.length === 0 && (
                            <div className="text-center py-12">
                                <div className="text-gray-500 mb-2">No Slot Available in the {selectedMonth}</div>
                                <div className="text-sm text-gray-400">
                                    Try for next month
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                <DialogFooter className="sm:justify-end mt-4">
                    <DialogClose asChild>
                        <Button type="button" className='bg-green-700 text-white text-xs rounded-xs h-8 cursor-pointer'>
                            Close
                        </Button>
                    </DialogClose>
                    <Button className='rounded-xs h-8 text-xs cursor-pointer' type="button" variant="destructive"
                            onClick={cnfRescheduleApt}
                    >
                        Confirm
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

export default RescheduleApt
