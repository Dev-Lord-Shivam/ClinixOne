import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogOverlay } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const RoleDialogue = ({ open, onClose, onSubmit, isEdit, roleData }) => {

    const [roleName, setRoleName] = useState("");
    const [portalType, setPortalType] = useState("");
    const [isActive, setIsActive] = useState(true);

    useEffect(() => {
        if (isEdit && roleData) {
            setRoleName(roleData.roleName);
            setPortalType(roleData.portalType);
            setIsActive(roleData.isActive);
        } else {
            setRoleName("");
            setPortalType("");
            setIsActive(true);
        }
    }, [isEdit, roleData]);

    const handleSubmit = (e) => {
        e?.preventDefault();
        onSubmit({
            roleName,
            portalType,
            isActive
        });
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogOverlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center" />
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>
                        {isEdit ? "Edit Role" : "Add Role"}
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-4">
                    {/* Role Name */}
                    <div>
                        <Label>Role Name</Label>
                        <Input
                            className='mt-2 form-control'
                            value={roleName}
                            onChange={(e) => setRoleName(e.target.value)}
                            placeholder="Enter role name"
                        />
                    </div>

                    {/* Portal Type */}
                    <div>
                        <Label>Portal Type</Label>
                        <select
                            value={portalType}
                            onChange={(e) => setPortalType(e.target.value)}
                            className="w-full border rounded p-2 mt-2 form-control"
                        >
                            <option value="">Select Portal</option>
                            <option value="Hospital">Hospital</option>
                            <option value="Patient">Patient</option>
                        </select>
                    </div>

                    {/* Status - only for edit */}
                    {isEdit && (
                        <div>
                            <Label>Status</Label>
                            <RadioGroup
                                value={isActive ? "true" : "false"}
                                onValueChange={(v) => setIsActive(v === "true")}
                                className="flex gap-4 mt-2"
                            >
                                <div className="flex items-center space-x-2">
                                    <RadioGroupItem
                                        className='border-2 border-gray-500'
                                        value="true" id="active"
                                    />
                                    <Label htmlFor="active">Active</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <RadioGroupItem className='border-2 border-gray-500' value="false" id="inactive" />
                                    <Label htmlFor="inactive">Inactive</Label>
                                </div>
                            </RadioGroup>
                        </div>
                    )}

                    <div className="flex justify-end gap-2">
                        <Button variant="outline"
                            type="button"
                            className='bg-red-700 text-white text-xs rounded-xs h-8 cursor-pointer'
                            onClick={onClose}>
                            Cancel
                        </Button>
                        <Button
                            type="button"
                            className='rounded-xs h-8 bg-green-700 text-xs cursor-pointer'
                            onClick={handleSubmit}>
                            {isEdit ? "Update" : "Add"}
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default RoleDialogue;
