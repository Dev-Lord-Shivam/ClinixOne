import { useState } from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Command, CommandInput, CommandList, CommandEmpty, CommandItem } from "@/components/ui/command";
import { Label } from "@/components/ui/label";
import { ChevronDown, Check } from "lucide-react";
import { cn } from "@/lib/utils"; // Required for conditional classNames

export default function SearchableDD({
  options = [],
  value = "",
  onChange = () => { },
  label = "",
  placeholder = "Select an option",
  required = false,
  className = ""
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="w-full">
      {label && (
        <Label className="mb-2 block">
          {label} {required && <span className="text-red-600">*</span>}
        </Label>
      )}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild className={`${className} h-9`}>
          <button
            type="button"
            role="combobox"
            className={cn(
              "w-full bg-white rounded border p-2 flex justify-between items-center",
              !value && "text-gray-500"
            )}
          >
            {options.find(opt => opt.value === value)?.label || placeholder}
            <ChevronDown className="ml-2 h-4 w-4 opacity-50" />
          </button>
        </PopoverTrigger>
        <PopoverContent className="p-0" align="start" style={{ width: 'var(--radix-popover-trigger-width)' }}>
          <Command>
            <CommandInput placeholder="Search..." />
            <CommandList>
              <CommandEmpty>No option found.</CommandEmpty>
              {options.map((option) => (
                <CommandItem
                  key={option.value}
                  value={option.label}
                  onSelect={(selectedLabel) => {
                    const selectedOption = options.find(opt => opt.label === selectedLabel);
                    if (selectedOption) {
                      onChange(selectedOption.value); // set value, not label
                      setOpen(false);
                    }
                  }}

                >
                  <Check
                    className={cn("mr-2 h-4", value === option.value ? "opacity-100" : "opacity-0")}
                  />
                  {option.label}
                </CommandItem>
              ))}

            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}
