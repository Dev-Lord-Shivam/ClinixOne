import { useEffect, useState } from "react";
import { Check, FileText, CircleX, Undo2, Search, Plus, Type, Download, ThumbsUp, ThumbsDown, Ban } from "lucide-react";
import { DataTable } from "../../components/custom/DataTable";
import CustomDatePicker from "../../components/custom/CustomDatePicker";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useSelector } from "react-redux";
import { useLoader } from "../../Context/LoaderProvider";
import axiosInstance from "../../Context/axiosInstance";
import useShowToast from "../../Context/useShowToast";
import SearchableDD from "../../components/custom/SearchableDD";
import { useConfirm } from "../../Context/ConfirmProvider";
import RescheduleAptHospital from "../../components/custom/RescheduleAptHospital";

const ApptManagement = () => {

    const formatDate = (date) => {
        const d = new Date(date);
        const day = String(d.getDate()).padStart(2, "0");
        const month = String(d.getMonth() + 1).padStart(2, "0");
        const year = d.getFullYear();
        return `${day}/${month}/${year}`; // → dd/MM/yyyy
    };
    const { deptlist, deptloading } = useSelector((state) => state.departments)
    const today = formatDate(new Date());

    const token = localStorage.getItem("token");
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast()
    const confirm = useConfirm();
    const [fromDate, setFromDate] = useState(today);
    const [toDate, setToDate] = useState(today);
    const [dept, setDept] = useState([]);
    const [selectedDept, setSelectedDept] = useState("");
    const [patients, setPatients] = useState([])
    const [openResModel, setOpenResModel] = useState(false)
    const [selectedApt, setSeletedApt] = useState({})

    useEffect(() => {
        fetchApt()
    }, [])

    useEffect(() => {
        if (deptlist && Array.isArray(deptlist)) {
            const mappedDept = deptlist.map(dep => ({
                label: dep.deptName,
                value: dep.deptId.toString(),
            }));
            // Append "All" option at the top
            setDept([{ label: "All", value: "" }, ...mappedDept]);
        }
    }, [deptlist]);

    const fetchApt = async () => {
        try {
            showLoader()
            const res = await axiosInstance.get(`${baseUrl}/api/Hospital/GetAppointment`, {
                params: {
                    Type: 'GetAllApt_BwtDate',
                    FromDate: fromDate,
                    ToDate: toDate
                },
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            })

            if (res.status === 200 && res.data.length > 0) {
                setPatients(res.data);
            }

        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    const ActionFunction = async (AptId, Type) => {
        try {
            // Step 1: Determine confirmation message dynamically
            let confirmOptions = {
                title: "Are you sure?",
                description: "",
                confirmText: "Yes",
                cancelText: "No",
                intent: "danger",
            };

            switch (Type) {
                case "CheckIn_Patient":
                    confirmOptions.description = "Are you sure you want to check in this patient?";
                    break;
                case "Undo_CheckIn":
                    confirmOptions.description = "Are you sure you want to undo the check-in?";
                    break;
                case "Not_Visited":
                    confirmOptions.description = "Are you sure you want to mark this appointment as not visited?";
                    break;
                case "Cancel_Appointment":
                    confirmOptions.description = "Are you sure you want to cancel this appointment?";
                    break;
                default:
                    showToast("error", "Error!", "Invalid action type");
                    return;
            }

            // Step 2: Ask for confirmation
            const confirmed = await confirm(confirmOptions);
            if (!confirmed) return;

            // Step 3: Execute API call
            showLoader();

            const url = `${baseUrl}/api/Hospital/UpdateAptStatus`;
            const params = {
                Type: Type,
                AptId: AptId,
            };

            const res = await axiosInstance.get(url, {
                params,
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            });

            // Step 4: Handle response
            if (res.status === 200) {
                switch (Type) {
                    case "CheckIn_Patient":
                        showToast("info", "Checked In", "Patient checked in successfully");
                        break;
                    case "Undo_CheckIn":
                        showToast("info", "Undone", "Patient check-in has been undone");
                        break;
                    case "Not_Visited":
                        showToast("info", "Updated", "Patient marked as not visited");
                        break;
                    case "Cancel_Appointment":
                        showToast("info", "Updated", "Appointment cancelled successfully");
                        break;
                }
                await fetchApt();
            } else {
                showToast("error", "Error!", "Failed to update appointment");
            }
        } catch (error) {
            showToast("error", "Error!", error.message || "Something went wrong");
        } finally {
            hideLoader();
        }
    };

    const handleRescheuleApt = (patient) => {
        setSeletedApt(patient);
        setOpenResModel(true);
    }

    const filteredPatients =
        selectedDept === ""
            ? patients
            : patients.filter((p) => p.deptId == selectedDept);

    const columns = [
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const patient = row.original;
                const istoday = formatDate(new Date()) === patient.aptDate

                if (istoday) {
                    return (
                        <div className="flex items-center gap-2">
                            {patient.aptStatus === "Confirm" && (
                                <button
                                    onClick={() => ActionFunction(patient.aptId, "CheckIn_Patient")}
                                    className="p-2 cursor-pointer rounded bg-green-200 text-green-700 hover:bg-white hover:text-green-700"
                                >
                                    <ThumbsUp size={16} />
                                </button>
                            )}

                            {patient.aptStatus === "Checked In" && (
                                <button
                                    onClick={() => ActionFunction(patient.aptId, "Undo_CheckIn")}
                                    className="p-2 cursor-pointer rounded bg-blue-200 text-blue-700 hover:bg-white hover:text-blue-700"
                                >
                                    <ThumbsDown size={16} />
                                </button>
                            )}

                            {patient.aptStatus === "under_observation" && (
                                <button
                                    onClick={() =>
                                        setPatients((prev) =>
                                            prev.map((p) =>
                                                p.id === patient.id ? { ...p, status: "completed" } : p
                                            )
                                        )
                                    }
                                    className="p-2 cursor-pointer rounded bg-green-300 text-green-600 hover:bg-white"
                                >
                                    <Check size={16} />
                                </button>
                            )}

                            <button className="p-2 cursor-pointer rounded bg-slate-200 text-slate-600 hover:bg-white">
                                <FileText size={16} />
                            </button>
                            {patient.aptStatus == 'Confirm' &&
                                <button
                                    onClick={() => handleRescheuleApt(patient)}
                                    className="p-2 cursor-pointer rounded bg-purple-200 text-purple-600 hover:bg-white">
                                    <Undo2 size={16} />
                                </button>
                            }
                            {(patient.aptStatus === "Confirm" || patient.aptStatus === "Proceed") && (
                                <button
                                    onClick={() => ActionFunction(patient.aptId, "Not_Visited")}
                                    className="p-2 cursor-pointer rounded bg-gray-200 text-red-600 hover:bg-red-600 hover:text-white">
                                    <Ban size={16} />
                                </button>
                            )}
                        </div>
                    );
                } else {
                    return (
                        <div className="flex items-center gap-2">
                            {patient.aptStatus === 'Confirm' &&
                                <button
                                    onClick={() => ActionFunction(patient.aptId, "Cancel_Appointment")}
                                    className="p-2 cursor-pointer rounded bg-red-200 text-red-600 hover:bg-white">
                                    <CircleX size={16} />
                                </button>
                            }
                            {patient.aptStatus === 'Confirm' &&
                                <button
                                    onClick={() => handleRescheuleApt(patient)}
                                    className="p-2 cursor-pointer rounded bg-purple-200 text-purple-600 hover:bg-white">
                                    <Undo2 size={16} />
                                </button>
                            }
                            <button className="p-2 cursor-pointer rounded bg-slate-200 text-slate-600 hover:bg-white">
                                <FileText size={16} />
                            </button>
                        </div>
                    );
                }
            },
        },
        {
            accessorKey: "aptDate",
            header: "Apt Date",
            cell: ({ row }) => {
                const patient = row.original;
                const istoday = formatDate(new Date()) === patient.aptDate
                if (istoday) {
                    return (
                        <span className={`px-3 py-1 rounded-full text-xs font-medium bg-green-200 text-green-700`}>
                            {patient.aptDate}
                        </span>
                    )
                } else {
                    return (
                        <span className={`px-3 py-1 rounded-full text-xs font-medium bg-gray-200 text-gray-700`}>
                            {patient.aptDate}
                        </span>
                    )
                }
            }
        },
        { accessorKey: "patientId", header: "Patient ID" },
        { accessorKey: "patientName", header: "Name" },
        { accessorKey: "doctorName", header: "Doctor" },
        { accessorKey: "doctorId", header: "DoctorId", hidden: true },
        { accessorKey: "deptId", header: "Dept Id", hidden: true },
        { accessorKey: "aptId", header: "Apt Id", hidden: true },
        { accessorKey: "aptCategory", header: "Category" },
        { accessorKey: "deptName", header: "Department" },
        {
            accessorKey: "aptStatus",
            header: "Status",
            cell: ({ row }) => {
                const status = row.original.aptStatus;
                let color = ''
                switch (status) {
                    case "Confirm":
                        color = "bg-blue-100 text-blue-700"
                        break;
                    case "Completed":
                        color = "bg-green-100 text-green-700"
                        break;
                    case "Not Visited":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Checked In":
                        color = "bg-yellow-100 text-yellow-700"
                        break;
                    case "Under Oveservation":
                        color = "bg-red-100 text-red-700"
                        break;
                    case "Proceed":
                        color = "bg-pink-100 text-pink-700"
                        break;
                    case "Cancelled":
                        color = "bg-red-700 text-white"
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700"
                        break;
                }
                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },
    ];

    return (
        <div className="p-1">
            {/* Header and Filters */}
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold text-blue-700">Manage Appointments</h1>
                <div className="flex gap-2">
                    <Button className="bg-blue-700 hover:bg-blue-800 text-white rounded-xs cursor-pointer flex items-center gap-2" size="sm">
                        <Plus size={16} /> Add Appointment
                    </Button>
                    <Button size={'sm'} className='bg-green-600 text-white rounded-xs hover:bg-green-800'>
                        <Download /> Excel
                    </Button>
                </div>
            </div>
            <div className="flex justify-between items-center">
                <div className="flex flex-wrap gap-3 mb-4 items-end">
                    <div>
                        <Label className="mb-1 block">From Date</Label>
                        <CustomDatePicker
                            selected={fromDate}
                            className="form-control"
                            onChange={(val) => setFromDate(val)}
                        />
                    </div>
                    <div>
                        <Label className="mb-1 block">To Date</Label>
                        <CustomDatePicker
                            selected={toDate}
                            className="form-control"
                            onChange={(val) => setToDate(val)}
                        />
                    </div>
                    <div>
                        <SearchableDD
                            options={dept}
                            value={selectedDept}
                            onChange={(val) => setSelectedDept(val)}
                            label="Filter By Dept"
                            placeholder="Select a Dept"
                            className="form-control !w-[180px]"
                        />
                    </div>
                    <div>
                        <Button className="bg-blue-600 text-white font-md rounded-xs"
                            size="icon"
                            onClick={fetchApt}
                        >
                            <Search />
                        </Button>
                    </div>
                </div>
                {/* Legend / Action Guide */}
                <div className="flex flex-wrap gap-4 items-center text-sm">
                    <div className="flex items-center gap-2"><span className="p-2 rounded bg-green-200 text-green-700"><ThumbsUp size={14} /></span>Checked In</div>
                    <div className="flex items-center gap-2"><span className="p-2 rounded bg-slate-300 text-slate-600"><FileText size={14} /></span>View Details</div>
                    <div className="flex items-center gap-2"><span className="p-2 rounded bg-red-200 text-red-600"><CircleX size={14} /></span>Cancel Appt</div>
                    <div className="flex items-center gap-2"><span className="p-2 rounded bg-purple-200 text-purple-600"><Undo2 size={14} /></span>Reschedule</div>
                    <div className="flex items-center gap-2"><span className="p-2 rounded bg-gray-300 text-red-600"><Ban size={14} /></span>Not Attended</div>
                </div>
            </div>

            {/* Table */}
            <DataTable
                columns={columns}
                data={filteredPatients}
                pageSize={50}
                headerBgColor="bg-blue-800"
                headerTextColor="text-white"
            />

            {openResModel &&
                <RescheduleAptHospital
                    isOpen={openResModel}
                    onClose={setOpenResModel}
                    patient={selectedApt}
                    fetchApt={fetchApt}
                />
            }
        </div>
    );
};

export default ApptManagement;
