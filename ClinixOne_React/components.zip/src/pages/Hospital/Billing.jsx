import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import DiagnosticTestBill from '../../components/custom/DiagnosticTestBill';
import PharmaBilling from '../../components/custom/PharmaBilling';
import axiosInstance from "../../Context/axiosInstance";
import SearchableDD from "../../components/custom/SearchableDD";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";

// Main Billing Dashboard Component
const Billing = () => {

    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast();
    const [active, setActive] = useState("diagnostic")
    const [patientid, setPatientId] = useState("");
    const [patientList, setPatientList] = useState([])
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`
    const token = localStorage.getItem("token");

    useEffect(() => {
        getPatientDD()
    },[])

    const getPatientDD = async () => {
        try {
            showLoader();
            const url = `${baseUrl}/api/Master/GetDropDown?Type=GetPatientsDD`
            const res = await axiosInstance.get(url,{
                headers: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true
            })

            if(res.status === 200 && res.data.length > 0){
                setPatientList(res.data.map(item => ({
                    label: item.text,
                    value: item.value,
                })))
            } else {
                showToast("error", "Error!", res.error || 'Internal server error');
            }
        } catch (error) {
            showToast("error", "Error!", error.message || 'Internal server error');
        } finally {
           hideLoader()
        }
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
            <div className="w-full mx-auto">
                {/* Header */}
                <div className="mb-4">
                    <div className="flex items-center gap-3 mb-2">
                        <FileText className="w-6 h-6 text-slate-700" />
                        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Healthcare Billing</h1>
                    </div>
                </div>

                {/* Navbar */}
                <div className='w-full flex justify-between'>
                    <div className="flex gap-4 p-2 rounded-md w-3/4">
                        <Button
                            size="sm"
                            className={active === "diagnostic" ? "bg-green-600 text-white w-40 rounded-xs" : "w-40 rounded-xs bg-gray-400"}
                            onClick={() => setActive("diagnostic")}
                        >
                            Diagnostic Test
                        </Button>
                        <Button
                            size="sm"
                            className={active === "pharmacy" ? "bg-green-600 text-white w-40 rounded-xs" : "w-40 rounded-xs bg-gray-400"}
                            onClick={() => setActive("pharmacy")}
                        >
                            Pharmacy
                        </Button>
                        <Button
                            size="sm"
                            className={active === "consultation" ? "bg-green-600 text-white w-40 rounded-xs" : "w-40 rounded-xs bg-gray-400"}
                            onClick={() => setActive("consultation")}
                        >
                            Consultation
                        </Button>

                        <Button
                            size="sm"
                            className={active === "emergency" ? "bg-green-600 text-white w-40 rounded-xs" : "w-40 rounded-xs bg-gray-400"}
                            onClick={() => setActive("emergency")}
                        >
                            Emergency Services
                        </Button>
                    </div>
                    <div className='w-1/4'>
                        <SearchableDD
                            options={patientList}
                            value={patientid}
                            onChange={(val) => {
                                setPatientId(val)
                               console.log(val)
                                }}
                            className="w-full !bg-blue-200"
                            //label="Patient id"
                            placeholder="Select Patient"
                            required
                        />
                    </div>
                </div>

                <div className="mt-2">
                    {active === "diagnostic" && <DiagnosticTestBill patientid={patientid} />}
                    {active === "pharmacy" && <PharmaBilling patientid={patientid} />}
                </div>

            </div>
        </div>
    );
};

export default Billing;