import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { ChevronUp, ChevronDown, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import PatientCaseStudy from "../../components/custom/PatientCaseStudy";
import PatientTestReport from "../../components/custom/PatientTestReport";
import PatientMedicine from "../../components/custom/PatientMedicine";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import axiosInstance from "../../Context/axiosInstance";
import AppointmentHistory from "../../components/custom/AppointmentHistory";

export default function CasestudyPage() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast()
    const token = localStorage.getItem("token");
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;

    const [activeTab, setActiveTab] = useState("case-study");
    const [patient, setPatient] = useState({});
    const [caseStudy, setcaseStudy] = useState({});
    const [isHeaderVisible, setIsHeaderVisible] = useState(true);

    useEffect(() => {
        GetPatientCaseStudy(id);
    }, [id]);

    const [medicines, setMedicines] = useState([{ name: "", dosage: "", duration: "" }]);

    const handleAddMedicine = () => {
        setMedicines([...medicines, { name: "", dosage: "", duration: "" }]);
    };

    const handleMedicineChange = (index, field, value) => {
        const updated = [...medicines];
        updated[index][field] = value;
        setMedicines(updated);
    };

    const GetPatientCaseStudy = async () => {
        try {
            showLoader();
            const url = `${baseUrl}/api/Hospital/GetPatientCaseStudy?AptId=${id}`;
            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            });

            if (res.status === 200) {
                setPatient(res.data?.patientDetails);
                setcaseStudy(res.data?.patientConsultation);
            }

        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error');
        } finally {
            hideLoader();
        }
    };

    return (
        <Card className="w-full p-6 shadow-md rounded-2xl space-y-6">

            {/* Patient Header with Toggle */}
            <div className="space-y-3"style={{ marginBottom: 0 }}>
                <div className="flex items-center justify-between">
                    <button
                        onClick={() => setIsHeaderVisible(!isHeaderVisible)}
                        className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors"
                    >
                        {isHeaderVisible ? (
                            <ChevronUp className="w-5 h-5" />
                        ) : (
                            <ChevronDown className="w-5 h-5" />
                        )}
                        <span className="text-sm font-medium">
                            {isHeaderVisible ? "Hide" : "Show"} Patient Details
                        </span>
                    </button>
                </div>

                {isHeaderVisible && (
                    <div className="flex flex-col md:flex-row items-start md:items-center gap-6 animate-in fade-in duration-200">
                        <Avatar className="w-24 h-24 ring-2 ring-blue-400 shadow">
                            <AvatarImage src={patient?.profilePic} />
                            <AvatarFallback>{patient?.fullName}</AvatarFallback>
                        </Avatar>

                        <div className="space-y-2 w-full">
                            <div className="text-xl font-semibold text-gray-900">{patient?.fullName}</div>

                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 text-sm text-gray-700">
                                <div><span className="font-medium">Patient Id:</span> {patient?.patientId}</div>
                                <div><span className="font-medium">Age:</span> {patient?.age}</div>
                                <div><span className="font-medium">Gender:</span> {patient?.gender}</div>
                                <div><span className="font-medium">Phone:</span> {patient?.mobNumber}</div>
                                <div><span className="font-medium">Email:</span> {patient?.email}</div>
                                <div><span className="font-medium">Blood Group:</span> {patient?.bloodGroup}</div>
                                <div className="col-span-2 lg:col-span-1">
                                    <span className="font-medium">Address:</span> {patient?.address}
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Tabs Section with Back Button */}
            <Tabs
                defaultValue="case-study"
                value={activeTab}
                onValueChange={(val) => {
                    setActiveTab(val);
                    if (val === "case-study") {
                        GetPatientCaseStudy(id);
                    }
                }}
                className="w-full"
            >
                <div className="flex items-center justify-between gap-4">
                    <TabsList className="bg-blue-100 rounded-lg justify-start flex flex-wrap gap-2 shadow-inner flex-1">
                        <TabsTrigger value="case-study" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white px-4 py-2 rounded-lg">Case Study</TabsTrigger>
                        <TabsTrigger value="appointments" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white px-4 py-2 rounded-lg">Appointment History</TabsTrigger>
                        <TabsTrigger value="test-reports" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white px-4 py-2 rounded-lg">Test Reports</TabsTrigger>
                        <TabsTrigger value="medicines" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white px-4 py-2 rounded-lg">Medicines</TabsTrigger>
                        <TabsTrigger value="operations" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white px-4 py-2 rounded-lg">Operations</TabsTrigger>
                    </TabsList>
                    
                    <Button
                        onClick={() => navigate(-1)}
                        className="flex bg-red-600 items-center gap-2 hover:bg-gray-400 hover:text-black"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back
                    </Button>
                </div>

                <div className="mt-1">
                    <TabsContent value="case-study">
                        <PatientCaseStudy caseStudy={caseStudy} />
                    </TabsContent>

                    <TabsContent value="appointments">
                            <AppointmentHistory patientId={patient?.patientId} />
                    </TabsContent>

                    <TabsContent value="test-reports">
                            <PatientTestReport patientId={patient?.patientId} />
                    </TabsContent>

                    <TabsContent value="medicines">
                        <PatientMedicine patientId={patient?.patientId} />
                    </TabsContent>

                    <TabsContent value="operations">
                        <div className="bg-gray-50 p-4 rounded-xl border">Surgeries or operations history here...</div>
                    </TabsContent>
                </div>
            </Tabs>
        </Card>
    );
}