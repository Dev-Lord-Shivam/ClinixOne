import { useState } from "react";
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Save, 
  User, 
  Stethoscope,
  Pill,
  TestTube,
  FileText,
  Calendar,
  Clock
} from "lucide-react";

const ConsultationPage = () => {
  // Sample patient data - in real app, this would come from route params
  const patientData = {
    id: "PTX001",
    name: "John Doe",
    age: 45,
    gender: "Male",
    doctor: "Dr. Smith",
    appointmentDate: "2025-10-16",
    appointmentTime: "10:30 AM"
  };

  const [consultation, setConsultation] = useState({
    chiefComplaint: "",
    symptoms: "",
    diagnosis: "",
    notes: "",
    followUpDate: "",
    vitals: {
      bloodPressure: "",
      temperature: "",
      pulse: "",
      weight: "",
      height: ""
    }
  });

  const [medicines, setMedicines] = useState([]);
  const [medicalTests, setMedicalTests] = useState([]);
  
  const [newMedicine, setNewMedicine] = useState({
    name: "",
    dosage: "",
    frequency: "",
    duration: "",
    instructions: ""
  });

  const [newTest, setNewTest] = useState({
    testName: "",
    priority: "routine",
    instructions: ""
  });

  const addMedicine = () => {
    if (newMedicine.name && newMedicine.dosage) {
      setMedicines([...medicines, { ...newMedicine, id: Date.now() }]);
      setNewMedicine({
        name: "",
        dosage: "",
        frequency: "",
        duration: "",
        instructions: ""
      });
    }
  };

  const removeMedicine = (id) => {
    setMedicines(medicines.filter(med => med.id !== id));
  };

  const addTest = () => {
    if (newTest.testName) {
      setMedicalTests([...medicalTests, { ...newTest, id: Date.now() }]);
      setNewTest({
        testName: "",
        priority: "routine",
        instructions: ""
      });
    }
  };

  const removeTest = (id) => {
    setMedicalTests(medicalTests.filter(test => test.id !== id));
  };

  const handleSave = () => {
    const consultationData = {
      patient: patientData,
      consultation,
      medicines,
      medicalTests,
      timestamp: new Date().toISOString()
    };
    console.log("Saving consultation:", consultationData);
    alert("Consultation saved successfully!");
  };

  return (
    <div className="min-h-screen p-1">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <button className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors">
              <ArrowLeft size={20} />
              <span className="font-medium">Back to Appointments</span>
            </button>
            <button 
              onClick={handleSave}
              className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-xs hover:bg-green-700 transition-colors shadow-sm"
            >
              <Save size={14} />
              Save & Complete
            </button>
          </div>
          
          {/* Patient Info Card */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="bg-white/20 p-3 rounded-lg">
                  <User size={32} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-2">{patientData.name}</h2>
                  <div className="grid grid-cols-2 gap-x-8 gap-y-1 text-blue-100">
                    <div>Patient ID: <span className="text-white font-medium">{patientData.id}</span></div>
                    <div>Age: <span className="text-white font-medium">{patientData.age} years</span></div>
                    <div>Gender: <span className="text-white font-medium">{patientData.gender}</span></div>
                    <div>Doctor: <span className="text-white font-medium">{patientData.doctor}</span></div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 justify-end mb-1">
                  <Calendar size={16} />
                  <span>{patientData.appointmentDate}</span>
                </div>
                <div className="flex items-center gap-2 justify-end text-blue-100">
                  <Clock size={16} />
                  <span>{patientData.appointmentTime}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Consultation Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Vitals Section */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <Stethoscope size={20} className="text-blue-600" />
                Vital Signs
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    placeholder="120/80 mmHg"
                    value={consultation.vitals.bloodPressure}
                    onChange={(e) => setConsultation({
                      ...consultation,
                      vitals: { ...consultation.vitals, bloodPressure: e.target.value }
                    })}
                    className="w-full form-control"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Temperature</label>
                  <input
                    type="text"
                    placeholder="98.6°F"
                    value={consultation.vitals.temperature}
                    onChange={(e) => setConsultation({
                      ...consultation,
                      vitals: { ...consultation.vitals, temperature: e.target.value }
                    })}
                    className="w-full form-control"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Pulse</label>
                  <input
                    type="text"
                    placeholder="72 bpm"
                    value={consultation.vitals.pulse}
                    onChange={(e) => setConsultation({
                      ...consultation,
                      vitals: { ...consultation.vitals, pulse: e.target.value }
                    })}
                    className="w-full form-control"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Weight</label>
                  <input
                    type="text"
                    placeholder="70 kg"
                    value={consultation.vitals.weight}
                    onChange={(e) => setConsultation({
                      ...consultation,
                      vitals: { ...consultation.vitals, weight: e.target.value }
                    })}
                    className="w-full form-control"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Height</label>
                  <input
                    type="text"
                    placeholder="175 cm"
                    value={consultation.vitals.height}
                    onChange={(e) => setConsultation({
                      ...consultation,
                      vitals: { ...consultation.vitals, height: e.target.value }
                    })}
                    className="w-full form-control"
                  />
                </div>
              </div>
            </div>

            {/* Consultation Details */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <FileText size={20} className="text-blue-600" />
                Consultation Details
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Chief Complaint</label>
                  <input
                    type="text"
                    placeholder="Primary reason for visit"
                    value={consultation.chiefComplaint}
                    onChange={(e) => setConsultation({ ...consultation, chiefComplaint: e.target.value })}
                    className="w-full form-control"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Symptoms</label>
                  <textarea
                    placeholder="Describe symptoms in detail..."
                    value={consultation.symptoms}
                    onChange={(e) => setConsultation({ ...consultation, symptoms: e.target.value })}
                    rows={3}
                    className="w-full form-control resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Diagnosis</label>
                  <textarea
                    placeholder="Medical diagnosis..."
                    value={consultation.diagnosis}
                    onChange={(e) => setConsultation({ ...consultation, diagnosis: e.target.value })}
                    rows={2}
                    className="w-full form-control resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Additional Notes</label>
                  <textarea
                    placeholder="Any additional observations or instructions..."
                    value={consultation.notes}
                    onChange={(e) => setConsultation({ ...consultation, notes: e.target.value })}
                    rows={3}
                    className="w-full form-control resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Follow-up Date</label>
                  <input
                    type="date"
                    value={consultation.followUpDate}
                    onChange={(e) => setConsultation({ ...consultation, followUpDate: e.target.value })}
                    className="w-full form-control"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Medicines and Tests Sidebar */}
          <div className="space-y-6">
            {/* Medicines Section */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <Pill size={20} className="text-green-600" />
                Prescribe Medicines
              </h3>
              
              <div className="space-y-3 mb-4">
                <input
                  type="text"
                  placeholder="Medicine name"
                  value={newMedicine.name}
                  onChange={(e) => setNewMedicine({ ...newMedicine, name: e.target.value })}
                  className="w-full form-control"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Dosage"
                    value={newMedicine.dosage}
                    onChange={(e) => setNewMedicine({ ...newMedicine, dosage: e.target.value })}
                    className="w-full form-control"
                  />
                  <input
                    type="text"
                    placeholder="Frequency"
                    value={newMedicine.frequency}
                    onChange={(e) => setNewMedicine({ ...newMedicine, frequency: e.target.value })}
                    className="w-full form-control"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Duration (e.g., 7 days)"
                  value={newMedicine.duration}
                  onChange={(e) => setNewMedicine({ ...newMedicine, duration: e.target.value })}
                  className="w-full form-control"
                />
                <input
                  type="text"
                  placeholder="Instructions (e.g., After meals)"
                  value={newMedicine.instructions}
                  onChange={(e) => setNewMedicine({ ...newMedicine, instructions: e.target.value })}
                  className="w-full form-control"
                />
                <button
                  onClick={addMedicine}
                  className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Plus size={18} />
                  Add Medicine
                </button>
              </div>

              {medicines.length > 0 && (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {medicines.map((med) => (
                    <div key={med.id} className="bg-green-50 p-3 rounded-lg border border-green-200">
                      <div className="flex items-start justify-between mb-1">
                        <h4 className="font-semibold text-gray-800 text-sm">{med.name}</h4>
                        <button
                          onClick={() => removeMedicine(med.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <p className="text-xs text-gray-600">
                        <span className="font-medium">Dosage:</span> {med.dosage} | <span className="font-medium">Frequency:</span> {med.frequency}
                      </p>
                      <p className="text-xs text-gray-600">
                        <span className="font-medium">Duration:</span> {med.duration}
                      </p>
                      {med.instructions && (
                        <p className="text-xs text-gray-600 mt-1">
                          <span className="font-medium">Instructions:</span> {med.instructions}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Medical Tests Section */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <TestTube size={20} className="text-purple-600" />
                Medical Tests
              </h3>
              
              <div className="space-y-3 mb-4">
                <input
                  type="text"
                  placeholder="Test name"
                  value={newTest.testName}
                  onChange={(e) => setNewTest({ ...newTest, testName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                />
                <select
                  value={newTest.priority}
                  onChange={(e) => setNewTest({ ...newTest, priority: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                >
                  <option value="routine">Routine</option>
                  <option value="urgent">Urgent</option>
                  <option value="emergency">Emergency</option>
                </select>
                <input
                  type="text"
                  placeholder="Special instructions"
                  value={newTest.instructions}
                  onChange={(e) => setNewTest({ ...newTest, instructions: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                />
                <button
                  onClick={addTest}
                  className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Plus size={18} />
                  Add Test
                </button>
              </div>

              {medicalTests.length > 0 && (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {medicalTests.map((test) => (
                    <div key={test.id} className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                      <div className="flex items-start justify-between mb-1">
                        <div>
                          <h4 className="font-semibold text-gray-800 text-sm">{test.testName}</h4>
                          <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium mt-1 ${
                            test.priority === 'emergency' ? 'bg-red-100 text-red-700' :
                            test.priority === 'urgent' ? 'bg-orange-100 text-orange-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {test.priority.charAt(0).toUpperCase() + test.priority.slice(1)}
                          </span>
                        </div>
                        <button
                          onClick={() => removeTest(test.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      {test.instructions && (
                        <p className="text-xs text-gray-600 mt-1">
                          <span className="font-medium">Instructions:</span> {test.instructions}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConsultationPage;