import React from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Calendar, Clock, Users, Activity, TrendingUp, Heart, Bed, AlertCircle } from 'lucide-react';

const DashboardPage = () => {
  // Chart Data
  const appointmentData = [
    { time: '8 AM', appointments: 2 },
    { time: '10 AM', appointments: 5 },
    { time: '12 PM', appointments: 8 },
    { time: '2 PM', appointments: 6 },
    { time: '4 PM', appointments: 9 },
    { time: '6 PM', appointments: 4 },
  ];

  const departmentData = [
    { name: 'Cardiology', value: 45, color: '#ef4444' },
    { name: 'Orthopedics', value: 32, color: '#3b82f6' },
    { name: 'Neurology', value: 28, color: '#8b5cf6' },
    { name: 'Pediatrics', value: 25, color: '#10b981' },
    { name: 'Others', value: 20, color: '#f59e0b' },
  ];

  const occupancyData = [
    { day: 'Mon', occupancy: 72 },
    { day: 'Tue', occupancy: 85 },
    { day: 'Wed', occupancy: 78 },
    { day: 'Thu', occupancy: 88 },
    { day: 'Fri', occupancy: 92 },
    { day: 'Sat', occupancy: 68 },
    { day: 'Sun', occupancy: 65 },
  ];

  const patientAdmissionData = [
    { week: 'Week 1', admissions: 24, discharges: 18 },
    { week: 'Week 2', admissions: 32, discharges: 22 },
    { week: 'Week 3', admissions: 28, discharges: 25 },
    { week: 'Week 4', admissions: 35, discharges: 28 },
  ];

  const metrics = [
    { title: 'Total Patients', value: '1,248', icon: Users, change: '+12%', color: 'from-blue-500 to-blue-600', bgColor: 'bg-blue-100', textColor: 'text-blue-600' },
    { title: "Today's Appointments", value: '34', icon: Calendar, change: '+5%', color: 'from-green-500 to-green-600', bgColor: 'bg-green-100', textColor: 'text-green-600' },
    { title: 'In-Patients', value: '156', icon: Heart, change: '-3%', color: 'from-red-500 to-red-600', bgColor: 'bg-red-100', textColor: 'text-red-600' },
    { title: 'Available Beds', value: '42', icon: Bed, change: '+8%', color: 'from-purple-500 to-purple-600', bgColor: 'bg-purple-100', textColor: 'text-purple-600' },
  ];

  const appointments = [
    { time: '9:00 AM', name: 'John Doe', reason: 'General Checkup', dept: 'General', status: 'confirmed', id: 'PTX001' },
    { time: '10:30 AM', name: 'Jane Smith', reason: 'Back Pain', dept: 'Orthopedics', status: 'pending', id: 'PTX002' },
    { time: '11:45 AM', name: 'Mike Ross', reason: 'Follow-up', dept: 'Cardiology', status: 'confirmed', id: 'PTX003' },
    { time: '1:00 PM', name: 'Sarah Wilson', reason: 'Checkup', dept: 'Pediatrics', status: 'completed', id: 'PTX004' },
    { time: '2:30 PM', name: 'Robert Brown', reason: 'X-Ray', dept: 'Orthopedics', status: 'pending', id: 'PTX005' },
  ];

  const inPatients = [
    { name: 'Chris Evans', room: '302A', dept: 'Cardiology', condition: 'Stable', lastVisit: 'Today 8:00 AM', doctor: 'Dr. Smith' },
    { name: 'Scarlett J.', room: '405B', dept: 'Orthopedics', condition: 'Under Observation', lastVisit: 'Today 3:30 PM', doctor: 'Dr. Johnson' },
    { name: 'Tom Hardy', room: '201C', dept: 'Neurology', condition: 'Stable', lastVisit: 'Today 10:00 AM', doctor: 'Dr. Lee' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">Hospital Dashboard</h1>
          <p className="text-slate-600">Welcome back! Here's your hospital overview</p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {metrics.map((metric, idx) => {
            const Icon = metric.icon;
            return (
              <div key={idx} className="bg-white rounded-xl p-6 border border-slate-200 hover:border-slate-300 transition-all duration-300 hover:shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-lg ${metric.bgColor}`}>
                    <Icon size={24} className={metric.textColor} />
                  </div>
                  <span className="text-sm font-semibold text-green-600 bg-green-50 px-3 py-1 rounded-full">{metric.change}</span>
                </div>
                <h3 className="text-slate-600 text-sm font-medium mb-2">{metric.title}</h3>
                <p className="text-3xl font-bold text-slate-900">{metric.value}</p>
              </div>
            );
          })}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Appointments Chart */}
          <div className="lg:col-span-2 bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-6">Appointments Over Time</h2>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={appointmentData}>
                <defs>
                  <linearGradient id="colorAppointments" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="time" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', color: '#1e293b' }} />
                <Area type="monotone" dataKey="appointments" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorAppointments)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Department Distribution */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-6">Patient Distribution</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={departmentData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={2} dataKey="value">
                  {departmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', color: '#1e293b' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {departmentData.map((dept, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div style={{ backgroundColor: dept.color }} className="w-2 h-2 rounded-full"></div>
                    <span className="text-slate-700">{dept.name}</span>
                  </div>
                  <span className="font-semibold text-slate-900">{dept.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Occupancy and Admissions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Weekly Bed Occupancy */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-6">Weekly Bed Occupancy Rate</h2>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={occupancyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="day" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', color: '#1e293b' }} />
                <Bar dataKey="occupancy" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Admissions vs Discharges */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-6">Admissions vs Discharges</h2>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={patientAdmissionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="week" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', color: '#1e293b' }} />
                <Legend />
                <Bar dataKey="admissions" fill="#10b981" radius={[8, 8, 0, 0]} />
                <Bar dataKey="discharges" fill="#f59e0b" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tables Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Appointments Table */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-200 bg-gradient-to-r from-blue-50 to-indigo-50">
              <h2 className="text-lg font-bold text-slate-900">Today's Appointments</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Time</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Patient</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Department</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {appointments.map((apt, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-900 flex items-center gap-2">
                        <Clock size={16} className="text-blue-500" /> {apt.time}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-700">{apt.name}</td>
                      <td className="px-6 py-4 text-sm text-slate-700">{apt.dept}</td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          apt.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                          apt.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* In-Patients Table */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-200 bg-gradient-to-r from-blue-50 to-indigo-50">
              <h2 className="text-lg font-bold text-slate-900">In-Patients Under Care</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Patient</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Room</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Doctor</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-slate-700">Condition</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {inPatients.map((patient, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-900">{patient.name}</td>
                      <td className="px-6 py-4 text-sm text-slate-700">{patient.room}</td>
                      <td className="px-6 py-4 text-sm text-slate-700">{patient.doctor}</td>
                      <td className="px-6 py-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Activity size={16} className={patient.condition === 'Stable' ? 'text-green-500' : 'text-yellow-500'} />
                          <span className="text-slate-700">{patient.condition}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;