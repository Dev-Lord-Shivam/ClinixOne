import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useEffect, useState } from 'react';
import { Delete, Download, Edit2, Eye, FileText, Trash2, Upload, View } from 'lucide-react';
import axiosInstance from "../../Context/axiosInstance";
import SearchableDD from "../../components/custom/SearchableDD";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import { DataTable } from "../../components/custom/DataTable";
import PatientCard from '../../components/custom/PatientCard';
import { useConfirm } from "../../Context/ConfirmProvider";
import PdfDialogueReader from "../../components/custom/PdfDialogueReader";

const Labtest = () => {

  const { showLoader, hideLoader } = useLoader();
  const showToast = useShowToast();
  const confirm = useConfirm()
  const [patientid, setPatientId] = useState("");
  const [patientList, setPatientList] = useState([]);
  const [patientDetails, setPatientDetails] = useState({});
  const [testList, setTestList] = useState([]);
  const [openModel, setOpenModel] = useState(false)
  const [selectedStatus, setSelectedStatus] = useState('Schedule')
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedScheduleId, setSelectScheduleId] = useState(null);
  const [openPdf, setOpenPdf] = useState(false);
  const [selectedPdf, setSelectedPdf] = useState(null);

  const [allTests, setAllTests] = useState([]);

  const statusDD = [
    { label: 'All', value: 'All' },
    { label: 'Schedule', value: 'Schedule' },
    { label: 'Pending', value: 'Pending' },
    { label: 'Completed', value: 'Completed' },
    { label: 'Cancelled', value: 'Cancelled' },
    { label: 'File Deleted', value: 'File Deleted' },
  ]
  const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
  const token = localStorage.getItem("token");

  const columns = [
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const patient = row.original;
        return (
          <div className="flex items-center gap-2">
            {(patient.status === 'Schedule' || patient.status === 'File Deleted') && (
              <button
                onClick={() => {
                  setOpenModel(true)
                  setSelectScheduleId(patient.scheduleId)
                }}
                className="p-2 rounded-full bg-blue-400 text-black hover:bg-white cursor-pointer">
                <Upload size={16} />
              </button>
            )}
            {(patient.status === 'Completed' && (
              <>
                <button
                  onClick={() => {
                    setSelectedPdf(patient.fileBase64);
                    setOpenPdf(true);
                  }}
                  className="p-2 rounded-full bg-yellow-400 text-black hover:bg-white cursor-pointer">
                  <Eye size={16} />
                </button>
                <button
                  onClick={() => downloadBase64Pdf(patient.fileBase64, patient.fileName)}
                  className="p-2 rounded-full bg-green-400 text-black hover:bg-white cursor-pointer">
                  <Download size={16} />
                </button>
                <button
                  onClick={() => handleFileDelete(patient.scheduleId, patient.fileName)}
                  className="p-2 rounded-full bg-red-400 text-black hover:bg-white cursor-pointer">
                  <Trash2 size={16} />
                </button>
              </>
            ))}
          </div>
        );
      },
    },
    { accessorKey: "testName", header: "Test Name" },
    { accessorKey: "createdAt", header: "Date" },
    { accessorKey: "testId", header: "testId", hidden: true },
    { accessorKey: "scheduleId", header: "scheduleId", hidden: true },
    { accessorKey: "createdBy", header: "Doctor", hidden: true },
    { accessorKey: "categoryName", header: "Category" },
    { accessorKey: "mrp", header: "MRP (₹)" },
    { accessorKey: "fileBase64", header: "FileBase64", hidden: true },
    { accessorKey: "fileName", header: "FileName", hidden: true },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.original.status;
        let color = "";

        switch (status) {
          case "Schedule":
            color = "bg-purple-200 text-purple-700";
            break;
          case "Pending":
            color = "bg-red-100 text-red-700";
            break;
          case "Completed":
            color = "bg-green-200 text-green-700";
            break;
          case "Cancelled":
            color = "bg-red-700 text-white";
            break;
          case "File Deleted":
            color = "bg-pink-700 text-white";
            break;
          default:
            color = "bg-gray-100 text-gray-700";
        }

        return (
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
            {status.replace("_", " ")}
          </span>
        );
      },
    },
  ];

  useEffect(() => {
    getPatientDD();
  }, []);

  useEffect(() => {
    if (selectedStatus === "" || selectedStatus === "All") {
      setTestList(allTests);
    } else {
      setTestList(allTests.filter(m => m.status === selectedStatus));
    }
  }, [selectedStatus, allTests]);


  // Fetch when patient changes
  useEffect(() => {
    if (patientid) {
      fetchTestByPatient();
    } else {
      setTestList([]);
    }
  }, [patientid]);

  const fetchTestByPatient = async () => {
    try {
      showLoader();
      let url = `${baseUrl}/api/Hospital/GetTestHistory?patientId=${patientid}&Type=PatientTestHistory`;

      let res = await axiosInstance.get(url, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      if (res.status === 200 && res.data.length > 0) {
        setAllTests(res.data);   // keep original
        setTestList(res.data);   // display filtered
      } else {
        setAllTests([]);
        setTestList([]);
      }


      let patienturl = `${baseUrl}/api/Hospital/GetPatientById?patientId=${patientid}`
      let response = await axiosInstance.get(patienturl, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
      console.log(response.data)
      if (response.status === 200 && response.data) {

        setPatientDetails(response.data)
      } else {
        setPatientDetails({});
      }


    } catch (error) {
      showToast('error', 'Error!', error.message || 'Internal Server Error');
    } finally {
      hideLoader();
    }
  };

  const getPatientDD = async () => {
    try {
      showLoader();
      const url = `${baseUrl}/api/Master/GetDropDown?Type=GetPatientsDD`;

      const res = await axiosInstance.get(url, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      if (res.status === 200 && res.data.length > 0) {
        setPatientList(
          res.data.map(item => ({
            label: item.text,
            value: item.value,
          }))
        );
      } else {
        showToast("error", "Error!", res.error || "Internal server error");
      }
    } catch (error) {
      showToast("error", "Error!", error.message || "Internal server error");
    } finally {
      hideLoader();
    }
  };

  const handelFileUpload = async () => {
    try {

      if (!selectedFile) {
        showToast("error", "Validation Error!", "Please select a PDF file");
        return;
      }
      let confirmOptions = {
        title: "Are you sure?",
        description: "Are you sure, you want to upload the file",
        confirmText: "Yes",
        cancelText: "No",
        intent: "danger",
      };

      const confirmed = await confirm(confirmOptions);
      if (!confirmed) return;

      showLoader()
      const TestName = testList.find(m => m.scheduleId === selectedScheduleId).testName;
      const formData = new FormData();
      formData.append("TestName", TestName);
      formData.append("ScheduleId", selectedScheduleId);
      formData.append("PatientId", patientid);
      formData.append("File", selectedFile);
      const url = `${baseUrl}/api/Hospital/UploadTestReport`;

      const res = await axiosInstance.post(url, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
        withCredentials: true,
      });

      if (res.status == 200) {
        showToast("success", "File Uploaded", "File Uploaded successfully");
        setOpenModel(false)
        setSelectScheduleId(null)
        setSelectedFile(null)
        await fetchTestByPatient();
      }
      else {
        showToast("error", "Error!", res.error || "File Upload failed");
      }
    } catch (error) {
      showToast("error", "Error!", error.message || "Internal Server Error");
    } finally {
      hideLoader()
    }
  }

  const handleFileDelete = async (scheduleId, fileName) => {
    try {
     
      let confirmOptions = {
        title: "Are you sure?",
        description: "Are you sure, you want to delete the file",
        confirmText: "Yes",
        cancelText: "No",
        intent: "danger",
      };

      const confirmed = await confirm(confirmOptions);
      if (!confirmed) return;

      showLoader()
      const payload = {
        ScheduleId: scheduleId,
        FileName: fileName,
        Type: 'deletereport'
      }
      const url = `${baseUrl}/api/Hospital/DeleteTestReport`;
      const res = await axiosInstance.post(url, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        withCredentials: true,
      });
      
      if(res.status == 200){
        showToast("success", "File Deleted", "File deleted successfully");
        await fetchTestByPatient();
      }
      else {
        showToast("error", "Error!", res.error || "File Deletion failed");
      }
    } catch (error) {
      showToast("error", "Error!", error.message || "File Deletion failed");
    } finally {
      hideLoader()
    }
  }

  const downloadBase64Pdf = (base64, fileName = "report.pdf") => {
    const link = document.createElement("a");
    link.href = `data:application/pdf;base64,${base64}`;
    link.download = fileName;
    link.click();
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="w-full mx-auto">
        {/* Header */}
        <div className="mb-4 flex justify-between">
          <div className="flex flex-col w-2/3">
            <div className='flex items-center gap-3'>
              <FileText className="w-6 h-6 text-slate-700" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Tests & Reports
              </h1>
            </div>
            {/* <p className="text-gray-600 mt-2">Examine the medical test and update to portal</p> */}
          </div>

          <div className="flex gap-2 w-1/3">
            <SearchableDD
              options={statusDD}
              value={selectedStatus}
              onChange={(val) =>
                setSelectedStatus(val)
              }
              className="w-full !bg-blue-200"
              placeholder="Select Status"
              required
            />
            <SearchableDD
              options={patientList}
              value={patientid}
              onChange={(val) => setPatientId(val)}
              className="w-full !bg-blue-200"
              placeholder="Select Patient"
              required
            />
          </div>
        </div>
      </div>
      <div className='flex gap-2 w-full'>
        <div className='w-2/3'>
          <div className="flex justify-between items-center">
            <div className="flex flex-wrap gap-4 items-center text-sm mb-4">
              <div className="flex items-center gap-2"><span className="p-2 rounded-full bg-yellow-400 text-black"><Eye size={14} /></span>View Report</div>
              <div className="flex items-center gap-2"><span className="p-2 rounded-full bg-green-400 text-black"><Download size={14} /></span>Download pdf</div>
              <div className="flex items-center gap-2"><span className="p-2 rounded-full bg-red-400 text-black"><Trash2 size={14} /></span>Delete Report</div>
              <div className="flex items-center gap-2"><span className="p-2 rounded-full bg-blue-400 text-black"><Upload size={14} /></span>Upload Report</div>
            </div>
          </div>
          <DataTable
            columns={columns}
            data={testList}
            pageSize={50}
            headerBgColor="bg-blue-700"
            headerTextColor="text-white"
          />
        </div>
        <div className='w-1/3 mt-11'>
          <PatientCard patientDetails={patientDetails} />
        </div>
      </div>

      <Dialog open={openModel} onOpenChange={setOpenModel}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Report</DialogTitle>
            <DialogDescription>
              Upload only PDF medical reports.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-2">
            <Label htmlFor="file">Select PDF</Label>
            <Input
              id="file"
              type="file"
              accept="application/pdf"
              onChange={(e) => setSelectedFile(e.target.files[0])}
            />
          </div>

          <DialogFooter className="sm:justify-end">
            <Button
              type="button"
              className='bg-red-600 rounded-sm'
              onClick={() => setOpenModel(false)}
            >
              Close
            </Button>
            <Button
              type="button"
              className='bg-green-600 rounded-sm'
              onClick={() => handelFileUpload()}
            >
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <PdfDialogueReader
        open={openPdf}
        onClose={() => setOpenPdf(false)}
        base64Pdf={selectedPdf}
        title="Patient Report"
      />
    </div>
  );
};

export default Labtest;
