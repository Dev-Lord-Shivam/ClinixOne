import React, { useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { useNavigate, useParams } from "react-router-dom";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import axiosInstance from "../../Context/axiosInstance";
import { useConfirm } from "../../Context/ConfirmProvider";

/* =========================================================
   MenuAccessPage
========================================================= */

const MenuAccessPage = () => {
  const baseUrl = import.meta.env.VITE_API_BASE_URL;
  const token = localStorage.getItem("token");
  const navigate = useNavigate();
  const { roleId, portalType, roleName } = useParams();
  const { showLoader, hideLoader } = useLoader();
  const showToast = useShowToast();
  const confirm = useConfirm()
  const [menus, setMenus] = useState([]);

  /* =========================================================
     Load Menus
  ========================================================= */

  useEffect(() => {
    if (roleId) getMenusByRole();
  }, [roleId]);

  /* =========================================================
     Convert Flat List → Tree (Like MVC MenuLevel Logic)
  ========================================================= */

  const buildMenuTree = (flatMenus) => {
    const parents = flatMenus
      .filter((m) => m.menuLevel === 1)
      .map((menu) => ({
        menuId: menu.menuId,
        menuName: menu.displayName || menu.menuName,
        read: menu.readAccess ?? false,
        write: menu.writeAccess ?? false,
        subMenus: [],
      }));

    const children = flatMenus.filter((m) => m.menuLevel === 2);

    parents.forEach((menu) => {
      menu.subMenus = children
        .filter((sub) => sub.parentMenuId === menu.menuId)
        .map((sub) => ({
          subMenuId: sub.menuId,
          name: sub.displayName || sub.menuName,
          read: sub.readAccess ?? false,
          write: sub.writeAccess ?? false,
        }));
    });

    return parents;
  };

  /* =========================================================
     API Call
  ========================================================= */

  const getMenusByRole = async () => {
    try {
      showLoader();

      const res = await axiosInstance.get(
        `${baseUrl}/api/Master/GetMenus`,
        {
          params: {
            Type: "Get_MenusByRole",
            Portal: portalType,
            Id: roleId,
          },
          headers: {
            Authorization: `Bearer ${token}`,
          },
          withCredentials: true,
        }
      );

      if (res.status === 200) {
        const structuredMenus = buildMenuTree(res.data);
        setMenus(structuredMenus);
      } else {
        showToast("error", "Error!", "Failed to load menus");
      }
    } catch (error) {
      showToast("error", "Error!", error.message);
    } finally {
      hideLoader();
    }
  };

  /* =========================================================
     Toggle Menu (Parent)
  ========================================================= */

  const toggleMenu = (menuId, type, value) => {
    setMenus((prev) =>
      prev.map((menu) =>
        menu.menuId === menuId
          ? {
            ...menu,
            [type]: value,
            ...(type === "read" && !value && { write: false }),
            ...(type === "write" && value && { read: true }),
            subMenus: menu.subMenus.map((sub) => ({
              ...sub,
              [type]: value,
              ...(type === "read" && !value && { write: false }),
              ...(type === "write" && value && { read: true }),
            })),
          }
          : menu
      )
    );
  };

  /* =========================================================
     Toggle Sub Menu (Child)
  ========================================================= */

  const toggleSubMenu = (menuId, subMenuId, type, value) => {
    setMenus((prev) =>
      prev.map((menu) => {
        if (menu.menuId !== menuId) return menu;

        const updatedSubMenus = menu.subMenus.map((sub) =>
          sub.subMenuId === subMenuId
            ? {
              ...sub,
              [type]: value,
              ...(type === "write" && value && { read: true }),
              ...(type === "read" && !value && { write: false }),
            }
            : sub
        );

        const allRead = updatedSubMenus.every((s) => s.read);
        const allWrite = updatedSubMenus.every((s) => s.write);

        return {
          ...menu,
          read: allRead,
          write: allWrite,
          subMenus: updatedSubMenus,
        };
      })
    );
  };

  /* =========================================================
     Save (Payload Ready)
  ========================================================= */

  const handleSave = async () => {

    let confirmOptions = {
      title: "Are you sure",
      description: "Are you sure, you want to update the menu access",
      confirmText: "Yes",
      cancelText: "No",
      intent: "danger",
    };

    const confirmed = await confirm(confirmOptions);
    if (!confirmed) return;

    const menusPayload = menus.flatMap((menu) => [
      {
        menuId: menu.menuId,
        readAccess: menu.read,
        writeAccess: menu.write,
        roleId,
      },
      ...menu.subMenus.map((sub) => ({
        menuId: sub.subMenuId,
        readAccess: sub.read,
        writeAccess: sub.write,
        roleId,
      })),
    ]);

    const payload = {
      JsonData: JSON.stringify(menusPayload),
      RoleId: roleId,
      Type: 'updateMenus'
    }
     
    console.log("SAVE PAYLOAD:", payload);

    const url = `${baseUrl}/api/Master/UpdateMenus`
    const res = await axiosInstance.post(url, payload, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true
    })
    console.log(res)
    if (res.status == 200 && res.data.msg_code == '1'){
      showToast('success', 'Success!', res.data.message);
      await getMenusByRole()
    } else {
      showToast('error', 'Error!', 'Internal Server Error')
    }
  };

  /* =========================================================
     Render
  ========================================================= */

  return (
    <div className="p-2">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">
          Menu Access Rights (Role ID: {roleId})
        </h2>

        <div className="flex gap-2">
          <Button
            onClick={handleSave}
            className="bg-green-600 text-xs h-8 px-4"
          >
            Save
          </Button>

          <Button
            onClick={() => navigate("/hospital/rolemaster")}
            className="bg-red-600 text-xs h-8 px-4"
          >
            Back
          </Button>
        </div>
      </div>

      <div className="rounded-md border shadow bg-white p-4 overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-blue-800 text-white text-left">
              <th className="p-2">Menu Name</th>
              <th className="p-2">Sub Menu Name</th>
              <th className="p-2 text-center">Read</th>
              <th className="p-2 text-center">Write</th>
            </tr>
          </thead>

          <tbody>
            {menus.map((menu) => (
              <React.Fragment key={menu.menuId}>
                {/* Parent Menu */}
                <tr className="bg-purple-100 font-semibold">
                  <td className="p-2 border">{menu.menuName}</td>
                  <td className="p-2 border"></td>
                  <td className="p-2 border text-center">
                    <Checkbox
                      checked={menu.read}
                      className='border-2 border-gray-400'
                      onCheckedChange={(v) =>
                        toggleMenu(menu.menuId, "read", v)
                      }
                    />
                  </td>
                  <td className="p-2 border text-center">
                    <Checkbox
                      checked={menu.write}
                      className='border-2 border-gray-400'
                      onCheckedChange={(v) =>
                        toggleMenu(menu.menuId, "write", v)
                      }
                    />
                  </td>
                </tr>

                {/* Child Menus */}
                {menu.subMenus.map((sub) => (
                  <tr key={sub.subMenuId}>
                    <td className="p-2 border"></td>
                    <td className="p-2 border">{sub.name}</td>
                    <td className="p-2 border text-center">
                      <Checkbox
                        checked={sub.read}
                        className='border-2 border-gray-400'
                        onCheckedChange={(v) =>
                          toggleSubMenu(
                            menu.menuId,
                            sub.subMenuId,
                            "read",
                            v
                          )
                        }
                      />
                    </td>
                    <td className="p-2 border text-center">
                      <Checkbox
                        checked={sub.write}
                        className='border-2 border-gray-400'
                        onCheckedChange={(v) =>
                          toggleSubMenu(
                            menu.menuId,
                            sub.subMenuId,
                            "write",
                            v
                          )
                        }
                      />
                    </td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MenuAccessPage;
