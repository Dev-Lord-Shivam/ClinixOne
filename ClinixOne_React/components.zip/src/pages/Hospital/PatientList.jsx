import React, { useEffect, useState } from 'react'
import useShowToast from '../../Context/useShowToast';
import { useLoader } from '../../Context/LoaderProvider';
import { Button } from '@/components/ui/button';
import { DataTable } from '../../components/custom/DataTable';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from "@/components/ui/badge";
import { Pencil, BookPlus } from 'lucide-react';
import axiosInstance from '../../Context/axiosInstance';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import PatientRegistration from '../Landing/RegisterPatient';
import RegisterPatients from '../../components/custom/RegisterPatient';

const PatientList = () => {
    const token = localStorage.getItem("token");
    const userInfo = JSON.parse(localStorage.getItem('user'))
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const showToast = useShowToast();
    const { showLoader, hideLoader } = useLoader();

    const [patientList, setPatientList] = useState([]);
    const [activeTab, setActiveTab] = useState("all_Patient"); // default tab
    const [allowedTabs, setAllowedTabs] = useState({
        all_Patient: true,
        my_Patient: true,
        reg_Patient: true
    });

    // Example role logic (can be from token, context, or API)
    useEffect(() => {
        const role = userInfo.roleName; // Example
        const tabAccess = { all_Patient: false, my_Patient: false, reg_Patient: false };

        if (role === "Admin" || role === "Doctor") {
            tabAccess.all_Patient = true;
            tabAccess.my_Patient = true;
            tabAccess.reg_Patient = true
        } else if (role === "Lab") {
            tabAccess.my_Patient = true;
        } else if (role === "Receptionist") {
            tabAccess.all_Patient = true;
        }

        setAllowedTabs(tabAccess);

        // Set default visible tab
        if (tabAccess.all_Patient) setActiveTab("all_Patient");
        else if (tabAccess.my_Patient) setActiveTab("my_Patient");
        else if (tabAccess.reg_Patient) setActiveTab("reg_Patient")

    }, []);

    const patientColumns = [
        {
            accessorKey: "action",
            header: "Action",
            enableColumnFilter: false,
            size: 100,
            cell: ({ row }) => {
                const empId = row.original.empId;
                return (
                    <div className='flex gap-2'>
                        <button
                            onClick={() => handleEdit(empId)}
                            className="text-white p-2 rounded-full cursor-pointer bg-blue-500 hover:text-blue-500 hover:bg-white"
                        >
                            <Pencil size={13} />
                        </button>
                        <button
                            onClick={() => handleView(empId)}
                            className="text-white p-2 rounded-full cursor-pointer bg-green-600 hover:text-green-700 hover:bg-white"
                        >
                            <BookPlus size={13} />
                        </button>
                    </div>
                );
            }
        },
        {
            accessorKey: "profilePic",
            header: "Profile",
            enableColumnFilter: false,
            size: 30,
            cell: ({ row }) => (
                <Avatar className="h-10 w-10 border-2 border-blue-500">
                    <AvatarImage src={row.original.profilePic} alt={row.original.fullName} />
                    <AvatarFallback>{row.original.fullName?.charAt(0)}</AvatarFallback>
                </Avatar>
            )
        },
        { accessorKey: "patientId", header: "Patient ID", size: 80 },
        { accessorKey: "fullName", header: "Name" },
        { accessorKey: "gender", header: "Gender", size: 100 },
        { accessorKey: "bloodGroup", header: "Blood Group", size: 100 },
        { accessorKey: "maritalStatus", header: "Marital Status", size: 100 },
        { accessorKey: "mobNumber", header: "Phone", size: 100 },
        { accessorKey: "email", header: "Email" },
        { accessorKey: "dob", header: "DOB", size: 100 },
        { accessorKey: "religion", header: "Religion", size: 80 },
        { accessorKey: "nationality", header: "Nationality", size: 100 },
        { accessorKey: "occupation", header: "Occupation", size: 100 },
        { accessorKey: "address", header: "Address", size: 180 },
        { accessorKey: "createdAt", header: "Created On", size: 100 },
        {
            accessorKey: "isActive", header: "Status", size: 100,
            cell: ({ row }) => {
                const isActive = row.getValue("isActive");
                return (
                    <Badge className={isActive ? "bg-green-500 text-white" : "bg-red-500 text-white"}>
                        {isActive ? "Active" : "Inactive"}
                    </Badge>
                );
            },
        },
    ];

    // Fetch data whenever tab changes
    useEffect(() => {
        if(activeTab != 'reg_Patient')
             fetchPatients(activeTab);
    }, [activeTab]);

    const fetchPatients = async (tab) => {
        try {
            showLoader();

            const typeParam = tab === "all_Patient" ? "Get_PatientsList" : "Get_MyPatientList";

            // Dynamically build query string
            const queryParams = new URLSearchParams({
                Type: typeParam,
                ...(typeParam === "Get_MyPatientList" && { Id: userInfo.empId })
            });

            const url = `${baseUrl}/api/Hospital/GetPatientList?${queryParams.toString()}`;

            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            });

            if (res.status === 200) {
                setPatientList(res.data);
            }
        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error');
        } finally {
            hideLoader();
        }
    };


    const handleEdit = (id) => {
        showToast("info", "Edit clicked", `Editing patient ${id}`);
    };

    const handleView = (id) => {
        showToast("info", "View clicked", `Viewing patient ${id}`);
    };

    return (
        <div className="p-1">

            {/* Tabs for Patient Lists */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-1">
                <TabsList className="bg-gray-100 rounded-sm p-1 bg-blue-300">
                    {allowedTabs.all_Patient && (
                        <TabsTrigger value="all_Patient" className="px-4 py-2 text-xs font-medium rounded-sm">
                            All Patients
                        </TabsTrigger>
                    )}
                    {allowedTabs.my_Patient && (
                        <TabsTrigger value="my_Patient" className="px-4 py-2 text-xs font-medium rounded-sm">
                            My Patients
                        </TabsTrigger>
                    )}
                    {allowedTabs.reg_Patient && (
                        <TabsTrigger value="reg_Patient" className="px-4 py-2 text-xs font-medium rounded-sm">
                            Register Patients
                        </TabsTrigger>
                    )}
                </TabsList>
                <TabsContent value="all_Patient" className="space-y-6">
                    <div className='mt-1'>
                        <DataTable
                            columns={patientColumns}
                            data={patientList}
                            pageSize={50}
                            headerBgColor="bg-blue-800"
                            headerTextColor="text-white"
                        />
                    </div>
                </TabsContent>
                <TabsContent value="my_Patient" className="space-y-6">
                    <div className='mt-4'>
                        <DataTable
                            columns={patientColumns}
                            data={patientList}
                            pageSize={50}
                            headerBgColor="bg-blue-800"
                            headerTextColor="text-white"
                        />
                    </div>
                </TabsContent>
                <TabsContent value="reg_Patient" className="space-y-6">
                    <div className='mt-4'>
                       <RegisterPatients /> 
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default PatientList;
