import { useState, useRef, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import axiosInstance from "../../Context/axiosInstance";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import SearchableDD from "../../components/custom/SearchableDD";
import { useLoader } from "../../Context/LoaderProvider";
import { useCustomAlert } from "../../Context/CustomAlertProvider";
import CustomDatePicker from "../../components/custom/CustomDatePicker";
import useShowToast from "../../Context/useShowToast";
import { useNavigate, useParams } from "react-router-dom";

const RegisterUser = () => {

    const { id } = useParams();
    const [errors, setErrors] = useState({});
    const { showLoader, hideLoader } = useLoader()
    const [roles, setRoles] = useState([]);
    const [dept, setDept] = useState([]);
    const fileInputRef = useRef(null);
    const alert = useCustomAlert();
    const showToast = useShowToast();
    const navigate = useNavigate();
    const [form, setForm] = useState({
        empId: '',
        empPhoto: '',
        empName: '',
        gender: '',
        qualification: '',
        dob: '',
        maritalStatus: 'Single',
        emailId: '',
        altEmail: '',
        mobNo: '',
        altMobNo: '',
        presentStreet: '',
        presentCity: '',
        presentState: '',
        presentZip: '',
        presentCountry: '',
        isAddressSame: false,
        parmaStreet: '',
        parmaCity: '',
        parmaState: '',
        parmaZip: '',
        parmaCountry: '',
        roleId: 0,
        deptId: 0,
        doj: '',
        expInYear: 0,
        isActive: true
    });

    const handleImageChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setForm((prev) => ({
                    ...prev,
                    empPhoto: reader.result // base64 in form
                }));
            };
            reader.readAsDataURL(file);
        }
    };

    // Sync address when checkbox changes
    const handleSameAddressToggle = (e) => {
        const checked = e.target.checked;

        if (checked) {
            setForm((prev) => ({
                ...prev,
                parmaStreet: prev.presentStreet,
                parmaCity: prev.presentCity,
                parmaState: prev.presentState,
                parmaZip: prev.presentZip,
                parmaCountry: prev.presentCountry,
                isAddressSame: true
            }));
        }
        else {
            setForm((prev) => ({
                ...prev,
                parmaStreet: '',
                parmaCity: '',
                parmaState: '',
                parmaZip: '',
                parmaCountry: '',
                isAddressSame: false
            }));
        }
    };

    const triggerUpload = () => fileInputRef.current?.click();

    useEffect(() => {
        const fetchDropdowns = async () => {
            showLoader();
            try {
                const [rolesRes, deptRes] = await Promise.all([
                    axiosInstance.get(`${import.meta.env.VITE_API_BASE_URL}/api/Master/GetRolesDD`),
                    axiosInstance.get(`${import.meta.env.VITE_API_BASE_URL}/api/Master/GetDeptDD`)
                ]);

                if (rolesRes.data) {
                    setRoles(rolesRes.data.map(role => ({
                        label: role.roleName,
                        value: role.roleId.toString(),
                    })));
                }

                if (deptRes.data) {
                    setDept(deptRes.data.map(dep => ({
                        label: dep.deptName,
                        value: dep.deptId.toString(),
                    })));
                }

                if (id) {
                    await fetchUserById(id);
                }
            } catch (err) {
                console.error("Error loading dropdowns", err);
            } finally {
                hideLoader();
            }
        };

        fetchDropdowns();
    }, [id]);

    const fetchUserById = async (userId) => {
        try {
            const token = localStorage.getItem("token");
            const res = await axiosInstance.get(`${import.meta.env.VITE_API_BASE_URL}/api/Master/GetMasterById?Type=Get_EmployeeDetailsById&Id=${userId}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true
            });
            console.log(res.data)
            if (res.status === 200 && res.data) {
                const data = res.data;
                setForm(prev => ({
                    ...prev,
                    empId: data.empId,
                    empPhoto: data.empPhoto,
                    empName: data.empName,
                    gender: data.gender,
                    qualification: data.qualification,
                    dob: data.dob,
                    maritalStatus: data.maritalStatus,
                    emailId: data.emailId,
                    altEmail: data.altEmail,
                    mobNo: data.mobNo,
                    altMobNo: data.altMobNo,
                    presentStreet: data.presentStreet,
                    presentCity: data.presentCity,
                    presentState: data.presentState,
                    presentZip: data.presentZip,
                    presentCountry: data.presentCountry,
                    isAddressSame: data.isAddressSame,
                    parmaStreet: data.parmaStreet,
                    parmaCity: data.parmaCity,
                    parmaState: data.parmaState,
                    parmaZip: data.parmaZip,
                    parmaCountry: data.parmaCountry,
                    roleId: data.roleId?.toString(),
                    deptId: data.deptId?.toString(),
                    doj: data.doj,
                    expInYear: data.expInYear,
                    isActive: data.isActive
                }));
            } else {
                showToast("error", "Error!", res.error || "Failed to load user data.");
            }
        } catch (error) {
            showToast("error", "Error!", error.message);
        }
    };


    const validate = () => {
        const newErrors = {};
        if (!form.empName.trim()) newErrors.empName = "Name is required";
        if (!form.gender) newErrors.gender = "Gender is required";
        if (!form.qualification) newErrors.qualification = "Qualification is required";
        if (!form.dob) newErrors.dob = "Date of Birth is required";
        if (!form.maritalStatus) newErrors.maritalStatus = "Marital Status is required";
        if (!form.emailId) newErrors.emailId = "Email is required";
        if (!form.mobNo) newErrors.mobNo = "Mobile number is required";
        if (!form.presentStreet) newErrors.presentStreet = "Street is required";
        if (!form.presentCity) newErrors.presentCity = "City is required";
        if (!form.presentState) newErrors.presentState = "State is required";
        if (!form.presentZip) newErrors.presentZip = "ZIP is required";
        if (!form.presentCountry) newErrors.presentCountry = "Country is required";
        if (!form.parmaStreet) newErrors.parmaStreet = "Street is required";
        if (!form.parmaCity) newErrors.parmaCity = "City is required";
        if (!form.parmaState) newErrors.parmaState = "State is required";
        if (!form.parmaZip) newErrors.parmaZip = "ZIP is required";
        if (!form.parmaCountry) newErrors.parmaCountry = "Country is required";
        if (!form.roleId) newErrors.roleId = "Role is required";
        if (!form.deptId) newErrors.deptId = "Department is required";
        if (!form.doj) newErrors.doj = "Date of Joining is required";
        if (!form.expInYear) newErrors.expInYear = "Experience is required";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) {
            alert({
                title: "Alert",
                description: "Please Fill All Mendetory Filed",
            })

            return;
        }
        //API call
        try {
            showLoader()
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/RegisterUser`
            const token = localStorage.getItem("token");
            const response = await axiosInstance.post(url, form, {
                headers: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true
            });
            if (response.status == 200) {
               
                hideLoader();
                if(response.data.msg_code == '1')
                    showToast("success", "Success!", "User Registered successfully.")
                else if(response.data.msg_code == '2')
                    showToast("info", "Success!", "User Updated successfully.")
                else
                    showToast("error", "Error!", "Failed to Update User.")
                
                navigate('/hospital/usermaster')

            } else {
                showToast("error", "Error!", "Failed to Register User.")
            }
        } catch (err) {
            console.log(err)
            alert({
                title: "API Error",
                description: err.message,
            })
        } finally {
            hideLoader()
        }
    };

    return (
        <div className="w-full mx-auto">
            <Card className='bg-gray-200 shadow-none'>
                <CardHeader className='flex justify-between items-center'>
                    <CardTitle className="text-gray-700">{id ? 'Edit' : 'Register'} Hospital User</CardTitle>
                    <Button
                        className='bg-red-600 text-white text-sm h-8 rounded'
                        onClick={(e) => navigate('/hospital/usermaster')}
                    >
                        Back
                    </Button>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="grid gap-8">
                        {/* Personal Information */}
                        <div className="border-2 border-gray-400 border-dashed bg-gray-200 rounded-sm p-4 relative">
                            <span className="absolute -top-3 left-4 bg-gray-200 px-2 text-sm font-semibold text-gray-600">Personal Information</span>
                            <div className="flex w-full gap-2">
                                <div className="items-center justify-center w-1/6 flex-col gap-4">
                                    <Avatar className="w-20 h-20 border-2 border-blue-500">
                                        <AvatarImage src={form.empPhoto || "/Images/DefaultProfile.jpg"} />
                                        <AvatarFallback>U</AvatarFallback>
                                    </Avatar>
                                    <div className="mt-2">
                                        <input
                                            type="file"
                                            accept="image/*"
                                            ref={fileInputRef}
                                            onChange={handleImageChange}
                                            className="hidden"
                                        />
                                        <Button type="button" onClick={triggerUpload} className="rounded h-8 text-xs bg-blue-600 text-white">
                                            Upload
                                        </Button>
                                    </div>
                                </div>

                                <div className="w-5/6 grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div>
                                        <Label htmlFor="name" className='mb-2'>Full Name <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="name"
                                            className='rounded bg-white'
                                            placeholder="Enter full name"
                                            value={form.empName}
                                            onChange={(e) => setForm({ ...form, empName: e.target.value })}
                                        />
                                        {errors.empName && <p className="text-red-600 text-sm">{errors.empName}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="Gender" className='mb-2'>Gender <span className="text-red-600 font-bold">*</span></Label>
                                        <Select id='Gender'
                                            value={form.gender}
                                            onValueChange={(val) => setForm({ ...form, gender: val })}
                                        >
                                            <SelectTrigger className='w-full rounded bg-white'>
                                                <SelectValue placeholder="Select Gender" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Male">Male</SelectItem>
                                                <SelectItem value="Female">Female</SelectItem>
                                                <SelectItem value="Others">Others</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        {errors.gender && <p className="text-red-600 text-sm">{errors.gender}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="qualification" className='mb-2'>Qualification <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="qualification"
                                            className='rounded bg-white'
                                            placeholder="e.g. MBBS, GNM, B.Com"
                                            value={form.qualification}
                                            onChange={(e) => setForm({ ...form, qualification: e.target.value })}
                                        />
                                        {errors.qualification && <p className="text-red-600 text-sm">{errors.qualification}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="DOB" className='mb-2'>Date Of Birth <span className="text-red-600 font-bold">*</span></Label>
                                        <CustomDatePicker
                                            selected={form.dob}
                                            onChange={(date) => setForm({ ...form, dob: date })}
                                            disableFuture={true} // disables dates after today
                                        />
                                        {errors.dob && <p className="text-red-600 text-sm">{errors.dob}</p>}
                                    </div>
                                    {/* Marital Status */}
                                    <div className="md:col-span-2 flex flex-col">
                                        <Label className="mb-1">
                                            Marital Status <span className="text-red-600 font-bold">*</span>
                                        </Label>
                                        <div className="flex gap-4 mt-1">
                                            <label className="flex items-center gap-1">
                                                <input
                                                    type="radio"
                                                    name="maritalStatus"
                                                    value="Single"
                                                    className="accent-blue-600"
                                                    checked={form.maritalStatus === "Single"}
                                                    onChange={(e) => setForm({ ...form, maritalStatus: e.target.value })}
                                                />
                                                <span>Single</span>
                                            </label>
                                            <label className="flex items-center gap-1">
                                                <input
                                                    type="radio"
                                                    name="maritalStatus"
                                                    value="Married"
                                                    className="accent-blue-600"
                                                    checked={form.maritalStatus === "Married"}
                                                    onChange={(e) => setForm({ ...form, maritalStatus: e.target.value })}
                                                />
                                                <span>Married</span>
                                            </label>
                                            <label className="flex items-center gap-1">
                                                <input
                                                    type="radio"
                                                    name="maritalStatus"
                                                    value="Other"
                                                    className="accent-blue-600"
                                                    checked={form.maritalStatus === "Other"}
                                                    onChange={(e) => setForm({ ...form, maritalStatus: e.target.value })}
                                                />
                                                <span>Other</span>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        {/* Contact Details */}
                        <div className="border-2 border-gray-400 border-dashed bg-gray-200 rounded-sm p-4 relative">
                            <span className="absolute -top-3 left-4 bg-gray-200 font-semibold px-2 text-sm text-gray-600">Contact Details</span>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                                <div>
                                    <Label htmlFor="email" className='mb-2'>Email <span className="text-red-600 font-bold">*</span></Label>
                                    <Input
                                        type="email"
                                        className='rounded bg-white'
                                        id="email"
                                        placeholder="Enter email"
                                        value={form.emailId}
                                        onChange={(e) => setForm({ ...form, emailId: e.target.value })}
                                    />
                                    {errors.emailId && <p className="text-red-600 text-sm">{errors.emailId}</p>}
                                </div>
                                <div>
                                    <Label htmlFor="alternativeemail" className='mb-2'>Alternative Email</Label>
                                    <Input
                                        type="email"
                                        className='rounded bg-white'
                                        id="email"
                                        placeholder="Enter Alternative email"
                                        value={form.altEmail}
                                        onChange={(e) => setForm({ ...form, altEmail: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <Label htmlFor="mobile" className='mb-2'>Mobile <span className="text-red-600 font-bold">*</span></Label>
                                    <Input
                                        type="tel"
                                        className='rounded bg-white'
                                        id="mobile"
                                        placeholder="Enter Mobile number"
                                        value={form.mobNo}
                                        onChange={(e) => setForm({ ...form, mobNo: e.target.value })}
                                    />
                                    {errors.mobNo && <p className="text-red-600 text-sm">{errors.mobNo}</p>}
                                </div>
                                <div>
                                    <Label htmlFor="phone" className='mb-2'>Phone Number</Label>
                                    <Input
                                        type="tel"
                                        className='rounded bg-white'
                                        id="phone"
                                        placeholder="Enter phone number"
                                        value={form.altMobNo}
                                        onChange={(e) => setForm({ ...form, altMobNo: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Address Section */}
                        <div className="border-2 border-gray-400 border-dashed bg-gray-200 rounded-sm p-4 relative mt-6">
                            <span className="absolute -top-3 left-4 bg-gray-200 font-semibold px-2 text-sm text-gray-600">Address</span>

                            {/* Present Address */}
                            <div className="mb-6">
                                <span className="font-semibold text-sm text-gray-700 mb-2 block">Present Address <span className="text-red-600 font-bold">*</span></span>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div>
                                        <Label htmlFor="presentStreet" className='mb-2'>Street</Label>
                                        <Input
                                            id="presentStreet"
                                            className="bg-white rounded"
                                            placeholder='Enter your street'
                                            value={form.presentStreet}
                                            onChange={(e) => setForm({ ...form, presentStreet: e.target.value })}
                                        />
                                        {errors.presentStreet && <p className="text-red-600 text-sm">{errors.presentStreet}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="presentCity" className='mb-2'>City <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="presentCity"
                                            placeholder='Enter your city'
                                            className="bg-white rounded"
                                            value={form.presentCity}
                                            //onChange={(e) => handlePresentChange("presentCity", e.target.value)}
                                            onChange={(e) => setForm({ ...form, presentCity: e.target.value })}
                                        />
                                        {errors.presentCity && <p className="text-red-600 text-sm">{errors.presentCity}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="presentState" className='mb-2'>State <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="presentState"
                                            placeholder='Enter your state'
                                            className="bg-white rounded"
                                            value={form.presentState}
                                            onChange={(e) => setForm({ ...form, presentState: e.target.value })}
                                        />
                                        {errors.presentState && <p className="text-red-600 text-sm">{errors.presentState}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="presentZip" className='mb-2'>Zip <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="presentZip"
                                            placeholder='Enter zip code'
                                            className="bg-white rounded"
                                            value={form.presentZip}
                                            //onChange={(e) => handlePresentChange("presentZip", e.target.value)}
                                            onChange={(e) => setForm({ ...form, presentZip: e.target.value })}
                                        />
                                        {errors.presentZip && <p className="text-red-600 text-sm">{errors.presentZip}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="presentCountry" className='mb-2'>Country <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="presentCountry"
                                            placeholder='Enter country'
                                            className="bg-white rounded"
                                            value={form.presentCountry}
                                            onChange={(e) => setForm({ ...form, presentCountry: e.target.value })}
                                        />
                                        {errors.presentCountry && <p className="text-red-600 text-sm">{errors.presentCountry}</p>}
                                    </div>
                                </div>
                            </div>

                            {/* Checkbox */}
                            <div className="mb-4 flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    id="sameAddress"
                                    className="accent-blue-600"
                                    checked={form.isAddressSame}
                                    onChange={handleSameAddressToggle}
                                />
                                <label htmlFor="sameAddress" className="text-sm text-red-700">
                                    Permanent Address is same as Present Address
                                </label>
                            </div>

                            {/* Permanent Address */}
                            <div>
                                <span className="font-semibold text-sm text-gray-700 mb-2 block">Permanent Address</span>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div>
                                        <Label htmlFor="permanentStreet" className='mb-2'>Street <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="permanentStreet"
                                            className="bg-white rounded"
                                            value={form.parmaStreet}
                                            placeholder='Enter your Street'
                                            onChange={(e) => setForm({ ...form, parmaStreet: e.target.value })}
                                            disabled={form.isAddressSame}
                                        />
                                        {errors.parmaStreet && <p className="text-red-600 text-sm">{errors.parmaStreet}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="permanentCity" className='mb-2'>City <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="permanentCity"
                                            className="bg-white rounded"
                                            placeholder='Select your city'
                                            value={form.parmaCity}
                                            // onChange={(e) =>
                                            //     setPermanentAddress({ ...permanentAddress, city: e.target.value })
                                            // }
                                            onChange={(e) => setForm({ ...form, parmaCity: e.target.value })}
                                            disabled={form.isAddressSame}
                                        />
                                        {errors.parmaCity && <p className="text-red-600 text-sm">{errors.parmaCity}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="permanentState" className='mb-2'>State <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="permanentState"
                                            className="bg-white rounded"
                                            placeholder='Enter your state'
                                            value={form.parmaState}
                                            onChange={(e) => setForm({ ...form, parmaState: e.target.value })}
                                            disabled={form.isAddressSame}
                                        />
                                        {errors.parmaState && <p className="text-red-600 text-sm">{errors.parmaState}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="permanentZip" className='mb-2'>Zip <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="permanentZip"
                                            className="bg-white rounded"
                                            placeholder='Enter zip code'
                                            value={form.parmaZip}
                                            onChange={(e) => setForm({ ...form, parmaZip: e.target.value })}
                                            disabled={form.isAddressSame}
                                        />
                                        {errors.parmaZip && <p className="text-red-600 text-sm">{errors.parmaZip}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="permanentCountry" className='mb-2'>Country <span className="text-red-600 font-bold">*</span></Label>
                                        <Input
                                            id="permanentCountry"
                                            className="bg-white rounded"
                                            placeholder='select country'
                                            value={form.parmaCountry}
                                            onChange={(e) => setForm({ ...form, parmaCountry: e.target.value })}
                                            disabled={form.isAddressSame}
                                        />
                                        {errors.parmaCountry && <p className="text-red-600 text-sm">{errors.parmaCountry}</p>}
                                    </div>
                                </div>
                            </div>
                        </div>


                        {/* Professional Details */}
                        <div className="border-2 border-gray-400 border-dashed bg-gray-200 rounded-sm p-4 relative mt-6">
                            <span className="absolute -top-3 left-4 bg-gray-200 font-semibold px-2 text-sm text-gray-600">Official Details</span>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div>
                                    <SearchableDD
                                        options={roles}
                                        value={form.roleId}
                                        onChange={(val) => setForm({ ...form, roleId: val })}
                                        label="Role"
                                        placeholder="Select a Role"
                                        required
                                    />
                                    {errors.roleId && <p className="text-red-600 text-sm">{errors.roleId}</p>}
                                </div>
                                <div>
                                    <SearchableDD
                                        options={dept}
                                        value={form.deptId}
                                        onChange={(val) => setForm({ ...form, deptId: val })}
                                        label="Department"
                                        placeholder="Select Department"
                                        required
                                    />
                                    {errors.deptId && <p className="text-red-600 text-sm">{errors.deptId}</p>}
                                </div>
                                <div>
                                    <Label htmlFor="doj" className='mb-2'>Date of Joining <span className="text-red-600">*</span></Label>
                                    <CustomDatePicker
                                        selected={form.doj}
                                        onChange={(date) => setForm({ ...form, doj: date })}
                                        disableFuture={false} // disables dates after today
                                    />
                                    {errors.doj && <p className="text-red-600 text-sm">{errors.doj}</p>}
                                </div>
                                <div>
                                    <Label htmlFor="exp" className='mb-2'>{`Experience (in year)`} <span className="text-red-600">*</span></Label>
                                    <Input
                                        id="exp"
                                        type='number'
                                        className='bg-white rounded'
                                        placeholder="Enter Experience"
                                        value={form.expInYear}
                                        onChange={(e) => setForm({ ...form, expInYear: e.target.value })}
                                    />
                                    {errors.expInYear && <p className="text-red-600 text-sm">{errors.expInYear}</p>}
                                </div>
                                {/* Active or InActive*/}
                                {id &&
                                    <div className="md:col-span-2 flex flex-col">
                                        <Label className="mb-1">
                                            User Status <span className="text-red-600 font-bold">*</span>
                                        </Label>
                                        <div className="flex gap-4 mt-1">
                                            <label className="flex items-center gap-1">
                                                <input
                                                    type="radio"
                                                    name="isActive"
                                                    value="true"
                                                    className="accent-blue-600"
                                                    checked={form.isActive === true}
                                                    onChange={() => setForm({ ...form, isActive: true })}
                                                />
                                                <span>Active</span>
                                            </label>
                                            <label className="flex items-center gap-1">
                                                <input
                                                    type="radio"
                                                    name="isActive"
                                                    value="false"
                                                    className="accent-blue-600"
                                                    checked={form.isActive === false}
                                                    onChange={() => setForm({ ...form, isActive: false })}
                                                />
                                                <span>InActive</span>
                                            </label>
                                        </div>
                                    </div>
                                }

                            </div>
                        </div>

                        <div className="flex justify-end">
                            <Button type="submit" className="bg-green-700 rounded hover:bg-green-900 text-white px-6">
                                {id ? 'Update' : 'Register User'}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
};

export default RegisterUser;
