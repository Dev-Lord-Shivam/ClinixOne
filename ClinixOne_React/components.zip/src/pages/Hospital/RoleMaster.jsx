import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { DataTable } from '../../components/custom/DataTable';
import { Badge } from "@/components/ui/badge";
import { Pencil } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLoader } from '../../Context/LoaderProvider';
import useShowToast from '../../Context/useShowToast';
import axiosInstance from '../../Context/axiosInstance';
import { Link } from "react-router-dom";
import RoleDialogue from '../../components/custom/RoleDialogue';


const RoleMaster = () => {
    const token = localStorage.getItem("token");
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const navigate = useNavigate();
    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast();
    const [rolesList, setRolesList] = useState([]);
    const [openModal, setOpenModal] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [selectedRole, setSelectedRole] = useState(null);

    useEffect(() => {
        getRolesList();
    }, [])

    const getRolesList = async () => {
        try {
            showLoader()
            const token = localStorage.getItem("token");
            const res = await axiosInstance.get(`${baseUrl}/api/Master/GetMasterById?Type=GetRolesList`, {
                headers: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true
            })

            if (res.status == 200) {
                console.log(res)
                setRolesList(res.data);
            }
            else {
                showToast("error", "Error!", 'Failed to Load')
            }
        } catch (error) {
            showToast("error", "Error!", error.message)
        } finally {
            hideLoader();
        }
    }

    const handleEdit = (rowData) => {
        setIsEdit(true);
        setSelectedRole(rowData);
        setOpenModal(true);
    };
    const handleSubmitRole = async (data) => {
        try {
            showLoader();
            console.log(selectedRole)
            const res = await axiosInstance.post(
                `${baseUrl}/api/Master/RoleAddUpdate`,
                {
                    ...data,
                    roleId: selectedRole?.roleId
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            if (res.status === 200) {
                showToast("success", "Success", res.data.message);
                setOpenModal(false);
                getRolesList();
            } else {
                showToast("error", "Error!", res.data.message);
            }

        } catch (err) {
            showToast("error", "Error", err.response?.data?.message || err.message);
        } finally {
            hideLoader();
        }
    };


    const rolesColumns = [
        {
            accessorKey: "action",
            header: "Action",
            enableColumnFilter: false,
            size: 100,
            cell: ({ row }) => {
                const empId = row.original.empId;
                return (
                    <button
                        onClick={() => handleEdit(row.original)}
                        className="text-white p-2 rounded-full cursor-pointer bg-blue-500 hover:text-blue-500 hover:bg-white"
                    >
                        <Pencil size={18} />
                    </button>
                );
            }
        },
        { accessorKey: "roleId", header: "Role id", size: 50, hidden: true },
        { accessorKey: "roleName", header: "Role Name" },
        {
            accessorKey: "menuAccess",
            header: "Menu Access Rights",
            cell: ({ row }) => {
                const roleId = row.original.roleId;
                const isActive = row.original.isActive;
                const portalType = row.original.portalType
                const roleName = row.original.roleName
                return (
                    <Link to={`/hospital/menuaccess/${roleId}/${portalType}/${roleName}`}>
                        <Badge
                            className={
                                isActive
                                    ? "bg-blue-500 text-white cursor-pointer"
                                    : "bg-red-500 text-white cursor-pointer"
                            }
                        >
                            Menu Access Rights
                        </Badge>
                    </Link>

                );
            },
        },
        { accessorKey: "portalType", header: "Portal Type" },
        { accessorKey: "createdAt", header: "Created On" },
        { accessorKey: "createdBy", header: "Created By" },
        {
            accessorKey: "isActive", header: "Statue",
            cell: ({ row }) => {
                const isActive = row.getValue("isActive");
                return (
                    <Badge
                        className={isActive ? "bg-green-500 text-white" : "bg-red-500 text-white"}
                    >
                        {isActive ? "Active" : "Inactive"}
                    </Badge>
                );
            },
        },

    ];

    return (
        <div className="p-1">
            <div className='flex justify-between items-center w-full'>
                <h2 className="text-xl font-semibold mb-4">Role Master</h2>
                <Button
                    onClick={() => {
                        setIsEdit(false);
                        setSelectedRole(null);
                        setOpenModal(true);
                    }}
                    className="bg-blue-600 rounded text-xs h-8 w-20"
                >
                    Add Roles
                </Button>

            </div>
            <div className='mt-4'>
                <DataTable
                    columns={rolesColumns}
                    data={rolesList}
                    pageSize={100}
                    headerBgColor="bg-blue-800"
                    headerTextColor="text-white"
                />
            </div>

            <RoleDialogue
                open={openModal}
                onClose={() => setOpenModal(false)}
                isEdit={isEdit}
                roleData={selectedRole}
                onSubmit={handleSubmitRole}
            />

        </div>
    );
};

export default RoleMaster;

