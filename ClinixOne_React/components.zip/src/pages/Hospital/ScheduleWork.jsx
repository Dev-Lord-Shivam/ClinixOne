import { useState, useEffect, useCallback, useMemo } from "react";
import { useParams } from "react-router-dom";
import { Calendar, dateFnsLocalizer } from "react-big-calendar";
import format from "date-fns/format";
import parse from "date-fns/parse";
import startOfWeek from "date-fns/startOfWeek";
import getDay from "date-fns/getDay";
import enUS from 'date-fns/locale/en-US';
import "react-big-calendar/lib/css/react-big-calendar.css";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { ChevronLeft, ChevronRight, Calendar as CalIcon, Grid as TableIcon, ChevronDown, XCircle } from "lucide-react";
import CustomDatePicker from "../../components/custom/CustomDatePicker";
import CustomTimePicker from "../../components/custom/CustomTimePicker";
import axiosInstance from "../../Context/axiosInstance";
import { useLoader } from "../../Context/LoaderProvider";
import { useCustomAlert } from "../../Context/CustomAlertProvider";
import useShowToast from "../../Context/useShowToast";
import SearchableDD from "../../components/custom/SearchableDD";

// Constants
const SHIFT_TYPES = [
  { label: 'Consultation', value: 'Consultation' },
  { label: 'Operation', value: 'Operation' },
  { label: 'Lab', value: 'Lab' }
];

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const RECURRENCE_TYPES = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" }
];

const DEFAULT_FORM_STATE = {
  title: "Available Shift",
  type: '',
  startTime: "09:00",
  endTime: "17:00",
  isRecurring: false,
  recurrenceType: "weekly",
  maxPatients: 10,
  selectedDays: [],
  selectedDate: [],
  recurringStart: "",
  recurringEnd: "",
  clinicid: "",
  locationid: ""
};

// Utility functions
const parseDateTime = (str) => {
  const [datePart, timePart] = str.split(" ");
  const [month, day, year] = datePart.split("/").map(Number);
  return new Date(`${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}T${timePart}`);
};

const formatDate = (date) => {
  return `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}/${date.getFullYear()}`;
};

const parseDateString = (dateString) => {
  const [day, month, year] = dateString.split("/").map(Number);
  return new Date(year, month - 1, day);
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales: { 'en-US': enUS },
});

export default function ScheduleWork() {
  const { empId } = useParams();
  const { showLoader, hideLoader } = useLoader();
  const showToast = useShowToast();
  const alert = useCustomAlert();

  // State
  const [events, setEvents] = useState([]);
  const [calendarEvents, setCalendarEvents] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [calendarMinimized, setCalendarMinimized] = useState(false);
  const [formState, setFormState] = useState(DEFAULT_FORM_STATE);
  const [clinic, setSelectedClinic] = useState([]);
  const [location, setLocation] = useState([]);

  // Update form field helper
  const updateFormField = (field, value) => {
    setFormState(prev => ({ ...prev, [field]: value }));
  };

  // Fetch schedules
  const fetchSchedules = useCallback(async () => {
    try {
      showLoader();
      const token = localStorage.getItem("token");
      const baseUrl = import.meta.env.VITE_API_BASE_URL;
      const config = {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      };

      // Fetch shifts
      const shiftsRes = await axiosInstance.get(
        `${baseUrl}/api/Master/GetShift?EmpId=${empId}&Type=Get_ShiftsById`,
        config
      );

      const mappedEvents = (shiftsRes.data || []).map((item) => ({
        shiftId: item.shiftId,
        rowType: item.rowType,
        shiftDate: item.shiftDate,
        dayName: item.dayName,
        timeRange: item.timeRange,
        title: `${item.title} (${item.maxPatients} max)`,
        recurrenceType: item.recurrenceType,
        isRecurring: item.isRecurring,
        maxPatients: item.maxPatients,
      }));
      setEvents(mappedEvents);

      // Fetch calendar view
      const calendarRes = await axiosInstance.get(
        `${baseUrl}/api/Master/GetShift?EmpId=${empId}&Type=Get_ShiftCalenderView`,
        config
      );

      const calendarData = (calendarRes.data || []).map((item) => ({
        title: item.title,
        start: parseDateTime(item.recurringStart),
        end: parseDateTime(item.recurringEnd),
        allDay: false,
      }));
      setCalendarEvents(calendarData);

      const res = await axiosInstance.get(`${baseUrl}/api/Master/GetCountryStateCity?Type=GetClinicDD`);
      setSelectedClinic(res.data.map(item => ({
        label: item.text,
        value: item.value
      })))


    } catch (error) {
      console.error("Error fetching schedules:", error);
      showToast("error", "Error!", "Failed to fetch schedules.");
    } finally {
      hideLoader();
    }
  }, [empId, showLoader, hideLoader, showToast]);

  useEffect(() => {
    fetchSchedules();
  }, []);

  // Validation
  const validateForm = useCallback(() => {
    const { title, isRecurring, recurringStart, startTime, endTime, maxPatients, recurrenceType, selectedDays } = formState;

    if (!title.trim()) {
      alert({ title: "Alert", description: "Please provide a title for the schedule." });
      return false;
    }

    if (isRecurring && !recurringStart) {
      alert({ title: "Alert", description: "Please select a start date." });
      return false;
    }

    if (!startTime || !endTime) {
      alert({ title: "Alert", description: "Please provide both start and end times." });
      return false;
    }

    if (new Date(`1970-01-01T${startTime}`) >= new Date(`1970-01-01T${endTime}`)) {
      alert({ title: "Alert", description: "Start time must be before end time." });
      return false;
    }

    if (!maxPatients || maxPatients <= 0) {
      alert({ title: "Alert", description: "Please enter a valid max number of patients." });
      return false;
    }

    if (isRecurring && recurrenceType === "weekly" && selectedDays.length === 0) {
      alert({ title: "Alert", description: "Please select at least one day for weekly recurrence." });
      return false;
    }

    return true;
  }, [formState, alert]);

  // Handle schedule confirmation
  const handleConfirmSchedule = async () => {
    if (!validateForm()) return;

    const newEvent = {
      EmpId: empId,
      ...formState,
    };
    console.log(newEvent)
    try {
      showLoader();
      const token = localStorage.getItem("token");
      const response = await axiosInstance.post(
        `${import.meta.env.VITE_API_BASE_URL}/api/Master/AddShift`,
        newEvent,
        {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true
        }
      );

      if (response.status !== 200 && response.data.msg_code !== '1') {
        showToast("error", "Error!", "Failed to Register Shift.");
      } else {
        showToast("success", "Success!", "Shift Registered successfully.");
        setFormState(DEFAULT_FORM_STATE);
        setDialogOpen(false);
        await fetchSchedules();
      }
    } catch (error) {
      console.error("Error saving schedule:", error);
      alert({ title: "Alert", description: "Something went wrong while saving. Please try again." });
    } finally {
      hideLoader();
    }
  };

  const fetchRoomsByClinicId = async (clinicid) => {
    try {
      showLoader()
      const res = await axiosInstance.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=GetRoomDDById&Id=${clinicid}`
      );
      setLocation(res.data.map(item => ({
        label: item.text,
        value: item.value,
      })))
    } catch (error) {
      console.error("Error fetching rooms:", error);
      showToast('error', 'error!', 'failed to fetch Rooms');
    } finally {
      hideLoader()
    }
  }

  // Handle recurring end date change
  const handleRecurringEndChange = useCallback((dateString) => {
    if (!formState.recurringStart || !dateString) {
      updateFormField('recurringEnd', dateString);
      return;
    }

    const startDate = parseDateString(formState.recurringStart);
    const endDate = parseDateString(dateString);

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      console.error("Invalid date format");
      return;
    }

    const minEndDate = new Date(startDate);
    minEndDate.setDate(minEndDate.getDate() + 7);

    if (endDate < minEndDate) {
      alert({ title: "Alert", description: "Occur Until must be at least 7 days after Start From." });
      updateFormField('recurringEnd', formatDate(minEndDate));
    } else {
      updateFormField('recurringEnd', dateString);
    }
  }, [formState.recurringStart, alert]);

  // Handle recurring start change
  const handleRecurringStartChange = useCallback((dateString) => {
    updateFormField('recurringStart', dateString);

    if (dateString) {
      const parsedDate = parseDateString(dateString);
      if (!isNaN(parsedDate.getTime())) {
        const occurUntil = new Date(parsedDate);
        occurUntil.setDate(occurUntil.getDate() + 30);
        updateFormField('recurringEnd', formatDate(occurUntil));
      } else {
        updateFormField('recurringEnd', '');
      }
    } else {
      updateFormField('recurringEnd', '');
    }
  }, []);

  // Toggle day selection
  const toggleDay = useCallback((dayIndex) => {
    setFormState(prev => ({
      ...prev,
      selectedDays: prev.selectedDays.includes(dayIndex)
        ? prev.selectedDays.filter(d => d !== dayIndex)
        : [...prev.selectedDays, dayIndex]
    }));
  }, []);

  // Grouped events for table
  const groupedEvents = useMemo(() => {
    return events
      .filter(e => e.rowType === "PARENT")
      .map(parent => ({
        parent,
        children: events.filter(c => c.rowType === "CHILD" && c.shiftId === parent.shiftId)
      }));
  }, [events]);

  return (
    <div className="p-4 bg-white rounded-xl shadow-lg border border-gray-200">
      <div className="flex gap-4 h-[700px]">
        {/* Calendar Section */}
        <div className={`transition-all duration-300 ${calendarMinimized ? 'w-12' : 'w-2/3'} border-r border-gray-200 pr-4`}>
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <CalIcon className="w-5 h-5" />
              {!calendarMinimized && <h2 className="text-lg font-semibold">Schedule Calendar</h2>}
            </div>
            <div className="flex gap-2">
              {!calendarMinimized && (
                <>
                  <Button
                    className='rounded bg-green-600 text-xs h-8 shadow-lg'
                    onClick={() => setDialogOpen(true)}
                  >
                    Add Routine
                  </Button>
                  <Button className='rounded bg-blue-600 text-xs h-8 shadow-lg'>
                    Add Events
                  </Button>
                </>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCalendarMinimized(!calendarMinimized)}
                className="p-2 h-8 w-8"
              >
                {calendarMinimized ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {!calendarMinimized ? (
            <Calendar
              localizer={localizer}
              events={calendarEvents}
              selectable
              style={{ height: 600 }}
              onSelectSlot={(slotInfo) => setSelectedSlot(slotInfo.start)}
              views={["month", "week", "day", "agenda"]}
              className="bg-white rounded-lg border"
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <CalIcon className="w-8 h-8 mb-2" />
              <p className="text-xs text-center transform -rotate-90 whitespace-nowrap">Calendar</p>
            </div>
          )}
        </div>

        {/* Table Section */}
        {/* Table Section */}
        <div className={`transition-all duration-300 ${calendarMinimized ? 'w-11/12' : 'w-1/3'} pl-4`}>
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <TableIcon className="w-5 h-5" />
                <CardTitle className="text-lg">Scheduled Events</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[600px] overflow-y-auto">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead className="w-8"></TableHead>
                      <TableHead className="text-xs">Title</TableHead>
                      <TableHead className="text-xs">Max Patients</TableHead>
                      <TableHead className="text-xs">Type</TableHead>
                      <TableHead className="text-xs text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {groupedEvents.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-gray-500 py-8">
                          No scheduled events found
                        </TableCell>
                      </TableRow>
                    ) : (
                      groupedEvents.map(({ parent, children }) => (
                        <Collapsible key={parent.shiftId} asChild>
                          <>
                            <TableRow className="hover:bg-gray-50">
                              <TableCell>
                                <CollapsibleTrigger asChild>
                                  <button className="flex items-center gap-1 text-blue-500 hover:text-blue-700">
                                    <ChevronDown className="w-4 h-4 transition-transform duration-200" />
                                  </button>
                                </CollapsibleTrigger>
                              </TableCell>
                              <TableCell className="text-xs font-medium">
                                {parent.title?.replace(/ \(\d+ max\)/, "")}
                              </TableCell>
                              <TableCell className="text-xs">{parent.maxPatients}</TableCell>
                              <TableCell className="text-xs">
                                <span
                                  className={`px-2 py-1 rounded-full text-xs ${parent.isRecurring
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-green-100 text-green-800"
                                    }`}
                                >
                                  {parent.isRecurring ? parent.recurrenceType : "One-time"}
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <button
                                  onClick={() => {
                                    if (window.confirm(`Delete all ${children.length} occurrences of "${parent.title?.replace(/ \(\d+ max\)/, "")}"?`)) {
                                      const childIds = children.map(c => c.id);
                                      setEvents(prev => prev.filter(e => !childIds.includes(e.id)));
                                    }
                                  }}
                                  className="px-3 py-1 text-xs bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
                                >
                                  Delete All
                                </button>
                              </TableCell>
                            </TableRow>

                            {children.map((child) => (
                              <TableRow key={child.shiftDate}>
                                <TableCell colSpan={5} className="p-0">
                                  <CollapsibleContent>
                                    <div className="p-4 bg-gray-50 flex items-center justify-between">
                                      <div className="grid grid-cols-3 gap-4 text-xs text-gray-700 flex-1">
                                        <div>
                                          <span className="font-semibold">Date:</span> {child.shiftDate}
                                        </div>
                                        <div>
                                          <span className="font-semibold">Day:</span> {child.dayName}
                                        </div>
                                        <div>
                                          <span className="font-semibold">Time:</span> {child.timeRange}
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => {
                                          if (window.confirm(`Delete event on ${child.shiftDate}?`)) {
                                            setEvents(prev => prev.filter(e => e.id !== child.id));
                                          }
                                        }}
                                        className="px-3 py-1 text-xs bg-red-500 text-white rounded hover:bg-red-600 transition-colors ml-4"
                                      >
                                        Delete
                                      </button>
                                    </div>
                                  </CollapsibleContent>
                                </TableCell>
                              </TableRow>
                            ))}
                          </>
                        </Collapsible>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Sheet open={dialogOpen} onOpenChange={setDialogOpen}>
        <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto p-0">
          <SheetHeader className="bg-white border-b border-gray-400 px-6 py-4 sticky top-0 z-10">
            <SheetTitle className="text-lg font-semibold">
              Schedule Routine
            </SheetTitle>
          </SheetHeader>

          <div className="p-6 space-y-5">
            {/* Title and Type Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-sm font-medium">
                  Title <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="title"
                  className="w-full form-control"
                  type="text"
                  value={formState.title}
                  onChange={(e) => updateFormField('title', e.target.value)}
                  placeholder="Enter shift title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type" className="text-sm font-medium">
                  Type <span className="text-red-500">*</span>
                </Label>
                <Select value={formState.type} onValueChange={(v) => updateFormField('type', v)}>
                  <SelectTrigger id="type" className="w-full form-control">
                    <SelectValue placeholder="Select shift type" />
                  </SelectTrigger>
                  <SelectContent>
                    {SHIFT_TYPES.map((item) => (
                      <SelectItem key={item.value} value={item.value}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Date and Time Section */}
            <div className="space-y-4">
              {!formState.isRecurring && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Start Date</Label>
                  <CustomDatePicker
                    onChange={(date) => updateFormField('selectedDate', date)}
                    disableFuture={false}
                    disablePast={true}
                    multiSelect={true}
                    className="w-full"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startTime" className="text-sm font-medium">
                    Start Time <span className="text-red-500">*</span>
                  </Label>
                  <CustomTimePicker
                    id="startTime"
                    value={formState.startTime}
                    className="form-control"
                    onChange={(v) => updateFormField('startTime', v)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endTime" className="text-sm font-medium">
                    End Time <span className="text-red-500">*</span>
                  </Label>
                  <CustomTimePicker
                    id="endTime"
                    value={formState.endTime}
                    className="form-control"
                    onChange={(v) => updateFormField('endTime', v)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Select Clinic <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={formState.clinicid}
                    onValueChange={(v) => {
                      updateFormField("clinicid", v);
                      fetchRoomsByClinicId(v);
                    }}
                  >
                    <SelectTrigger className="form-control w-full text-sm">
                      <SelectValue placeholder="Select clinic" />
                    </SelectTrigger>
                    <SelectContent>
                      {clinic.map((item) => (
                        <SelectItem key={item.value} value={item.value}>
                          {item.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Select Room <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={formState.locationid}
                    onValueChange={(v) => updateFormField("locationid", v)}
                  >
                    <SelectTrigger className="form-control w-full text-sm">
                      <SelectValue placeholder="Select room" />
                    </SelectTrigger>
                    <SelectContent>
                      {location.map((item) => (
                        <SelectItem key={item.value} value={item.value}>
                          {item.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Recurring Toggle */}
            <div className="flex items-center justify-between p-4 rounded-lg border bg-white-100">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Recurring Schedule</Label>
                <p className="text-xs text-gray-500">Enable to repeat this schedule</p>
              </div>
              <Switch
                checked={formState.isRecurring}
                onCheckedChange={(v) => updateFormField('isRecurring', v)}
              />
            </div>

            {/* Recurring Options */}
            {formState.isRecurring && (
              <div className="space-y-5 p-4 rounded-lg border bg-blue-50/50">
                {/* Days Selection */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Repeat On</Label>
                  <div className="grid grid-cols-7 gap-2">
                    {DAYS.map((day, index) => (
                      <button
                        key={day}
                        type="button"
                        onClick={() => toggleDay(index)}
                        className={`text-xs font-medium rounded-lg border py-2 px-1 transition-all ${formState.selectedDays.includes(index)
                          ? "bg-blue-600 text-white border-blue-600 shadow-sm"
                          : "bg-white text-gray-700 border-gray-300 hover:bg-blue-50 hover:border-blue-300"
                          }`}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Recurrence Settings */}
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="recurrence" className="text-sm font-medium">
                      Recurrence Pattern
                    </Label>
                    <Select
                      value={formState.recurrenceType}
                      onValueChange={(v) => updateFormField('recurrenceType', v)}
                    >
                      <SelectTrigger id="recurrence" className="w-full bg-white">
                        <SelectValue placeholder="Select recurrence" />
                      </SelectTrigger>
                      <SelectContent>
                        {RECURRENCE_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Start From</Label>
                      <CustomDatePicker
                        onChange={handleRecurringStartChange}
                        disableFuture={false}
                        disablePast={true}
                        className="w-full bg-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Occur Until</Label>
                      <div className="flex gap-2">
                        <CustomDatePicker
                          value={formState.recurringEnd}
                          onChange={handleRecurringEndChange}
                          disableFuture={false}
                          disablePast={true}
                          className="flex-1 bg-white"
                        />
                        {formState.recurringEnd && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                type="button"
                                onClick={() => updateFormField('recurringEnd', '')}
                                className="p-2 rounded-md text-red-500 hover:text-red-600 hover:bg-red-100 transition-colors"
                              >
                                <XCircle className="w-5 h-5" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent side="top">
                              Remove end date
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            )}

            {/* Max Patients */}
            <div className="space-y-2">
              <Label htmlFor="maxPatients" className="text-sm font-medium">
                Max Number of Patients
              </Label>
              <Input
                id="maxPatients"
                className="w-full form-control"
                type="number"
                min="1"
                value={formState.maxPatients}
                onChange={(e) => updateFormField('maxPatients', Number(e.target.value))}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 p-4 border-t border-gray-400 sticky bottom-0 bg-white">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
                className="px-4 cursor-pointer"
              >
                Cancel
              </Button>
              <Button
                type="button"
                onClick={handleConfirmSchedule}
                className="rounded-sm bg-blue-600 hover:bg-blue-700 text-white px-4 cursor-pointer"
              >
                Confirm
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>


    </div>
  );
}