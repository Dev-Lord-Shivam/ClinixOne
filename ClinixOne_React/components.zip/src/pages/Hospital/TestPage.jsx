import { useState } from "react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";

const shifts = [
  {
    id: 1,
    title: "Available Shift",
    maxPatients: 10,
    type: "Weekly",
    date: "02-10-2025",
    day: "Thursday",
    time: "09:00 - 17:00",
  },
  {
    id: 2,
    title: "Available Shift",
    maxPatients: 8,
    type: "Weekly",
    date: "06-10-2025",
    day: "Monday",
    time: "09:00 - 17:00",
  },
];

export default function CollapsibleRowsTable() {
  return (
    <div className="overflow-x-auto w-full">
      <table className="min-w-full border border-gray-200">
        <thead className="bg-gray-100">
          <tr>
            <th className="p-2 text-left">Title</th>
            <th className="p-2 text-left">Max Patients</th>
            <th className="p-2 text-left">Type</th>
            <th className="p-2 text-left">Action</th>
          </tr>
        </thead>
        <tbody>
          {shifts.map((shift) => (
            <Collapsible key={shift.id} asChild>
              <>
                {/* Main Row */}
                <tr className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="p-2">{shift.title}</td>
                  <td className="p-2">{shift.maxPatients}</td>
                  <td className="p-2">{shift.type}</td>
                  <td className="p-2">
                    <CollapsibleTrigger asChild>
                      <button className="flex items-center gap-1 text-blue-500">
                        <ChevronDown className="w-4 h-4 transition-transform duration-200" />
                      </button>
                    </CollapsibleTrigger>
                  </td>
                </tr>

                {/* Child Row */}
                <tr>
                  <td colSpan={4} className="p-0">
                    <CollapsibleContent>
                      <div className="p-4 bg-gray-50 grid grid-cols-3 text-sm text-gray-700">
                        <div><span className="font-semibold">Date:</span> {shift.date}</div>
                        <div><span className="font-semibold">Day:</span> {shift.day}</div>
                        <div><span className="font-semibold">Time:</span> {shift.time}</div>
                      </div>
                    </CollapsibleContent>
                  </td>
                </tr>
              </>
            </Collapsible>
          ))}
        </tbody>
      </table>
    </div>
  );
}
