import { useEffect, useState } from "react";
import { Phone, Check, FileText, CircleX, Undo2, RotateCcw, SquarePen, Stethoscope } from "lucide-react";
import { DataTable } from "../../components/custom/DataTable";
import useShowToast from "../../Context/useShowToast";
import { useLoader } from "../../Context/LoaderProvider";
import { Button } from "@/components/ui/button";
import axiosInstance from "../../Context/axiosInstance";
import { useConfirm } from "../../Context/ConfirmProvider";
import { useNavigate } from "react-router-dom";

const TodayAppointmentsPage = () => {

  const userInfo = JSON.parse(localStorage.getItem('user'))
  const token = localStorage.getItem("token");
  const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
  const showToast = useShowToast()
  const navigate = useNavigate();
  const confirm = useConfirm()
  const { showLoader, hideLoader } = useLoader()
  const [patients, setPatients] = useState([]);
  const [timer, setTimer] = useState(30);
  const [showCallModal, setShowCallModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);

  const handleCallPatient = async (patient) => {
    setSelectedPatient(patient);
    setShowCallModal(true);
    await ActionFunction(patient.aptId, 'Call_Patient')
    setShowCallModal(false);
  };

  const columns = [
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const patient = row.original;
        return (
          <div className="flex items-center gap-2">
            {patient.aptStatus === "Checked In" && (
              <button
                onClick={() => handleCallPatient(patient)}
                className="p-2 rounded bg-blue-200 text-blue-600 hover:bg-white"
              >
                <Phone size={16} />
              </button>
            )}
            {patient.aptStatus === "Under Oveservation" && patient.aptCategory != 'NEW' && (
              <button
                className="p-2 rounded bg-green-300 text-green-600 hover:bg-white"
              >
                <Check size={16} />
              </button>
            )}
            {(patient.aptStatus === 'Under Oveservation' || patient.aptStatus === 'Saved as Draft' || patient.aptStatus === 'Completed') && (
              <button className="p-2 rounded bg-orange-200 text-orange-600 hover:bg-white cursor-pointer"
                onClick={() => navigate(`/hospital/appointments/case-study/${patient.aptId}`)}
              >
                <SquarePen size={16} />
              </button>
            )}
            {patient.aptStatus == 'Confirm' && (
              <button className="p-2 rounded bg-purple-200 text-purple-600 hover:bg-white">
                <Undo2 size={16} />
              </button>
            )}
            {patient.aptStatus == 'Proceed' && (
              <button
                onClick={() => ActionFunction(patient.aptId, "Under_Observation")}
                className="p-2 rounded bg-blue-200 text-blue-600 hover:bg-white">
                <Stethoscope size={16} />
              </button>
            )}
            {patient.aptStatus === "Saved as Draft" && (
              <button
                onClick={() => ActionFunction(patient.aptId, "Complete")}
                className="p-2 rounded bg-green-300 text-green-600 hover:bg-white"
              >
                <Check size={16} />
              </button>
            )}
          </div>
        );
      },
    },
    { accessorKey: "patientId", header: "Patient ID" },
    { accessorKey: "patientName", header: "Name" },
    { accessorKey: "doctorName", header: "Doctor" },
    { accessorKey: "doctorId", header: "DoctorId", hidden: true },
    { accessorKey: "deptId", header: "Dept Id", hidden: true },
    { accessorKey: "aptId", header: "Apt Id", hidden: true },
    { accessorKey: "aptCategory", header: "Category" },
    { accessorKey: "deptName", header: "Department" },
    {
      accessorKey: "aptStatus",
      header: "Status",
      cell: ({ row }) => {
        const status = row.original.aptStatus;
        let color = ''
        switch (status) {
          case "Confirm":
            color = "bg-blue-100 text-blue-700"
            break;
          case "Completed":
            color = "bg-green-100 text-green-700"
            break;
          case "Not Visited":
            color = "bg-red-100 text-red-700"
            break;
          case "Checked In":
            color = "bg-yellow-100 text-yellow-700"
            break;
          case "Under Oveservation":
            color = "bg-red-100 text-red-700"
            break;
          case "Proceed":
            color = "bg-pink-100 text-pink-700"
            break;
          case "Cancelled":
            color = "bg-red-700 text-white"
            break;
          case "Saved as Draft":
            color = "bg-yellow-600 text-white"
            break;
          default:
            color = "bg-gray-100 text-gray-700"
            break;
        }
        return (
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
            {status.replace("_", " ")}
          </span>
        );
      },
    },

  ];

  useEffect(() => {
    fetchApt(); // Run immediately when component mounts

    // Refresh every 30 seconds
    const interval = setInterval(() => {
      fetchApt();
      setTimer(30); // reset countdown
    }, 30000);

    // Countdown display timer (updates every second)
    const countdown = setInterval(() => {
      setTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    // Cleanup on unmount
    return () => {
      clearInterval(interval);
      clearInterval(countdown);
    };
  }, []);

  const ActionFunction = async (AptId, Type) => {
    try {
      // Step 1: Determine confirmation message dynamically
      let confirmOptions = {
        title: "Are you sure?",
        description: "",
        confirmText: "Yes",
        cancelText: "No",
        intent: "danger",
      };

      switch (Type) {
        case "Call_Patient":
          confirmOptions.description = "Are you sure you want to call the patient?";
          break;
        case "Not_Visited":
          confirmOptions.description = "Are you sure you want to mark this appointment as not visited?";
          break;
        case "Under_Observation":
          confirmOptions.description = "Are you sure you want to mark as under observation?";
          break;
        case "Complete":
          confirmOptions.description = "Are you sure you want to close this appointment?";
          break;
        default:
          showToast("error", "Error!", "Invalid action type");
          return;
      }

      // Step 2: Ask for confirmation
      const confirmed = await confirm(confirmOptions);
      if (!confirmed) return;

      // Step 3: Execute API call
      showLoader();

      const url = `${baseUrl}/api/Hospital/UpdateAptStatus`;
      const params = {
        Type: Type,
        AptId: AptId,
      };

      const res = await axiosInstance.get(url, {
        params,
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      // Step 4: Handle response
      if (res.status === 200) {
        switch (Type) {
          case "Call_Patient":
            showToast("warning", "Calling Patient", "Calling for patient");
            break;
          case "Undo_CheckIn":
            showToast("info", "Undone", "Patient check-in has been undone");
            break;
          case "Not_Visited":
            showToast("info", "Updated", "Patient marked as not visited");
            break;
          case "Cancel_Appointment":
            showToast("info", "Updated", "Appointment cancelled successfully");
            break;
          case "Under_Observation":
            showToast("success", "Updated", "Patient Marked as Under Observation");
            break;
        }
        await fetchApt();
      } else {
        showToast("error", "Error!", "Failed to update appointment");
      }
    } catch (error) {
      showToast("error", "Error!", error.message || "Something went wrong");
    } finally {
      hideLoader();
    }
  };

  const fetchApt = async () => {
    try {
      showLoader()
      const res = await axiosInstance.get(`${baseUrl}/api/Hospital/GetAppointment`, {
        params: {
          Type: 'GetTodayAppointment_ById',
          DoctorId: userInfo.empId
        },
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true
      })

      if (res.status === 200 && res.data.length > 0) {
        setPatients(res.data);
      }

    } catch (error) {
      showToast('error', 'Error!', error.message || 'Internal Server Error')
    } finally {
      hideLoader()
    }
  }

  return (
    <div className="p-4">
      <div className="flex justify-between item-center">
        <div>
          <h1 className="text-2xl font-bold mb-4 text-blue-700">
            Today's Appointments
          </h1>
        </div>
        <div>
          <Button size={'sm'} onClick={fetchApt} className='bg-green-700 text-white rounded-xs hover:bg-green-800'>
            <RotateCcw /> Refresh
          </Button>
        </div>
      </div>
      {/* Legend / Action Guide */}
      <div className="flex justify-between items-center">
        <div className="flex flex-wrap gap-4 items-center text-sm mb-4">
          <div className="flex items-center gap-2"><span className="p-2 border border-blue-400 rounded bg-blue-200 text-blue-700"><Phone size={14} /></span>Call patient</div>
          <div className="flex items-center gap-2"><span className="p-2 rounded border border-orange-400 bg-orange-200 text-orange-600"><SquarePen size={14} /></span> Case Study</div>
          <div className="flex items-center gap-2"><span className="p-2 rounded border border-green-400 bg-green-200 text-green-600"><Check size={14} /></span>Mark as complete</div>
          <div className="flex items-center gap-2"><span className="p-2 rounded border border-purple-400 bg-purple-200 text-purple-600"><Undo2 size={14} /></span>Reschedule</div>
          <div className="flex items-center gap-2"><span className="p-2 rounded border border-blue-400 bg-blue-200 text-blue-600"><Stethoscope size={14} /></span>Mark Under Ovservation</div>
        </div>
        <div>
          <span className="font-bold text-sm text-blue-700">Auto Refresh In : {timer} Sec</span>
        </div>
      </div>
      <DataTable
        columns={columns}
        data={patients}
        pageSize={50}
        headerBgColor="bg-blue-800"
        headerTextColor="text-white"
      />
    </div>
  );
};

export default TodayAppointmentsPage;
