import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { DataTable } from '../../components/custom/DataTable';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from "@/components/ui/badge";
import { Pencil } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLoader } from '../../Context/LoaderProvider';
import useShowToast from '../../Context/useShowToast';
import axiosInstance from '../../Context/axiosInstance';


const UserMaster = () => {

    const navigate = useNavigate();
    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast();
    const [userList, setUserList] = useState([]);

    useEffect(() => {
        getUsersList();
    }, [])

    const getUsersList = async () => {
        try {
            showLoader()
            const token = localStorage.getItem("token");
            const res = await axiosInstance.get(`${import.meta.env.VITE_API_BASE_URL}/api/Master/GetUsersList`, {
                headers: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true
            })

           // const res = await api.get("/api/Master/GetUsersList");
            
            if (res.status == 200) {
                setUserList(res.data);
            }
            else {
                showToast("error", "Error!", 'Failed to Load')
            }
        } catch (error) {
            showToast("error", "Error!", error.message)
        } finally {
            hideLoader();
        }
    }

    const handleEdit = (empId) => {
        // Redirect or open modal, or set state with empId
        console.log("Editing user with Emp ID:", empId);
        navigate(`/hospital/registeruser/edit/${empId}`);
    };

    const userColumns = [
        {
            accessorKey: "action",
            header: "Action",
            enableColumnFilter: false,
            size: 100,
            cell: ({ row }) => {
                const empId = row.original.empId;
                return (
                    <button
                        onClick={() => handleEdit(empId)}
                        className="text-white p-2 rounded-full cursor-pointer bg-blue-500 hover:text-blue-500 hover:bg-white"
                    >
                        <Pencil size={18} />
                    </button>
                );
            }
        },
        {
            accessorKey: "empPhoto",
            header: "Profile",
            enableColumnFilter: false,
            size: 30,
            cell: ({ row }) => (
                <Avatar className="h-10 w-10 border-2 border-blue-500">
                    <AvatarImage src={row.original.empPhoto} alt={row.original.empName} />
                    <AvatarFallback>{row.original.name?.charAt(0)}</AvatarFallback>
                </Avatar>
            )
        },
        { accessorKey: "empId", header: "Emp ID", size: 50 },
        { accessorKey: "empName", header: "Name" },
        { accessorKey: "gender", header: "Gender", size: 100 },
        { accessorKey: "roleName", header: "Role", size: 100 },
        { accessorKey: "deptName", header: "Department" },
        { accessorKey: "mobNo", header: "Phone" },
        { accessorKey: "emailId", header: "Email" },
        { accessorKey: "dob", header: "DOB", size: 100 },
        { accessorKey: "doj", header: "DOJ", size: 100 },
        { accessorKey: "prmanentAddress", header: "Parmanent Address", size: 180 },
        { accessorKey: "presentAddress", header: "Present Address", size: 180 },
        { accessorKey: "expInYear", header: "Exp (Yrs)", size: 100 },
        { accessorKey: "qualification", header: "Qualification" },
        { accessorKey: "createdAt", header: "Created On" },
        {
            accessorKey: "isActive", header: "Statue",
            cell: ({ row }) => {
                const isActive = row.getValue("isActive");
                return (
                    <Badge
                        className={isActive ? "bg-green-500 text-white" : "bg-red-500 text-white"}
                    >
                        {isActive ? "Active" : "Inactive"}
                    </Badge>
                );
            },
        },

    ];

    return (
        <div className="p-1">
            <div className='flex justify-between items-center w-full'>
                <h2 className="text-xl font-semibold mb-4">User Management</h2>
                <Button onClick={() => navigate(`/hospital/registeruser`)} className="bg-blue-600 rounded text-xs 
                        h-8 w-20 cursor-pointer text-white hover:bg-blue-700">
                    Add User
                </Button>
            </div>
            <div className='mt-4'>
                <DataTable
                    columns={userColumns}
                    data={userList}
                    pageSize={100}
                    headerBgColor="bg-blue-800"
                    headerTextColor="text-white"
                />
            </div>
        </div>
    );
};

export default UserMaster;

