import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { User, Phone, MapPin, Save, Eye, EyeOff } from "lucide-react";
import axiosInstance from "../../Context/axiosInstance";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";

export default function UserProfile() {
    const [userData, setUserData] = useState({});
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [errors, setErrors] = useState({});

    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast();

    const token = localStorage.getItem("token");
    const userInfo = JSON.parse(localStorage.getItem("user"));

    useEffect(() => {
        if (userInfo?.empId) {
            getUserProfile();
        }
    }, [userInfo?.empId]);

    const getUserProfile = async () => {
        try {
            showLoader();
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetMasterById?Type=Get_EmployeeDetailsById&Id=${userInfo.empId}`;

            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
            });

            if (res.status === 200) {
                setUserData(res.data);
                setPassword(res.data.password || "");
            }
        } catch {
            showToast("error", "Error!", "Failed to load profile");
        } finally {
            hideLoader();
        }
    };

    const validatePassword = () => {
        const err = {};
        if (!password) {
            err.password = "Password is required";
        } else if (password.length < 4) {
            err.password = "Minimum 4 characters required";
        }
        setErrors(err);
        return Object.keys(err).length === 0;
    };

    const handlePasswordUpdate = async () => {
        if (!validatePassword()) return;

        try {
            showLoader();
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/UpdateUserPassword`;

            const payload = {
                empId: userData.empId,
                password: password,
            };

            const res = await axiosInstance.post(url, payload, {
                headers: { Authorization: `Bearer ${token}` },
                 withCredentials: true
            });

            if (res.status === 200 && res.data.msg_code === '1') {
                showToast("success", "Success!", "Password updated successfully");
            } else {
                showToast("error", "Error!", "Failed to update password");
            }
        } catch {
            showToast("error", "Error!", "Failed to update password");
        } finally {
            hideLoader();
        }
    };

    const ReadOnlyInput = ({ label, value }) => (
        <div className="space-y-2">
            <Label>{label}</Label>
            <Input value={value || ""} readOnly disabled className="bg-gray-200" />
        </div>
    );

    return (
        <div className="min-h-screen p-4">
            <div className="max-w-6xl mx-auto space-y-6">

                {/* Header */}
                <div className="text-center">
                    <h1 className="text-4xl font-bold">My Profile</h1>
                    <p className="text-gray-600">
                        Your profile details are read-only. Only password can be updated.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

                    {/* Profile Photo */}
                    <Card className="lg:col-span-1 !max-h-80">
                        <CardHeader className="text-center">
                            <CardTitle className="flex justify-center items-center gap-2">
                                <User /> Profile Photo
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="flex justify-center">
                            <div className="w-32 h-32 rounded-full overflow-hidden bg-gray-100 border">
                                {userData.empPhoto ? (
                                    <img
                                        src={userData.empPhoto}
                                        alt="Profile"
                                        className="w-full h-full object-cover"
                                    />
                                ) : (
                                    <div className="flex items-center justify-center h-full">
                                        <User className="text-gray-400 w-12 h-12" />
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Details */}
                    <div className="lg:col-span-3 space-y-6">

                        {/* Personal Info */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex gap-2">
                                    <User /> Personal Information
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <ReadOnlyInput label="Employee ID" value={userData.empId} />
                                <ReadOnlyInput label="Name" value={userData.empName} />
                                <ReadOnlyInput label="Gender" value={userData.gender} />
                                <ReadOnlyInput label="Date of Birth" value={userData.dob} />
                                <ReadOnlyInput label="Marital Status" value={userData.maritalStatus} />
                                <ReadOnlyInput label="Qualification" value={userData.qualification} />
                                <ReadOnlyInput label="Role" value={userData.roleName} />
                                <ReadOnlyInput label="Designation" value={userData.deptName} />
                                <ReadOnlyInput label="Date of joining" value={userData.doj} />
                            </CardContent>
                        </Card>

                        {/* Address */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex gap-2">
                                    <MapPin /> Present Address Information
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <ReadOnlyInput label="Street" value={userData.presentStreet} />
                                <ReadOnlyInput label="City" value={userData.presentCity} />
                                <ReadOnlyInput label="State" value={userData.presentState} />
                                <ReadOnlyInput label="ZIP" value={userData.presentZip} />
                                <ReadOnlyInput label="Country" value={userData.presentCountry} />
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex gap-2">
                                    <MapPin /> Parmanent Address Information
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <ReadOnlyInput label="Street" value={userData.parmaStreet} />
                                <ReadOnlyInput label="City" value={userData.parmaCity} />
                                <ReadOnlyInput label="State" value={userData.parmaState} />
                                <ReadOnlyInput label="ZIP" value={userData.parmaZip} />
                                <ReadOnlyInput label="Country" value={userData.parmaCountry} />
                            </CardContent>
                        </Card>

                        {/* Contact */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex gap-2">
                                    <Phone /> Contact Information
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <ReadOnlyInput label="Mobile" value={userData.mobNo} />
                                <ReadOnlyInput label="Email" value={userData.emailId} />
                            </CardContent>
                        </Card>

                        {/* Password Update */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Password Update</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <Label>New Password</Label>
                                <div className="relative">
                                    <Input
                                        type={showPassword ? "text" : "password"}
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="Enter new password"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                                    >
                                        {showPassword ? <EyeOff /> : <Eye />}
                                    </button>
                                </div>
                                {errors.password && (
                                    <p className="text-sm text-red-500">{errors.password}</p>
                                )}

                                <div className="flex justify-end">
                                    <Button
                                        onClick={handlePasswordUpdate}
                                        className="bg-green-600 hover:bg-green-700 text-white"
                                    >
                                        <Save className="w-4 h-4 mr-2" />
                                        Update Password
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                    </div>
                </div>
            </div>
        </div>
    );
}
