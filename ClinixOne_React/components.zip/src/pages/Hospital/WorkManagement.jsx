import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLoader } from "../../Context/LoaderProvider";
import { useNavigate } from "react-router-dom";
import useShowToast from "../../Context/useShowToast";
import axios from "axios";
import { useSelector } from "react-redux";
import SearchableDD from "../../components/custom/SearchableDD";

const WorkManagement = () => {
    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast()
    const navigate = useNavigate();
    const [searchName, setSearchName] = useState("");
    const [filterDept, setFilterDept] = useState("");
    const [staff, setStaff] = useState([]);
    const [dept, setDept] = useState([]);
    const { deptlist, deptloading } = useSelector((state) => state.departments)

    useEffect(() => {
        const getStaffList = async () => {
            try {
                showLoader();
                const token = localStorage.getItem("token");
                const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/Master/GetUsersList`, {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true
                });

                if (res.status === 200) {
                    setStaff(res.data);
                } else {
                    showToast("error", "Error!", "Failed to Load");
                }
            } catch (error) {
                showToast("error", "Error!", error.message);
            } finally {
                hideLoader();
            }
        };

        getStaffList();
    }, []);


    useEffect(() => {
        if (deptlist && Array.isArray(deptlist)) {
            const mappedDept = deptlist.map(dep => ({
                label: dep.deptName,
                value: dep.deptId.toString(),
            }));
            // Append "All" option at the top
            setDept([{ label: "All", value: "" }, ...mappedDept]);
        }
    }, [deptlist]);


    const filteredEmployees = staff.filter((emp) => {
        const matchesName = emp.empName.toLowerCase().includes(searchName.toLowerCase());
        const matchesDept = !filterDept || emp.deptId.toString() === filterDept;
        return matchesName && matchesDept;
    });


    return (
        <div className="p-4">
            {/* Filters */}
            <div className="flex flex-col sm:flex-row items-center justify-between w-full gap-4 mb-6">
                <div className="w-1/2 flex flex-col sm:flex-row items-center gap-2">
                    <div className="w-1/2">
                        {/* <Label>Filter by Department</Label> */}
                        <SearchableDD
                            options={dept}
                            value={filterDept}
                            onChange={(val) => setFilterDept(val)}
                            label="Filter By Dept"
                            placeholder="Select a Dept"
                            className="form-control"
                        />
                    </div>

                    <div className="w-1/2">
                        <Label>Search by Name</Label>
                        <Input
                            placeholder="Enter doctor name"
                            value={searchName}
                            className='bg-white mt-2 rounded form-control'
                            onChange={(e) => setSearchName(e.target.value)}
                        />
                    </div>
                </div>
                <div className="w-1/2 w-full sm:w-auto mt-4 sm:mt-6">
                    <Button className="bg-green-600 rounded text-sm h-8">Schedule Events</Button>
                </div>
            </div>

            {/* Employee Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                {filteredEmployees.map((emp) => (
                    <Card key={emp.empId} className="shadow-md">
                        <CardContent className="p-4 flex flex-col items-center text-center">
                            <img
                                src={emp.empPhoto || '/Images/DefaultProfile.jpg'}
                                alt={emp.empName}
                                className="w-24 h-24 rounded-full mb-4 object-cover"
                            />
                            <div className="text-lg font-semibold">{emp.empName}</div>
                            <div className="text-sm text-gray-500 mb-4">{emp.deptName}</div>
                            <div className="text-sm text-gray-500 mb-4 hidden">{emp.deptId}</div>
                            <div className="flex gap-2">
                                <Button className='bg-blue-600 rounded text-xs h-8' onClick={() => navigate(`/hospital/scheulework/${emp.empId}`)}>Manage Shift</Button>
                                <Button className='bg-gray-600 rounded text-xs h-8'>View Profile</Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
};

export default WorkManagement;
