import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useNavigate } from "react-router-dom";
import useShowToast from "../../Context/useShowToast";
import { useDispatch } from "react-redux";
import { setAuth } from "../../Redux/slices/authSlice";
import axios from "axios";
import { Loader2Icon } from "lucide-react";

const HospitalPortal = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const showToast = useShowToast();
    const [loading, setLoading] = useState(false)
    const [rememberMe, setRememberMe] = useState(false)
    const userCredentials = JSON.parse(localStorage.getItem("hospitalAuth"));

    useEffect(() => {
        if (userCredentials) {
            setRememberMe(true);
        }
    }, [])

    const [formData, setFormData] = useState({
        loginId: userCredentials?.loginId,
        password: userCredentials?.password,
        type: "HospitalUser"
    });

    const [errors, setErrors] = useState({
        loginId: "",
        password: ""
    });

    const handleChange = (e) => {
        setFormData(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (!formData.loginId || !formData.password) {
                setErrors({
                    loginId: !formData.loginId ? "LoginId is required" : "",
                    password: !formData.password ? "Password is required" : ""
                });
                return;
            }
            setLoading(true)
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Account/Login`
            const response = await axios.post(url, formData);
            console.log(response)
            if (response.status === 200 && response.data) {

                if (rememberMe) {
                    localStorage.setItem("hospitalAuth", JSON.stringify({
                        loginId: formData.loginId,
                        password: formData.password
                    }));
                } else {
                    sessionStorage.setItem("hospitalAuth", JSON.stringify({
                        loginId: formData.loginId,
                        password: formData.password
                    }));
                }

                dispatch(setAuth({
                    token: response.data.token,
                    user: response.data.user,
                }));
                navigate('/hospital/Dashboard');
            }
            else {
                showToast("error", "Error!", "Failed to Authenticate")
            }
        } catch (error) {
            if (error.response) {
                const { status, data } = error.response;

                if (status === 401) {
                    const error_code = data.error_code;
                    if (error_code === '002') {
                        showToast("error", "Unknown", "LoginId or Password is incorrect");
                    } else {
                        showToast("error", "In Active", "User is Inactive. Please contact admin");
                    }
                } else {
                    showToast("error", "Error!", "Failed to Authenticate");
                }
            } else {
                showToast("error", "Network Error", "Please check your internet connection or server.");
            }
        } finally {
            setLoading(false)
        }

    };

    return (
        <div className="min-h-screen flex items-center justify-between w-full px-4">
            <div className="w-full flex justify-between overflow-hidden md:flex-row flex-col p-4 gap-4">

                {/* Left Panel: Doctor Image + Slogan */}
                <div className="w-3/5 text-blue-800 p-10 flex flex-col justify-center items-center">
                    <img src="Images/Dentist.png" alt="Doctor" className="w-64 h-auto mb-6" />
                    <h1 className="text-3xl font-bold text-center mb-2">We care about your health</h1>
                    <p className="text-sm font-bold text-green-700 text-center max-w-xs">
                        Providing secure access for doctors, patients, and healthcare staff — 24/7.
                    </p>
                </div>
                {/* Right Panel: Login Form */}
                <div className="w-2/5 rounded-2xl shadow-md bg-gradient-to-r from-blue-200 to-blue-400 p-10 flex flex-col justify-center">
                    <h2 className="text-2xl font-semibold text-gray-700 mb-6 text-center">Login to Hospital Portal</h2>

                    <form onSubmit={handleSubmit} className="ui form space-y-4">
                        <div>
                            <Label htmlFor="UserName" className="mb-1 block">
                                Email Address
                            </Label>
                            <div className="relative">

                                <Input
                                    id="userName"
                                    name="loginId"
                                    placeholder="you@example.com"
                                    value={formData.loginId}
                                    className="bg-white"
                                    onChange={handleChange}
                                />
                                <span className="absolute left-3 top-2.5 text-gray-400">
                                    <i className="envelope icon" />
                                </span>
                            </div>
                            {errors.loginId && (
                                <p className="text-red-500 text-sm mt-1">{errors.loginId}</p>
                            )}
                        </div>

                        <div>
                            <Label htmlFor="password" className="mb-1 block">
                                Password
                            </Label>
                            <div className="relative">
                                <Input
                                    id="password"
                                    name="password"
                                    type="password"
                                    placeholder="Enter password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    className="bg-white"
                                />
                                <span className="absolute left-3 top-2.5 text-gray-400">
                                    <i className="lock icon" />
                                </span>
                            </div>
                            {errors.password && (
                                <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                            )}
                        </div>

                        <div className="flex justify-between text-sm text-gray-500 items-center">
                            <label className="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    checked={rememberMe}
                                    onChange={(e) => setRememberMe(e.target.checked)}
                                />
                                <span>Remember me</span>
                            </label>
                            <a href="#" className="text-white font-bold hover:underline">
                                Forgot password?
                            </a>
                        </div>

                        <Button
                            type="submit"
                            id="Hospitallogin"
                            className="cursor-pointer bg-blue-900 text-white font-semibold py-2 px-6 rounded-lg w-full hover:bg-blue-800 transition duration-300 mt-4"
                        >
                            {loading ? (
                                <>
                                    <Loader2Icon className="animate-spin mr-2 inline-block" />
                                    Please Wait
                                </>
                            ) : (
                                "Login"
                            )}
                        </Button>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default HospitalPortal
