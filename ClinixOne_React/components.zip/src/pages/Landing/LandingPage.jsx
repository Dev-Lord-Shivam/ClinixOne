import { Button } from "@/components/ui/button";
import { useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

const services = [
  {
    icon: "huge blue hospital icon",
    title: "Patient Management",
    description: "Easily register, track, and manage patient data in real time.",
  },
  {
    icon: "huge green calendar check icon",
    title: "Appointments",
    description: "Schedule appointments with doctors and send timely reminders.",
  },
  {
    icon: "huge yellow file invoice dollar icon",
    title: "Billing & Reports",
    description: "Generate invoices and access detailed billing and medical reports.",
  },
  {
    icon: "medkit huge red icon",
    title: "Top Specialist",
    description: "You can reach out to 100+ specialists who have years of experience.",
  },
];

const specialities = [
  "Allergy", "Dentist", "Dermatologist", "Hiv", "Neurologist", "Urology",
  "Cardiologist", "Orthopedic", "Pediatrician", "Ophthalmologist",
  "ENT", "Gynecologist", "Physiotherapist", "Psychiatrist", "Oncologist",
  "Pathologist", "Nephrologist", "GeneralPhysician"
];

export default function LandingPage() {

  return (
    <div>
      {/* Hero Section */}
      <section className="relative" id="home">
        <div className="container mx-auto px-6 flex flex-col-reverse md:flex-row items-center justify-between">
          <div className="md:w-1/2 text-left">
            <h1 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
              Your Health is <br /> Our Upmost{" "}
              <span className="border-b-4 border-indigo-800">Priority</span>
            </h1>
            <p className="text-gray-700 text-lg mb-6 mt-6">
              Experience seamless healthcare with MediSphare's <br />
              advanced hospital management platform.
            </p>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              Book Appointment
            </Button>
          </div>
          <div className="md:w-1/2 mb-10 md:mb-0">
            <img
              src="Images/doctors.png"
              alt="Doctors"
              className="w-full max-w-md mx-auto"
            />
          </div>
        </div>

        <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none">
          <svg
            className="relative block w-full h-16"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 1440 100"
            preserveAspectRatio="none"
          >
            <path
              fill="#2185d0"
              d="M0,0 C480,100 960,0 1440,100 L1440,100 L0,100 Z"
            ></path>
          </svg>
        </div>
      </section>

      {/* Services Section */}
      <section className="container mx-auto px-6 py-16" id="services">
        <h2 className="text-3xl font-bold text-center text-blue-900 mb-10">
          Why you should trust us? <br />
          Get to know about us
        </h2>
        <div className="grid md:grid-cols-4 gap-8 text-center">
          {services.map((service, idx) => (
            <div key={idx} className="p-6 bg-white rounded-lg shadow">
              <i className={`${service.icon} mb-4`}></i>
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Specialities Section */}
      <section className="container mx-auto px-6 pb-16" id="Specialities">
        <h2 className="text-3xl font-bold text-center text-blue-900 mb-2">
          Our Consulting Specialities
        </h2>
        <p className="text-center font-medium text-gray-700 mb-10">
          Our Medical panel consists of over 100+ doctors and 80+ specialities
        </p>
        <Swiper
          modules={[Autoplay, Navigation]}
          spaceBetween={30}
          loop={true}
          autoplay={{
            delay: 1500,
            disableOnInteraction: false,
          }}
          breakpoints={{
            320: { slidesPerView: 1 },
            640: { slidesPerView: 2 },
            768: { slidesPerView: 3 },
            1024: { slidesPerView: 4 },
            1280: { slidesPerView: 6 },
          }}
        >
          {specialities.map((title, idx) => (
            <SwiperSlide key={idx}>
              <div className="p-6 bg-white rounded-lg shadow text-center">
                <img
                  src={`/Images/${title}.png`}
                  alt={title}
                  className="mx-auto h-24 w-auto"
                />
                <h3 className="text-lg font-semibold mt-4">{title}</h3>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

      </section>
    </div>
  );
}
