import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import { Loader2Icon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import useShowToast from "../../Context/useShowToast";
import axios from "axios";
import { setPatientAuth } from "../../Redux/slices/authPatientSlice";
import { useDispatch } from "react-redux";

const PatientPortal = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false)
    const showToast = useShowToast()
    const [rememberMe, setRememberMe] = useState(false)
    const userCredentials = JSON.parse(localStorage.getItem("patientAuth")); 

    useEffect(() => {
        if(userCredentials){
           setRememberMe(true);
        }
    },[])

    const [formData, setFormData] = useState({
        loginId: userCredentials?.loginId,
        password: userCredentials?.password,
        type: "Patients"
    });

    const [errors, setErrors] = useState({
        loginId: "",
        password: "",
    });

    const handleChange = (e) => {
        setFormData(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (!formData.loginId || !formData.password) {
                setErrors({
                    loginId: !formData.loginId ? "Username is required" : "",
                    password: !formData.password ? "Password is required" : ""
                });
                return;
            }
            setLoading(true)
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Account/PatientLogin`
            const response = await axios.post(url, formData);

            if (response.status === 200 && response.data) {
                const { token, user } = response.data;

                // save token depending on rememberMe
                if (rememberMe) {
                    localStorage.setItem("patientAuth", JSON.stringify({ 
                        loginId: formData.loginId,
                        password: formData.password
                     }));
                } else {
                    sessionStorage.setItem("patientAuth", JSON.stringify({ 
                        loginId: formData.loginId,
                        password: formData.password
                    }));
                }

                dispatch(setPatientAuth({
                    patienttoken: token,
                    patient: user,
                }));

                navigate('/patient/Dashboard');
            } else {
                showToast("error", "Error!", "Failed to Authenticate")
            }
        } catch (error) {
            if (error.response) {
                const { status, data } = error.response;

                if (status === 401) {
                    const error_code = data.error_code;
                    if (error_code === '002') {
                        showToast("error", "Unknown", "LoginId or Password is incorrect");
                    } else {
                        showToast("error", "In Active", "User is Inactive. Please contact admin");
                    }
                } else {
                    showToast("error", "Error!", "Failed to Authenticate");
                }
            } else {
                showToast("error", "Network Error", "Please check your internet connection or server.");
            }
        } finally {
            setLoading(false)
        }
    };

    return (
        <div className='min-h-screen flex items-center justify-center px-4'>
            <div className='shadow-2xl rounded-2xl overflow-hidden w-full max-w-4xl flex flex-col md:flex-row'>
                {/* Left side */}
                <div className="md:w-1/2 p-10 flex flex-col justify-center bg-blue-900 text-white">
                    <h3 className="text-3xl font-bold mb-4">Welcome to ClinixOne</h3>
                    <p className="text-blue-100">Access your appointments, reports, and medical records securely.</p>
                    <img
                        src="Images/GeneralPhysician.png"
                        alt="Doctors"
                        className="mt-6 w-3/5 mx-auto hidden md:block"
                    />
                </div>

                {/* Right side */}
                <div className="md:w-1/2 p-10 bg-white">
                    <h3 className="text-2xl font-semibold text-blue-900 mb-6 text-center">Patient Portal Login</h3>

                    <form onSubmit={handleSubmit} className="space-y-6 max-w-md mx-auto">
                        {/* Login ID */}
                        <div>
                            <Label htmlFor="loginId" className="mb-1 block">
                                Email Address Or PatientId
                            </Label>
                            <Input
                                id="loginId"
                                name="loginId"
                                placeholder="you@example.com"
                                value={formData.loginId}
                                onChange={handleChange}
                            />
                            {errors.loginId && (
                                <p className="text-red-500 text-sm mt-1">{errors.loginId}</p>
                            )}
                        </div>

                        {/* Password */}
                        <div>
                            <Label htmlFor="password" className="mb-1 block">
                                Password
                            </Label>
                            <Input
                                id="password"
                                name="password"
                                type="password"
                                placeholder="Enter password"
                                value={formData.password}
                                onChange={handleChange}
                            />
                            {errors.password && (
                                <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                            )}
                        </div>

                        {/* Remember Me */}
                        <div className="flex items-center justify-between">
                            <label className="flex items-center space-x-2 text-sm">
                                <input
                                    type="checkbox"
                                    checked={rememberMe}
                                    onChange={(e) => setRememberMe(e.target.checked)}
                                />
                                <span>Remember Me</span>
                            </label>
                            <a href="#" className="text-blue-800 hover:underline text-sm">
                                Forgot Password?
                            </a>
                        </div>

                        {/* Submit */}
                        <Button
                            type="submit"
                            className="w-full bg-blue-900 hover:bg-blue-800 text-white"
                        >
                            {loading ? (
                                <>
                                    <Loader2Icon className="animate-spin mr-2 inline-block" />
                                    Please Wait
                                </>
                            ) : (
                                <>
                                    <i className="sign-in icon mr-2" />
                                    Login
                                </>
                            )}
                        </Button>

                        {/* Register */}
                        <div className="text-center text-sm text-gray-600">
                            <a href="#" onClick={() => navigate('/RegisterPatient')} className="text-blue-800 hover:underline">
                                New Patient? Register here
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default PatientPortal;
