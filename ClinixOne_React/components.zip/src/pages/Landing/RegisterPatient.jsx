import { useState, useRef, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogOverlay } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Upload, X, MapPin, Phone, Shield, AlertCircle, User, Calendar, Droplets, IdCard, LogIn } from "lucide-react";
import CustomDatePicker from "../../components/custom/CustomDatePicker";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import axiosInstance from "../../Context/axiosInstance";
import { useCustomAlert } from "../../Context/CustomAlertProvider";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useNavigate } from "react-router-dom";

const genderOptions = ["Male", "Female", "Other", "Prefer not to say"];
const maritalStatusOptions = ["Single", "Married", "Divorced", "Widowed", "Separated"];
const bloodGroupOptions = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const religionOptions = [
  "Christianity", "Islam", "Hinduism", "Buddhism", "Judaism", "Sikhism",
  "Jainism", "Zoroastrianism", "Bahá'í Faith", "Atheism", "Agnosticism", "Other"
];
const SearchableSelect = ({ options, value, onValueChange, placeholder, className }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const filteredOptions = options.filter(option =>
    (typeof option === 'string' ? option : option.label)
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  return (
    <div className="relative">
      <Select value={value} onValueChange={onValueChange} open={isOpen} onOpenChange={setIsOpen}>
        <SelectTrigger className={className}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          <div className="p-2">
            <Input
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-8"
            />
          </div>
          <div className="max-h-60 overflow-auto">
            {filteredOptions.map((option) => {
              const optionValue = typeof option === 'string' ? option : option.value;
              const optionLabel = typeof option === 'string' ? option : option.label;
              return (
                <SelectItem key={optionValue} value={optionValue}>
                  {optionLabel}
                </SelectItem>
              );
            })}
            {filteredOptions.length === 0 && (
              <div className="p-2 text-sm text-gray-500 text-center">No results found</div>
            )}
          </div>
        </SelectContent>
      </Select>
    </div>
  );
};

export default function PatientRegistration() {
  const [formData, setFormData] = useState({
    Nationality: "Indian"
  });

  const [patientData, setPatientData] = useState({});
  const [showOtpDialog, setShowOtpDialog] = useState(false);
  const [showPatientDialog, setShowPatientDialog] = useState(false);
  const [isBouncing, setIsBouncing] = useState(false);
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [errors, setErrors] = useState({});
  const otpRefs = [useRef(), useRef(), useRef(), useRef()];
  const { showLoader, hideLoader } = useLoader()
  const showToast = useShowToast();
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const alert = useCustomAlert()
  const navigate = useNavigate();

  useEffect(() => {
    getCountryStateCity('Get_CountryDD');
  }, [])

  const getCountryStateCity = async (Type, countryId = null, stateId = null) => {
    console.log('inside')
    try {
      showLoader();
      let url = '';

      if (Type === 'Get_CountryDD') {
        url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=Get_CountryDD`;
        const res = await axiosInstance.get(url);
        if (res.status === 200 && res.data) {
          setCountryList(res.data.map(item => ({
            label: item.text,
            value: item.value.toString()
          })));
        }
      }

      if (Type === 'Get_StateDDById') {
        url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=${Type}&Id=${countryId}`;
        const res = await axiosInstance.get(url);
        if (res.status === 200 && res.data) {
          setStateList(res.data.map(item => ({
            label: item.text,
            value: item.value.toString()
          })));
        }
      }

      if (Type === 'Get_CityByStateId') {
        url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=${Type}&Id=${stateId}&Id2=${countryId}`;
        const res = await axiosInstance.get(url);
        if (res.status === 200 && res.data) {
          setCityList(res.data.map(item => ({
            label: item.text,
            value: item.value.toString()
          })));
        }
      }

    } catch (error) {
      console.error("API error:", error);
    } finally {
      hideLoader();
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert({ title: 'alert', description: "File size must be less than 5MB" });
        return;
      }

      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert({ title: 'alert', description: "Please select a valid image file" });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({
          ...prev,
          ProfilePic: reader.result, // base64 in form
          ProfilePicUrl: URL.createObjectURL(file),
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const requiredFields = [
      'FullName', 'Gender', 'DOB', 'MaritalStatus', 'Religion', 'BloodGroup',
      'Street', 'CountryId', 'StateId', 'City', 'Pincode', 'MobNumber', 'Email'
    ];

    requiredFields.forEach(field => {
      if (!formData[field]) {
        newErrors[field] = 'This field is required';
      }
    });

    // Email validation
    if (formData.Email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.Email)) {
      newErrors.Email = 'Please enter a valid email address';
    }

    // Mobile number validation
    if (formData.MobNumber && !/^\d{10}$/.test(formData.MobNumber)) {
      newErrors.MobNumber = 'Please enter a valid 10-digit mobile number';
    }

    // Pincode validation
    if (formData.Pincode && !/^\d{6}$/.test(formData.Pincode)) {
      newErrors.Pincode = 'Please enter a valid 6-digit pincode';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {

    if (!validateForm()) {
      // Scroll to first error
      const firstError = document.querySelector('.border-red-500');
      if (firstError) {
        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    try {
      showLoader();
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/RegisterPatient`
      const response = await axiosInstance.post(url, formData);
      console.log(response)
      if (response.status == 200) {
        if (response.data.patientId) {
          setPatientData({
            name: formData.FullName,
            id: response.data.patientId,
            bloodGroup: formData.BloodGroup,
            dob: formData.DOB,
            photo: formData.ProfilePic,
            password: formData.DOB.replaceAll("/", '')
          });

          window.scrollTo({ top: 0, behavior: "smooth" });
          setTimeout(() => setShowPatientDialog(true), 800);

          // Reset form properly
          setFormData({
            Nationality: "Indian",
            FullName: "",
            BloodGroup: "",
            DOB: "",
            ProfilePic: null,
            ProfilePicUrl: null,
            MaritalStatus: null,
            CountryId: null,
            StateId: null,
            City: '',
            Street: '',
            Gender: ''
          });

          showToast("success", "Success!", "Patient Registered successfully.")
        }
        else {
          if (response.data.msg_code == "3") {
            showToast("error", "Error!", `${response.data.message}`)
          }
        }
      }

    } catch (error) {
      showToast("error", "Error!", "Server Error")
    } finally {
      hideLoader()
    }
  };

  const handleOtpChange = (index, value) => {
    if (!/^[0-9]?$/.test(value)) return;
    const updatedOtp = [...otp];
    updatedOtp[index] = value;
    setOtp(updatedOtp);

    if (value && index < 3) {
      otpRefs[index + 1].current?.focus();
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs[index - 1].current?.focus();
    }
  };

  const handleVerifyOtp = () => {
    const fullOtp = otp.join("");
    if (fullOtp.length === 4) {
      setShowOtpDialog(false);
      alert("OTP Verified! Registration Complete.");
      console.log("Form Data Submitted:", formData);
    } else {
      alert("Enter all 4 digits of the OTP.");
    }
  };

  const handleResendOtp = () => {
    alert("OTP resent!");
    setOtp(["", "", "", ""]);
    otpRefs[0].current?.focus();
  };

  const removeProfilePic = () => {
    if (formData.ProfilePicUrl) {
      URL.revokeObjectURL(formData.ProfilePicUrl);
    }
    setFormData(prev => ({
      ...prev,
      ProfilePic: null,
      ProfilePicUrl: null
    }));
  };

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Patient Registration</h1>
          <p className="text-gray-600">Please fill in all required information to complete your registration</p>
        </div>

        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Profile Picture Section */}
            <div className="lg:col-span-1">
              <Card className="h-fit">
                <CardHeader className="text-center pb-4">
                  <CardTitle className="flex items-center justify-center gap-2 text-lg">
                    <User className="w-5 h-5" />
                    Profile Photo
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <div className="relative group">
                    <div className="w-32 h-32 mx-auto rounded-full border-4 border-gray-200 overflow-hidden bg-gray-100">
                      {formData.ProfilePicUrl ? (
                        <>
                          <img
                            src={formData.ProfilePicUrl}
                            alt="Profile"
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={removeProfilePic}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </>
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <User className="w-12 h-12 text-gray-400" />
                        </div>
                      )}
                    </div>
                  </div>

                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                    id="profileImage"
                  />

                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById("profileImage").click()}
                    className="w-full"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Photo
                  </Button>

                  <p className="text-xs text-gray-500">
                    Max size: 5MB. Supported formats: JPG, PNG, GIF
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Form Fields */}
            <div className="lg:col-span-3 space-y-6">
              {/* Personal Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Full Name <span className="text-red-500">*</span></Label>
                      <Input
                        value={formData.FullName || ""}
                        onChange={(e) => handleChange("FullName", e.target.value)}
                        className={errors.FullName ? "border-red-500 form-control" : "form-control"}
                        placeholder="Enter your full name"
                      />
                      {errors.FullName && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.FullName}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Gender <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={genderOptions}
                        value={formData.Gender || ""}
                        onValueChange={(val) => handleChange("Gender", val)}
                        placeholder="Select gender"
                        className={errors.Gender ? "border-red-500 w-full form-control" : "w-full form-control"}
                      />
                      {errors.Gender && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.Gender}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Date of Birth <span className="text-red-500">*</span></Label>
                      <CustomDatePicker
                        selected={formData.DOB}
                        className='form-control'
                        onChange={(date) => handleChange("DOB", date)}
                        disableFuture={true} // disables dates after today
                      />
                      {errors.DOB && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.DOB}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Nationality</Label>
                      <Input
                        value={formData.Nationality || ""}
                        onChange={(e) => handleChange("Nationality", e.target.value)}
                        placeholder="Enter nationality"
                        className='form-control'
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Marital Status <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={maritalStatusOptions}
                        value={formData.MaritalStatus || ""}
                        onValueChange={(val) => handleChange("MaritalStatus", val)}
                        placeholder="Select marital status"
                        className={errors.MaritalStatus ? "border-red-500 form-control" : "form-control w-full"}
                      />
                      {errors.MaritalStatus && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.MaritalStatus}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Religion <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={religionOptions}
                        value={formData.Religion || ""}
                        onValueChange={(val) => handleChange("Religion", val)}
                        placeholder="Select religion"
                        className={errors.Religion ? "border-red-500 form-control" : "form-control w-full"}
                      />
                      {errors.Religion && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.Religion}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Occupation</Label>
                      <Input
                        value={formData.Occupation || ""}
                        onChange={(e) => handleChange("Occupation", e.target.value)}
                        placeholder="Enter occupation"
                        className='form-control'
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Blood Group <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={bloodGroupOptions}
                        value={formData.BloodGroup || ""}
                        onValueChange={(val) => handleChange("BloodGroup", val)}
                        placeholder="Select blood group"
                        className={errors.BloodGroup ? "border-red-500 form-control" : "form-control w-full"}
                      />
                      {errors.BloodGroup && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.BloodGroup}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Address Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    Address Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    <div className="md:col-span-2 xl:col-span-3 space-y-2">
                      <Label>Street Address <span className="text-red-500">*</span></Label>
                      <Input
                        value={formData.Street || ""}
                        onChange={(e) => handleChange("Street", e.target.value)}
                        className={errors.Street ? "border-red-500 form-control" : "form-control"}
                        placeholder="Enter complete street address"
                      />
                      {errors.Street && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.Street}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Country <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={countryList}
                        value={formData.CountryId || ""}
                        onValueChange={(val) => {
                          handleChange("CountryId", val);
                          handleChange("StateId", "");
                          getCountryStateCity('Get_StateDDById', val)
                        }}
                        placeholder="Select country"
                        className={errors.CountryId ? "border-red-500 form-control" : "w-full form-control"}
                      />
                      {errors.CountryId && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.CountryId}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>State/Province <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={stateList}
                        value={formData.StateId || ""}
                        onValueChange={(val) => {
                          handleChange("StateId", val)
                          getCountryStateCity('Get_CityByStateId', formData.CountryId, val)
                        }}
                        placeholder="Select state"
                        className={errors.StateId ? "border-red-500 form-control" : "form-control w-full"}
                      />
                      {errors.StateId && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.StateId}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>City/Town <span className="text-red-500">*</span></Label>
                      <SearchableSelect
                        options={cityList}
                        value={formData.City || ""}
                        onValueChange={(val) => {
                          handleChange("City", val)
                        }}
                        placeholder="Select city/town"
                        className={errors.StateId ? "border-red-500 form-control" : "form-control w-full"}
                      />
                      {errors.City && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.City}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Pincode/ZIP <span className="text-red-500">*</span></Label>
                      <Input
                        value={formData.Pincode || ""}
                        onChange={(e) => handleChange("Pincode", e.target.value)}
                        className={errors.Pincode ? "border-red-500 form-control" : "form-control"}
                        placeholder="Enter pincode"
                      />
                      {errors.Pincode && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.Pincode}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Mobile Number <span className="text-red-500">*</span></Label>
                      <Input
                        type="tel"
                        value={formData.MobNumber || ""}
                        onChange={(e) => handleChange("MobNumber", e.target.value)}
                        className={errors.MobNumber ? "border-red-500 form-control" : "form-control"}
                        placeholder="Enter 10-digit mobile number"
                        maxLength={10}
                      />
                      {errors.MobNumber && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.MobNumber}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Email Address <span className="text-red-500">*</span></Label>
                      <Input
                        type="email"
                        value={formData.Email || ""}
                        onChange={(e) => handleChange("Email", e.target.value)}
                        className={errors.Email ? "border-red-500 form-control" : "form-control"}
                        placeholder="Enter email address"
                      />
                      {errors.Email && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.Email}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Submit Button */}
              <div className="flex justify-end pt-6">
                <Button
                  type="button"
                  size="lg"
                  onClick={handleSubmit}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-12"
                >

                  <Shield className="w-4 h-4 mr-2" />
                  Register Patient
                </Button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Registration Successfull model */}

      <Dialog open={showPatientDialog} onOpenChange={setShowPatientDialog}>
        <DialogOverlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center" />
        <DialogContent
          className={`w-full max-w-4xl !max-w-4xl max-h-[90vh] rounded-2xl shadow-xl bg-white transition-transform duration-300 ${isBouncing ? "scale-105" : "scale-100"
            }`}
          onInteractOutside={(e) => {
            e.preventDefault();
            setIsBouncing(true);
            setTimeout(() => setIsBouncing(false), 200);
          }}
          onEscapeKeyDown={(e) => e.preventDefault()}
        >
          <DialogHeader className="text-center">
            <DialogTitle className="text-xl text-center">
              Patient registered successfully
            </DialogTitle>
            <DialogDescription className="text-gray-600">
              Please refer the below instructions
            </DialogDescription>
          </DialogHeader>

          {/* Remove min-h-screen and use responsive spacing */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-2 rounded-md">
            <div className="w-full space-y-6 grid grid-cols-2 gap-2">
              {/* Patient ID Card */}
              <div className="bg-white shadow-lg border rounded-lg">
                {/* Card Header with Hospital Branding */}
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white rounded-t-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-semibold text-sm">MEDICAL CENTER</span>
                  </div>
                  <h3 className="text-lg font-bold">Patient ID Card</h3>
                </div>

                <div className="p-4 space-y-2">
                  {/* Patient Photo */}
                  <div className="flex justify-center">
                    {/* <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-blue-100"> */}
                    <Avatar className="h-25 w-25 border-2 border-white">
                      {patientData.photo ? (
                        <AvatarImage src={patientData.photo} />
                      ) : (
                        <AvatarFallback className="bg-green-700 text-white text-xl">
                          {patientData?.name ? patientData.name.charAt(0) : ""}
                        </AvatarFallback>
                      )}
                    </Avatar>
                  </div>

                  {/* Patient Information */}
                  <div className="space-y-3 grid grid-cols-2 gap-2">
                    <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                      <div>
                        <span className="text-xs text-gray-500 font-medium">PATIENT ID</span>
                        <p className="font-bold text-gray-900">{patientData?.id}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                      <User className="w-4 h-4 text-blue-600" />
                      <div>
                        <span className="text-xs text-gray-500 font-medium">PATIENT NAME</span>
                        <p className="font-bold text-gray-900">{patientData?.name}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <div>
                        <span className="text-xs text-gray-500 font-medium">DATE OF BIRTH</span>
                        <p className="font-bold text-gray-900">{patientData?.dob}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                      <Droplets className="w-4 h-4 text-red-500" />
                      <div>
                        <span className="text-xs text-gray-500 font-medium">BLOOD GROUP</span>
                        <p className="font-bold text-gray-900">{patientData?.bloodGroup}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Login Credentials Message */}
              <div className="flex gap-2 flex-col">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <LogIn className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div className="text-blue-800">
                      <div className="space-y-1">
                        <p className="font-semibold">Login Credentials:</p>
                        <p><strong>Username:</strong> {patientData.id} (Your Patient ID)</p>
                        <p><strong>Default Password:</strong> {patientData.password}</p>
                        <p className="text-sm text-blue-600 mt-2">
                          Please change your password after first login for security.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Navigate to Login Button */}
                <button
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 py-2 px-3 rounded-lg text-white font-semibold shadow-lg transform hover:cursor-pointer flex items-center justify-center gap-2"
                  onClick={() => navigate('/patientportal')}
                >
                  Go to Login Page
                </button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* OTP Verification Modal */}
      <Dialog open={showOtpDialog} onOpenChange={setShowOtpDialog}>
        <DialogOverlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50" />
        <DialogContent
          className={`max-w-md transition-transform duration-300 ${isBouncing ? "scale-105" : "scale-100"
            }`}
          onInteractOutside={(e) => {
            e.preventDefault();
            setIsBouncing(true);
            setTimeout(() => setIsBouncing(false), 200);
          }}
          onEscapeKeyDown={(e) => e.preventDefault()}
        >
          <DialogHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <DialogTitle className="text-xl">Verify Your Identity</DialogTitle>
            <DialogDescription className="text-gray-600">
              We've sent a 4-digit verification code to your registered mobile number and email address.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="flex gap-3 justify-center">
              {otp.map((digit, index) => (
                <Input
                  key={index}
                  ref={otpRefs[index]}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, index)}
                  className="w-14 h-14 text-center text-2xl font-semibold border-2 rounded-lg focus:border-blue-500"
                />
              ))}
            </div>

            <div className="flex justify-between items-center gap-3">
              <Button
                type="button"
                variant="ghost"
                onClick={handleResendOtp}
                className="text-blue-600 hover:text-blue-700"
              >
                Resend Code
              </Button>
              <Button
                onClick={handleVerifyOtp}
                className="bg-green-600 hover:bg-green-700 text-white px-8"
              >
                Verify & Complete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>

  );
}