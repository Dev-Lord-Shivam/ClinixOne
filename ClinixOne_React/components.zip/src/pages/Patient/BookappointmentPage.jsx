import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Search, User } from 'lucide-react';
import { useSelector } from "react-redux";
import { Calendar } from "@/components/ui/calendar";
import SearchableDD from "../../components/custom/SearchableDD";
import { useLoader } from '../../Context/LoaderProvider';
import axiosInstance from '../../Context/axiosInstance';
import useShowToast from '../../Context/useShowToast';
import DefaultProfilePic from '/Images/DefaultProfile.jpg';
import BookingDrawer from '../../components/custom/BookingDrawer';

// Doctor card component
const DoctorCard = React.memo(({ doctor, onBookClick }) => {
  return (
    <div className="bg-green-100 rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="flex items-start space-x-4 mb-4">
        <img
          src={doctor.image || DefaultProfilePic}
          alt={doctor.name}
          className="w-24 h-24 rounded-sm object-cover flex-shrink-0"
        />
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 mb-1">{doctor.name}</h3>
          <div className="flex items-center text-sm text-gray-600 mb-1">
            <User className="w-4 h-4 mr-1" />
            {doctor.deptName}
          </div>
          <div className="mt-1">
            {doctor.available === 'Available' ? (
              <span className="px-2 py-1 rounded text-xs font-medium bg-blue-600 text-white">
                Available
              </span>
            ) : (
              <span className="px-2 py-1 rounded text-xs font-medium bg-red-600 text-white">
                Slot Full
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="flex space-x-2">
        <button
          disabled={doctor.available !== 'Available' ? true : false}
          className={`flex-1 text-sm px-4 py-2 rounded-sm font-medium transition-colors cursor-pointer
            ${doctor.available !== 'Available' ? 'bg-gray-300 text-gray-400' : 'bg-green-600 text-white hover:bg-green-700'}`}
          onClick={() => onBookClick(doctor)}
        >
          Book Now
        </button>
      </div>
    </div>
  );
});

DoctorCard.displayName = 'DoctorCard';

// Main component
export default function BookappointmentPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const { deptlist } = useSelector((state) => state.departments);
  const [dept, setDept] = useState([]);
  const [filteredDept, setFilteredDept] = useState('');
  const [doctors, setDoctors] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const { showLoader, hideLoader } = useLoader();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const showToast = useShowToast();

  // Format date to yyyy-mm-dd
  const formatDate = useCallback((date) => {
    if (!date) return '';
    return date.toLocaleDateString("en-CA");
  }, []);

  // Memoize department options
  const departmentOptions = useMemo(() => {
    if (deptlist && Array.isArray(deptlist)) {
      const mappedDept = deptlist.map(dep => ({
        label: dep.deptName,
        value: dep.deptName,
      }));
      return [{ label: "All", value: "" }, ...mappedDept];
    }
    return [{ label: "All", value: "" }];
  }, [deptlist]);

  useEffect(() => {
    setDept(departmentOptions);
  }, [departmentOptions]);

  const getDoctorsByShift = useCallback(async (date) => {
    try {
      showLoader();
      const token = localStorage.getItem("patienttoken");
      const formattedDate = formatDate(date);
      let url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/GetDoctorsByShift`;

      const res = await axiosInstance.get(url, {
        params: {
          date: formattedDate,
          type: 'GetDoctorShiftByDate'
        },
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      if (res.status === 200) {
        console.log(res.data)
        setDoctors(res.data);
        setFilteredDoctors(res.data);
      } else {
        showToast('error', 'Error!', 'Something went wrong');
      }
    } catch (error) {
      showToast('error', 'Error!', error?.message || 'Failed to fetch doctors');
    } finally {
      hideLoader();
    }
  }, [showLoader, hideLoader, showToast, formatDate]);

  // Load doctors for today on mount
  useEffect(() => {
    getDoctorsByShift(selectedDate);
  }, []);

  // Handle date selection
  const handleDateSelect = useCallback((date) => {
    if (date) {
      setSelectedDate(date);
      getDoctorsByShift(date);
    }
  }, [getDoctorsByShift]);

  // Combined filter effect
  useEffect(() => {
    let filtered = doctors;

    // Apply search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(doctor =>
        doctor.name.toLowerCase().includes(term) ||
        doctor.deptName.toLowerCase().includes(term)
      );
    }

    // Apply department filter
    if (filteredDept) {
      filtered = filtered.filter(doctor =>
        doctor.deptName.toLowerCase().includes(filteredDept.toLowerCase())
      );
    }

    setFilteredDoctors(filtered);
  }, [searchTerm, filteredDept, doctors]);

  const handleSearch = useCallback((e) => {
    setSearchTerm(e.target.value);
  }, []);

  const handleDeptChange = useCallback((value) => {
    setFilteredDept(value);
  }, []);

  const handleBookClick = (doctor) => {
    setSelectedDoctor(doctor);
    setIsDrawerOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="w-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left sidebar - Calendar */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h3 className="text-lg text-center font-semibold mb-4">Booking Appointment</h3>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                classNames={{
                  months: "flex flex-col space-y-4",
                  month: "space-y-4",
                  caption: "flex justify-center pt-1 relative items-center text-green-600",
                  head_row: "flex",
                  head_cell: "text-gray-500 font-medium text-sm w-13 text-center",
                  row: "flex w-full mt-2",
                  cell: "text-center p-0 relative focus-within:relative focus-within:z-20",
                  day: "h-12 w-13 p-0 font-normal aria-selected:opacity-100 rounded-full hover:bg-green-100",
                  day_selected:
                    "bg-green-500 text-white hover:bg-green-600 focus:bg-green-600 rounded-full",
                  day_today:
                    "bg-green-50 text-green-700 border border-green-500 font-bold rounded-full",
                  day_outside: "text-gray-300",
                  day_disabled: "text-gray-300 opacity-50 cursor-not-allowed",
                }}
              />

            </div>
          </div>

          {/* Right side - Doctor list */}
          <div className="lg:col-span-2">
            {/* Header */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                {/* Title */}
                <h2 className="text-xl font-semibold text-gray-900">Doctor List</h2>

                {/* Search + Filter */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
                  {/* Search input */}
                  <div className="relative flex-1 sm:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="Search doctor..."
                      value={searchTerm}
                      onChange={handleSearch}
                      className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>

                  {/* Department filter */}
                  <div className="sm:w-48">
                    <SearchableDD
                      options={dept}
                      value={filteredDept}
                      onChange={handleDeptChange}
                      placeholder="Filter by Dept"
                      className="w-full border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Doctor grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredDoctors.map((doctor) => (
                <DoctorCard key={doctor.doctorId} doctor={doctor} onBookClick={handleBookClick} />
              ))}
            </div>

            {/* No results message */}
            {filteredDoctors.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-500 mb-2">No doctors found</div>
                <div className="text-sm text-gray-400">
                  {searchTerm || filteredDept
                    ? "Try adjusting your search terms"
                    : "No doctors available for the selected date"}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <BookingDrawer
        isOpen={isDrawerOpen}
        onClose={() => {
          setIsDrawerOpen(false);
          setSelectedDoctor(null)
        }}
        doctor={selectedDoctor}
        dateparam={formatDate(selectedDate)}
      />
    </div>
  );
}