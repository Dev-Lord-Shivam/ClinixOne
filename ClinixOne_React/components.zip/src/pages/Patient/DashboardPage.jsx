import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, FileText, Pill, Wallet } from "lucide-react";

const DashboardPage = () => {

    const userInfo = JSON.parse(localStorage.getItem("patient"));

    const user = {
        patientId: userInfo.patientId,
        name: userInfo.fullName,
        role: "Patient",
        email: userInfo.email,
        avatar: userInfo.profilePic,
    };
    const patient = {
        name: "Shivam Jaiswal",
        age: 26,
        id: "PT-2025",
        avatar: "",
    };

    const upcomingAppointments = [
        { date: "25 Sep 2025", time: "10:00 AM", doctor: "Dr. Smith", type: "Dental Checkup" },
        { date: "29 Sep 2025", time: "02:00 PM", doctor: "Dr. Adams", type: "Eye Consultation" },
    ];

    const recentReports = [
        { title: "Blood Test", date: "20 Sep 2025" },
        { title: "X-Ray", date: "15 Sep 2025" },
    ];

    return (
        <div className="p-6 space-y-6">
            {/* Welcome Card */}
            <Card className="bg-gradient-to-r from-green-600 to-emerald-400 text-white shadow-lg rounded-2xl">
                <CardContent className="flex items-center justify-between p-6">
                    <div>
                        <h1 className="text-2xl font-bold">Welcome back, {user.name} 👋</h1>
                        <p className="text-sm opacity-90">Patient ID: {user.patientId} | Age: {patient.age}</p>
                    </div>
                    <Avatar className="h-16 w-16 border-2 border-white">
                        {user.avatar ? (
                            <AvatarImage src={user.avatar} />
                        ) : (
                            <AvatarFallback className="bg-green-700 text-white text-xl">
                                {patient.name.charAt(0)}
                            </AvatarFallback>
                        )}
                    </Avatar>
                </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-white shadow hover:shadow-md transition rounded-xl">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Appointments</CardTitle>
                        <Calendar className="h-5 w-5 text-green-600" />
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold text-green-700">4</p>
                        <p className="text-xs text-gray-500">Upcoming this month</p>
                    </CardContent>
                </Card>

                <Card className="bg-white shadow hover:shadow-md transition rounded-xl">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Reports</CardTitle>
                        <FileText className="h-5 w-5 text-green-600" />
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold text-green-700">8</p>
                        <p className="text-xs text-gray-500">Medical files</p>
                    </CardContent>
                </Card>

                <Card className="bg-white shadow hover:shadow-md transition rounded-xl">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Prescriptions</CardTitle>
                        <Pill className="h-5 w-5 text-green-600" />
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold text-green-700">3</p>
                        <p className="text-xs text-gray-500">Active meds</p>
                    </CardContent>
                </Card>

                <Card className="bg-white shadow hover:shadow-md transition rounded-xl">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Bills</CardTitle>
                        <Wallet className="h-5 w-5 text-green-600" />
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold text-green-700">₹ 2,500</p>
                        <p className="text-xs text-gray-500">Pending payments</p>
                    </CardContent>
                </Card>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Upcoming Appointments */}
                <Card className="shadow rounded-xl">
                    <CardHeader>
                        <CardTitle className="text-lg font-semibold text-green-700">Upcoming Appointments</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-3">
                            {upcomingAppointments.map((appt, i) => (
                                <li
                                    key={i}
                                    className="flex justify-between items-center p-3 rounded-lg bg-green-50 hover:bg-green-100 transition"
                                >
                                    <div>
                                        <p className="font-medium text-green-800">{appt.type}</p>
                                        <p className="text-sm text-gray-600">
                                            {appt.date} | {appt.time} with {appt.doctor}
                                        </p>
                                    </div>
                                    <Button variant="outline" className="border-green-600 text-green-600">
                                        View
                                    </Button>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>

                {/* Recent Reports */}
                <Card className="shadow rounded-xl">
                    <CardHeader>
                        <CardTitle className="text-lg font-semibold text-green-700">Recent Reports</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-3">
                            {recentReports.map((report, i) => (
                                <li
                                    key={i}
                                    className="flex justify-between items-center p-3 rounded-lg bg-white shadow-sm hover:shadow-md transition"
                                >
                                    <div>
                                        <p className="font-medium">{report.title}</p>
                                        <p className="text-sm text-gray-500">Uploaded on {report.date}</p>
                                    </div>
                                    <Button variant="outline" className="border-green-600 text-green-600">
                                        Download
                                    </Button>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            </div>

        </div>
    );
};

export default DashboardPage;
