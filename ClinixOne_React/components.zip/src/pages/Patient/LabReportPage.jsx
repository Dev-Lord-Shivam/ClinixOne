import { BookPlus, Download, Eye, Upload } from 'lucide-react';
import { useEffect, useState } from 'react';
import axiosInstance from "../../Context/axiosInstance";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import { DataTable } from "../../components/custom/DataTable";
import PdfDialogueReader from "../../components/custom/PdfDialogueReader";
import SearchableDD from "../../components/custom/SearchableDD";

const LabReportPage = () => {
    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast();
    const baseUrl = `${import.meta.env.VITE_API_BASE_URL}`;
    const userInfo = JSON.parse(localStorage.getItem("patient"));
    const token = localStorage.getItem("token");
    const [testList, setTestList] = useState([]);
    const [allTests, setAllTests] = useState([]);
    const [selectedStatus, setSelectedStatus] = useState('All')
    const [openPdf, setOpenPdf] = useState(false);
    const [selectedPdf, setSelectedPdf] = useState(null);

    const statusDD = [
        { label: 'All', value: 'All' },
        { label: 'Schedule', value: 'Schedule' },
        { label: 'Pending', value: 'Pending' },
        { label: 'Completed', value: 'Completed' },
        { label: 'Cancelled', value: 'Cancelled' },
        { label: 'File Deleted', value: 'File Deleted' },
    ]

    const columns = [
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const patient = row.original;
                return (
                    <div className="flex items-center gap-2">
                        {(patient.status === 'Completed' && (
                            <>
                                <button
                                    onClick={() => {
                                        setSelectedPdf(patient.fileBase64);
                                        setOpenPdf(true);
                                    }}
                                    className="p-2 rounded-full bg-yellow-400 text-black hover:bg-white cursor-pointer">
                                    <Eye size={16} />
                                </button>
                                <button
                                    onClick={() => downloadBase64Pdf(patient.fileBase64, patient.fileName)}
                                    className="p-2 rounded-full bg-green-400 text-black hover:bg-white cursor-pointer">
                                    <Download size={16} />
                                </button>
                            </>
                        ))}
                    </div>
                );
            },
        },
        { accessorKey: "testName", header: "Test Name" },
        { accessorKey: "createdAt", header: "Date" },
        { accessorKey: "testId", header: "testId", hidden: true },
        { accessorKey: "scheduleId", header: "scheduleId", hidden: true },
        { accessorKey: "createdBy", header: "Doctor", hidden: true },
        { accessorKey: "categoryName", header: "Category" },
        { accessorKey: "mrp", header: "MRP (₹)" },
        { accessorKey: "fileBase64", header: "FileBase64", hidden: true },
        { accessorKey: "fileName", header: "FileName", hidden: true },
        {
            accessorKey: "status",
            header: "Status",
            cell: ({ row }) => {
                const status = row.original.status;
                let color = "";

                switch (status) {
                    case "Schedule":
                        color = "bg-purple-200 text-purple-700";
                        break;
                    case "Pending":
                        color = "bg-red-100 text-red-700";
                        break;
                    case "Completed":
                        color = "bg-green-200 text-green-700";
                        break;
                    case "Cancelled":
                        color = "bg-red-700 text-white";
                        break;
                    case "File Deleted":
                        color = "bg-pink-700 text-white";
                        break;
                    default:
                        color = "bg-gray-100 text-gray-700";
                }

                return (
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>
                        {status.replace("_", " ")}
                    </span>
                );
            },
        },
    ];

    // Fetch when patient changes
    useEffect(() => {
        if (userInfo.patientId) {
            fetchTestByPatient();
        } else {
            setTestList([]);
        }
    }, [userInfo.patientId]);

    const fetchTestByPatient = async () => {
        try {
            showLoader();
            let url = `${baseUrl}/api/Hospital/GetTestHistory?patientId=${userInfo.patientId}&Type=PatientTestHistory`;

            let res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            });

            if (res.status === 200 && res.data.length > 0) {
                setAllTests(res.data);   // keep original
                setTestList(res.data);   // display filtered
            } else {
                setAllTests([]);
                setTestList([]);
            }

        } catch (error) {
            showToast('error', 'Error!', error.message || 'Internal Server Error');
        } finally {
            hideLoader();
        }
    };

    useEffect(() => {
        if (selectedStatus === "" || selectedStatus === "All") {
            setTestList(allTests);
        } else {
            setTestList(allTests.filter(m => m.status === selectedStatus));
        }
    }, [selectedStatus, allTests]);

    const downloadBase64Pdf = (base64, fileName = "report.pdf") => {
        const link = document.createElement("a");
        link.href = `data:application/pdf;base64,${base64}`;
        link.download = fileName;
        link.click();
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8 flex justify-between items-center w-full">
                    <div className="flex items-center gap-3 mb-2 w-5/6">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
                            <BookPlus className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">My Test Reports</h1>
                            <p className="text-gray-600">Manage your lab test reports</p>
                        </div>
                    </div>
                    <div className='w-1/5'>
                        <div className="flex">
                            <SearchableDD
                                options={statusDD}
                                label="Select Status"
                                value={selectedStatus}
                                onChange={(val) =>
                                    setSelectedStatus(val)
                                }
                                className="w-full !bg-blue-200"
                                placeholder="Select Status"
                            />
                        </div>
                    </div>
                </div>

                <div className='mt-4'>
                    <DataTable
                        columns={columns}
                        data={testList}
                        pageSize={50}
                        headerBgColor="bg-green-700"
                        headerTextColor="text-white"
                    />
                </div>
            </div>

            <PdfDialogueReader
                open={openPdf}
                onClose={() => setOpenPdf(false)}
                base64Pdf={selectedPdf}
                title="Patient Report"
            />
        </div>
    )
}

export default LabReportPage
