import React, { useEffect, useState } from 'react';
import { Calendar, Clock, MapPin, User, FileText, CheckCircle2, XCircle, AlertCircle, Activity, Pencil } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import axiosInstance from '../../Context/axiosInstance';
import { useLoader } from '../../Context/LoaderProvider';
import useShowToast from '../../Context/useShowToast';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { motion } from "framer-motion";
import { DataTable } from '../../components/custom/DataTable';
import CancelAptDialog from '../../components/custom/CancelAptDialog';
import RescheduleApt from '../../components/custom/RescheduleApt';

const AppointmentCard = ({ appointment, isOpen, setIsOpen, setUpcomingApt, setPastApt }) => {
    const showToast = useShowToast();
    const { showLoader, hideLoader } = useLoader();
    const [openResModel, setOpenResModel] = useState(false)
    const getStatusColor = (status) => {
        switch (status) {
            case "completed":
                return "bg-green-50 text-green-700 border-green-200";
            case "cancelled":
                return "bg-red-50 text-red-700 border-red-200";
            case "confirmed":
                return "bg-blue-50 text-blue-700 border-blue-200";
            case "pending":
                return "bg-yellow-50 text-yellow-700 border-yellow-200";
            default:
                return "bg-gray-50 text-gray-700 border-gray-200";
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case "completed":
                return <CheckCircle2 className="w-4 h-4" />;
            case "cancelled":
                return <XCircle className="w-4 h-4" />;
            default:
                return <AlertCircle className="w-4 h-4" />;
        }
    };

    const handleDownloadLetter = async (appointmentId) => {
        try {
            showLoader();
            const token = localStorage.getItem("patienttoken");
            const response = await axiosInstance.get(
                `${import.meta.env.VITE_API_BASE_URL}/api/patient/DnldAptLetters?aptid=${appointmentId}`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    responseType: "blob", // 👈 Important to handle binary data
                }
            );

            // Create blob URL for the PDF file
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement("a");
            link.href = url;
            link.setAttribute("download", `Appointment_Letter_${appointmentId}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            console.error("Error downloading appointment letter:", error);
            showToast('error', 'error!', error.message || 'Internal server error')
        } finally {
            hideLoader();
        }
    };

    return (
        <motion.div
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
        >
            <Card className={`bg-gradient-to-br from-blue-200 via-indigo-200 to-teal-100
                              border border-gray-100 shadow-sm hover:shadow-md rounded-2xl 
                              transition-all overflow-hidden`}>
                <CardContent className="p-4 sm:p-4">
                    {/* Header Section */}
                    <div className="flex items-start justify-between mb-5">
                        <div className="flex items-start gap-4">
                            <Avatar className="w-14 h-14 border shadow-inner">
                                <AvatarImage src={appointment.profilePic} alt={appointment.doctorName} />
                                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-lg font-semibold">
                                    {appointment.doctorName?.charAt(0)}
                                </AvatarFallback>
                            </Avatar>
                            <div>
                                <h3 className="font-semibold text-lg text-gray-900">{appointment.doctorName}</h3>
                                <p className="text-sm text-gray-500">{appointment.deptName}</p>
                            </div>
                        </div>

                        <Badge className={`${getStatusColor(appointment.aptStatus)} flex items-center gap-1 px-2 py-1 text-xs rounded-md`}>
                            {getStatusIcon(appointment.aptStatus)}
                            <span className="capitalize">{appointment.aptStatus}</span>
                        </Badge>
                    </div>

                    {/* Info Section */}
                    <div className="space-y-3 text-sm">
                        <div className="flex items-center gap-2 text-gray-700">
                            <Calendar className="w-4 h-4 text-blue-600" />
                            <span className="font-medium">{appointment.aptDate}</span>
                        </div>

                        <div className="flex items-center gap-2 text-gray-700">
                            <Clock className="w-4 h-4 text-blue-600" />
                            <span>{appointment.slotStart} - {appointment.slotEnd}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                            <Activity className="w-4 h-4 text-blue-600" />
                            <span>{appointment.deptName}</span>
                        </div>
                        <div className="flex items-start gap-2 text-gray-700">
                            <MapPin className="w-4 h-4 text-blue-600 mt-0.5" />
                            <span>{appointment.locationName}</span>
                        </div>
                    </div>
                    <div className="mt-5 flex flex-col sm:flex-row sm:items-center sm:justify-end gap-2">
                        <button onClick={() => handleDownloadLetter(appointment.aptId)}
                            className="cursor-pointer flex items-center justify-center gap-1 px-4 py-2 text-xs 
                                               font-medium text-white rounded-xs bg-gradient-to-r from-blue-600 to-purple-600 
                                               hover:from-blue-700 hover:to-purple-700 transition-all">
                            <FileText className="w-4 h-4" /> Appointment Letter
                        </button>
                        <button onClick={() => setOpenResModel(true)}
                            className="cursor-pointer px-4 py-2 text-xs font-medium text-white bg-amber-600 rounded-xs hover:bg-amber-700 transition-all">
                            Reschedule
                        </button>
                        <button className="cursor-pointer px-4 py-2 text-xs font-medium text-white bg-red-600 rounded-xs hover:bg-red-700 transition-all"
                            onClick={() => setIsOpen(true)}
                        >
                            Cancel
                        </button>
                    </div>
                </CardContent>
            </Card>
            <CancelAptDialog
                isOpen={isOpen}
                onClose={setIsOpen}
                aptId={appointment.aptId}
                showToast={showToast}
                setUpcomingApt={setUpcomingApt}
                setPastApt={setPastApt}
            />
            {openResModel &&
                <RescheduleApt
                    isOpen={openResModel}
                    onClose={setOpenResModel}
                    appointment={appointment}
                    setUpcomingApt={setUpcomingApt}
                />
            }
        </motion.div>
    );
};

export default function MyAppointments() {

    const userInfo = JSON.parse(localStorage.getItem("patient"));
    const token = localStorage.getItem("patienttoken");
    const [activeTab, setActiveTab] = useState('upcoming');
    const { showLoader, hideLoader } = useLoader();
    const showToast = useShowToast()
    const [upcomingApt, setUpcomingApt] = useState([]);
    const [pastApt, setPastApt] = useState([]);
    const [isOpen, setIsOpen] = useState(false)

    const colModule = [
        {
            accessorKey: "action",
            header: "Action",
            enableColumnFilter: false,
            size: 100,
            cell: ({ row }) => {
                const empId = row.original.empId;
                return (
                    <button
                        onClick={() => handleEdit(empId)}
                        className="text-white p-2 rounded-full cursor-pointer bg-green-500 hover:text-green-500 hover:bg-white"
                    >
                        <Pencil size={18} />
                    </button>
                );
            }
        },
        {
            accessorKey: "profilePic",
            header: "Profile",
            enableColumnFilter: false,
            size: 30,
            cell: ({ row }) => (
                <Avatar className="h-10 w-10 border-2 border-green-500">
                    <AvatarImage src={row.original.profilePic} alt={row.original.profilePic} />
                    <AvatarFallback>{row.original.doctorName?.charAt(0)}</AvatarFallback>
                </Avatar>
            )
        },
        { accessorKey: "aptId", header: "aptid", size: 50, hidden: true },
        { accessorKey: "doctorName", header: "Doctor" },
        { accessorKey: "deptName", header: "Clinic", size: 100 },
        { accessorKey: "aptDate", header: "Date", size: 100 },
        { accessorKey: "slotStart", header: "Reporting Time" },
        { accessorKey: "clinicName", header: "Clinic" },
        { accessorKey: "locationName", header: "Location" },
        {
            accessorKey: "aptStatus",
            header: "Status",
            cell: ({ row }) => {
                const status = row.getValue("aptStatus");

                const getBadgeStyle = (status) => {
                    switch (status) {
                        case "Confirm":
                            return "bg-blue-100 text-blue-800 border border-blue-200";
                        case "Pending":
                            return "bg-yellow-100 text-yellow-800 border border-yellow-200";
                        case "Cancelled":
                            return "bg-red-100 text-red-800 border border-red-200";
                        case "Rescheduled":
                            return "bg-purple-100 text-purple-800 border border-purple-200";
                        case "Checked In":
                            return "bg-indigo-100 text-indigo-800 border border-indigo-200";
                        case "Completed":
                            return "bg-green-100 text-green-800 border border-green-200";
                        case "Not Visited":
                            return "bg-red-100 text-red-800 border border-red-200";
                        default:
                            return "bg-gray-50 text-gray-700 border border-gray-100";
                    }
                };

                return (
                    <Badge
                        className={`${getBadgeStyle(status)} text-xs px-2 py-1 rounded-md font-medium`}
                    >
                        {status}
                    </Badge>
                );
            },
        }


    ];

    useEffect(() => {
        fetUpcomingApt();
    }, [])

    const fetUpcomingApt = async () => {
        try {
            showLoader()
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/GetAppointment`;
            const res = await axiosInstance.get(url, {
                params: {
                    PatientId: userInfo?.patientId,
                    type: 'GetUpcomingAppointment'
                },
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            })
            if (res.status === 200 && res.data.length > 0) {
                setUpcomingApt(res.data)
            }

            const pstApt = await axiosInstance.get(`${import.meta.env.VITE_API_BASE_URL}/api/Patient/GetAppointment`, {
                params: {
                    PatientId: userInfo?.patientId,
                    type: 'GetAppointmentHistory'
                },
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            })

            if (pstApt.status === 200 && pstApt.data.length > 0) {
                setPastApt(pstApt.data)
            }

        } catch (error) {
            showToast('error', 'error!', error.message || 'Internal Server Error')
        } finally {
            hideLoader()
        }
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
                            <User className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">My Appointments</h1>
                            <p className="text-gray-600">Manage your healthcare schedule</p>
                        </div>
                    </div>
                </div>

                {/* Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <TabsList className="grid w-full max-w-sm grid-cols-2 h-8 mb-8 bg-green-400">
                        <TabsTrigger value="upcoming" className="text-xs">
                            Upcoming ({upcomingApt.length})
                        </TabsTrigger>
                        <TabsTrigger value="past" className="text-xs">
                            Past ({pastApt.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="upcoming" className="space-y-6">
                        {upcomingApt.length > 0 ? (
                            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
                                {upcomingApt.map((appointment) => (
                                    <AppointmentCard
                                        key={appointment.aptId}
                                        appointment={appointment}
                                        isOpen={isOpen}
                                        setIsOpen={setIsOpen}
                                        setUpcomingApt={setUpcomingApt}
                                        setPastApt={setPastApt}
                                    />
                                ))}
                            </div>
                        ) : (
                            <Card className="text-center py-12">
                                <CardContent>
                                    <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Upcoming Appointments</h3>
                                    <p className="text-gray-600">You don't have any scheduled appointments</p>
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>

                    <TabsContent value="past" className="space-y-6">
                        {pastApt.length > 0 ? (
                            <div>
                                <DataTable
                                    columns={colModule}
                                    data={pastApt}
                                    pageSize={5}
                                    headerBgColor="bg-green-800"
                                    headerTextColor="text-white"
                                />
                            </div>
                        ) : (
                            <Card className="text-center py-12">
                                <CardContent>
                                    <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Past Appointments</h3>
                                    <p className="text-gray-600">Your appointment history will appear here</p>
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>
                </Tabs>
            </div>

        </div>
    );
}