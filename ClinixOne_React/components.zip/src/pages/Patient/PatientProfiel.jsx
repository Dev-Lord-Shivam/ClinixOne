import { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, X, MapPin, Phone, Shield, AlertCircle, User, Edit, Save, Eye, EyeOff } from "lucide-react";
import CustomDatePicker from "../../components/custom/CustomDatePicker";
import { useLoader } from "../../Context/LoaderProvider";
import useShowToast from "../../Context/useShowToast";
import axiosInstance from "../../Context/axiosInstance";
import { useCustomAlert } from "../../Context/CustomAlertProvider";

const genderOptions = ["Male", "Female", "Other", "Prefer not to say"];
const maritalStatusOptions = ["Single", "Married", "Divorced", "Widowed", "Separated"];
const bloodGroupOptions = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const religionOptions = [
    "Christianity", "Islam", "Hinduism", "Buddhism", "Judaism", "Sikhism",
    "Jainism", "Zoroastrianism", "Bahá'í Faith", "Atheism", "Agnosticism", "Other"
];
const SearchableSelect = ({ options, value, onValueChange, placeholder, className }) => {
    const [searchTerm, setSearchTerm] = useState("");
    const [isOpen, setIsOpen] = useState(false);

    const filteredOptions = options.filter(option =>
        (typeof option === 'string' ? option : option.label)
            .toLowerCase()
            .includes(searchTerm.toLowerCase())
    );

    return (
        <div className="relative">
            <Select value={value} onValueChange={onValueChange} open={isOpen} onOpenChange={setIsOpen}>
                <SelectTrigger className={className}>
                    <SelectValue placeholder={placeholder} />
                </SelectTrigger>
                <SelectContent>
                    <div className="p-2">
                        <Input
                            placeholder="Search..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="h-8"
                        />
                    </div>
                    <div className="max-h-60 overflow-auto">
                        {filteredOptions.map((option) => {
                            const optionValue = typeof option === 'string' ? option : option.value;
                            const optionLabel = typeof option === 'string' ? option : option.label;
                            return (
                                <SelectItem key={optionValue} value={optionValue}>
                                    {optionLabel}
                                </SelectItem>
                            );
                        })}
                        {filteredOptions.length === 0 && (
                            <div className="p-2 text-sm text-gray-500 text-center">No results found</div>
                        )}
                    </div>
                </SelectContent>
            </Select>
        </div>
    );
};

export default function PatientProfile() {
    const [formData, setFormData] = useState({
        Nationality: "Indian"
    });

    const [patientData, setPatientData] = useState({});
    const [showPatientDialog, setShowPatientDialog] = useState(false);
    const [errors, setErrors] = useState({});
    const [isEditing, setIsEditing] = useState(false)
    const { showLoader, hideLoader } = useLoader()
    const showToast = useShowToast();
    const [countryList, setCountryList] = useState([]);
    const [stateList, setStateList] = useState([]);
    const [cityList, setCityList] = useState([]);
    const [showPassword, setShowPassword] = useState(false)
    const alert = useCustomAlert()
    const token = localStorage.getItem("patienttoken");
    const userInfo = JSON.parse(localStorage.getItem("patient"));

    useEffect(() => {
        getCountryStateCity('Get_CountryDD');
    }, [])

    const getCountryStateCity = async (Type, countryId = null, stateId = null) => {
        try {
            showLoader();
            let url = '';

            if (Type === 'Get_CountryDD') {
                url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=Get_CountryDD`;
                const res = await axiosInstance.get(url);
                if (res.status === 200 && res.data) {
                    setCountryList(res.data.map(item => ({
                        label: item.text,
                        value: item.value.toString()
                    })));
                }

                await getPatientProfile();
            }

            if (Type === 'Get_StateDDById') {
                url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=${Type}&Id=${countryId}`;
                const res = await axiosInstance.get(url);
                if (res.status === 200 && res.data) {
                    setStateList(res.data.map(item => ({
                        label: item.text,
                        value: item.value.toString()
                    })));
                }
            }

            if (Type === 'Get_CityByStateId') {
                url = `${import.meta.env.VITE_API_BASE_URL}/api/Master/GetCountryStateCity?Type=${Type}&Id=${stateId}&Id2=${countryId}`;
                const res = await axiosInstance.get(url);
                if (res.status === 200 && res.data) {
                    setCityList(res.data.map(item => ({
                        label: item.text,
                        value: item.value.toString()
                    })));
                }
            }

        } catch (error) {
            console.error("API error:", error);
        } finally {
            hideLoader();
        }
    };

    const getPatientProfile = async () => {
        try {
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/GetPatientById?PatientId=${userInfo.patientId}`;
            const res = await axiosInstance.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
            });
            if (res.status === 200) {
                console.log(res.data);
                await getCountryStateCity('Get_StateDDById', res.data.countryId)
                await getCountryStateCity('Get_CityByStateId', res.data.countryId, res.data.stateId)
                setPatientData(res.data);
            }
            else {
                showToast('error', 'error!', res.error || 'something went wrong');
            }
        } catch (error) {
            showToast('error', 'error!', error.message || 'Internal Server Error');
        }
    }

    const handleChange = (field, value) => {
        // setFormData((prev) => ({ ...prev, [field]: value }));
        setPatientData((prev) => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }));
        }
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            // Validate file size (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
                alert({ title: 'alert', description: "File size must be less than 5MB" });
                return;
            }

            // Validate file type
            if (!file.type.startsWith('image/')) {
                alert({ title: 'alert', description: "Please select a valid image file" });
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setPatientData((prev) => ({
                    ...prev,
                    profilePic: reader.result
                }));
            };
            reader.readAsDataURL(file);
        }
    };

    const validateForm = () => {
        const newErrors = {};
        const requiredFields = [
            'fullName', 'gender', 'dob', 'maritalStatus', 'religion', 'bloodGroup',
            'street', 'countryId', 'stateId', 'city', 'pincode', 'mobNumber', 'email', 'password'
        ];

        requiredFields.forEach(field => {
            console.log(patientData[field])
            if (!patientData[field]) {
                newErrors[field] = 'This field is required';
            }
        });

        // Email validation
        if (patientData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(patientData.email)) {
            newErrors.email = 'Please enter a valid email address';
        }

        // Mobile number validation
        if (patientData.mobNumber && !/^\d{10}$/.test(patientData.mobNumber)) {
            newErrors.mobNumber = 'Please enter a valid 10-digit mobile number';
        }

        // Pincode validation
        if (patientData.pincode && !/^\d{6}$/.test(patientData.pincode)) {
            newErrors.pincode = 'Please enter a valid 6-digit pincode';
        }
        console.log(newErrors)
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {

        if (!validateForm()) {
            // Scroll to first error
            const firstError = document.querySelector('.border-red-500');
            console.log(firstError)
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            return;
        }

        try {
            showLoader();
            const url = `${import.meta.env.VITE_API_BASE_URL}/api/Patient/RegisterPatient`
            const response = await axiosInstance.post(url, patientData);
            if (response.status == 200) {
                if (response.data.msg_code == "2") {

                    window.scrollTo({ top: 0, behavior: "smooth" });
                    setTimeout(() => setShowPatientDialog(true), 800);
                    showToast("success", "Success!", "Profile updated successfully.")
                }
                else {
                    if (response.data.msg_code == "3") {
                        showToast("error", "Error!", `${response.data.message}`)
                    }
                }
            }

        } catch (error) {
            showToast("error", "Error!", "Server Error")
        } finally {
            hideLoader()
        }
    };

    const removeProfilePic = () => {
        console.log(patientData)
        setPatientData(prev => ({
            ...prev,
            profilePic: null
        }));
    };

    return (
        <div className="min-h-screen p-4">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-gray-800 mb-2">Patient Profile</h1>
                    <p className="text-gray-600">Keep your profile updated, as this helps us provide faster, safer, and more personalized care during your visits.</p>
                </div>

                <div className="flex justify-end mb-2">
                    {!isEditing ? (
                        <Button
                            type="button"
                            onClick={() => setIsEditing(true)}
                            className="bg-green-800 text-sm p-1 hover:bg-blue-700 text-white rounded-xs cursor-pointer"
                        >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit Profile
                        </Button>
                    ) : (
                        <div className="flex gap-2">
                            <Button
                                type="button"
                                variant="outline"
                                className="rounded-xs"
                                onClick={() => {
                                    setIsEditing(false);
                                    setFormData({ Nationality: "Indian" });
                                    setErrors({});
                                }}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="button"
                                onClick={handleSubmit}
                                className="bg-green-600 hover:bg-green-700 text-white rounded-xs"
                            >
                                <Save className="w-4 h-4 mr-2" />
                                Save Changes
                            </Button>
                        </div>
                    )}
                </div>
                <div className="space-y-8">
                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                        {/* Profile Picture Section */}
                        <div className="lg:col-span-1">
                            <Card className="h-fit">
                                <CardHeader className="text-center pb-4">
                                    <CardTitle className="flex items-center justify-center gap-2 text-lg">
                                        <User className="w-5 h-5" />
                                        Profile Photo
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="text-center space-y-4">
                                    <div className="relative group">
                                        <div className="w-32 h-32 mx-auto rounded-full border-4 border-gray-200 overflow-hidden bg-gray-100">
                                            {patientData.profilePic ? (
                                                <>
                                                    <img
                                                        src={patientData.profilePic}
                                                        alt="Profile"
                                                        className="w-full h-full object-cover"
                                                    />
                                                    {isEditing &&
                                                        <button
                                                            type="button"
                                                            onClick={removeProfilePic}
                                                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                                        >
                                                            <X className="w-4 h-4" />
                                                        </button>
                                                    }
                                                </>
                                            ) : (
                                                <div className="flex items-center justify-center h-full">
                                                    <User className="w-12 h-12 text-gray-400" />
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={handleFileChange}
                                        className="hidden"
                                        id="profileImage"
                                    />

                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => document.getElementById("profileImage").click()}
                                        className="w-full"
                                        disabled={!isEditing}
                                    >
                                        <Upload className="w-4 h-4 mr-2" />
                                        Upload Photo
                                    </Button>

                                    <p className="text-xs text-gray-500">
                                        Max size: 5MB. Supported formats: JPG, PNG, GIF
                                    </p>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Form Fields */}
                        <div className="lg:col-span-3 space-y-6">
                            {/* Personal Information */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <User className="w-5 h-5" />
                                        Personal Information
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                                        <div className="space-y-2">
                                            <Label>Full Name <span className="text-red-500">*</span></Label>
                                            <Input
                                                value={patientData.fullName || ""}
                                                onChange={(e) => handleChange("fullName", e.target.value)}
                                                className={`border-red-500 form-control ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                                placeholder="Enter your full name"
                                            />
                                            {errors.fullName && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.fullName}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Gender <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={genderOptions}
                                                value={patientData.gender || ""}
                                                onValueChange={(val) => handleChange("gender", val)}
                                                placeholder="Select gender"
                                                readOnly
                                                className={`border-red-500 w-full form-control ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.Gender && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.gender}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Date of Birth <span className="text-red-500">*</span></Label>
                                            <CustomDatePicker
                                                selected={patientData.dob}
                                                className={`form-control ${!isEditing ? '!bg-gray-300' : ''}`}
                                                onChange={(date) => handleChange("dob", date)}
                                                disableFuture={true} // disables dates after today,
                                                disabled={!isEditing ? true : false}
                                            />
                                            {errors.DOB && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.DOB}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Nationality</Label>
                                            <Input
                                                value={patientData.nationality || ""}
                                                onChange={(e) => handleChange("nationality", e.target.value)}
                                                placeholder="Enter nationality"
                                                className={`form-control ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Marital Status <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={maritalStatusOptions}
                                                value={patientData.maritalStatus || ""}
                                                onValueChange={(val) => handleChange("maritalStatus", val)}
                                                placeholder="Select marital status"
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.MaritalStatus && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.maritalStatus}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Religion <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={religionOptions}
                                                value={patientData.religion || ""}
                                                onValueChange={(val) => handleChange("religion", val)}
                                                placeholder="Select religion"
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.Religion && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.religion}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Occupation</Label>
                                            <Input
                                                value={patientData.occupation || ""}
                                                onChange={(e) => handleChange("occupation", e.target.value)}
                                                placeholder="Enter occupation"
                                                className={`form-control ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Blood Group <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={bloodGroupOptions}
                                                value={patientData.bloodGroup || ""}
                                                onValueChange={(val) => handleChange("bloodGroup", val)}
                                                placeholder="Select blood group"
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.BloodGroup && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.bloodGroup}
                                                </p>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Address Information */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <MapPin className="w-5 h-5" />
                                        Address Information
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                                        <div className="md:col-span-2 xl:col-span-3 space-y-2">
                                            <Label>Street Address <span className="text-red-500">*</span></Label>
                                            <Input
                                                value={patientData.street || ""}
                                                onChange={(e) => handleChange("street", e.target.value)}
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                                placeholder="Enter complete street address"
                                            />
                                            {errors.Street && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.street}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Country <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={countryList}
                                                value={patientData.countryId || ""}
                                                onValueChange={(val) => {
                                                    handleChange("countryId", val);
                                                    handleChange("stateId", "");
                                                    getCountryStateCity('Get_StateDDById', val)
                                                }}
                                                placeholder="Select country"
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.CountryId && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.countryId}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>State/Province <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={stateList}
                                                value={patientData.stateId || ""}
                                                onValueChange={(val) => {
                                                    handleChange("stateId", val)
                                                    getCountryStateCity('Get_CityByStateId', formData.CountryId, val)
                                                }}
                                                placeholder="Select state"
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.stateId && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.stateId}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>City/Town <span className="text-red-500">*</span></Label>
                                            <SearchableSelect
                                                options={cityList}
                                                value={patientData.city || ""}
                                                onValueChange={(val) => {
                                                    handleChange("city", val)
                                                }}
                                                placeholder="Select city/town"
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                            />
                                            {errors.city && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.city}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Pincode/ZIP <span className="text-red-500">*</span></Label>
                                            <Input
                                                value={patientData.pincode || ""}
                                                onChange={(e) => handleChange("pincode", e.target.value)}
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                                placeholder="Enter pincode"
                                            />
                                            {errors.pincode && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.pincode}
                                                </p>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Contact Information */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Phone className="w-5 h-5" />
                                        Contact Information
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>Mobile Number <span className="text-red-500">*</span></Label>
                                            <Input
                                                type="tel"
                                                value={patientData.mobNumber || ""}
                                                onChange={(e) => handleChange("mobNumber", e.target.value)}
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                                placeholder="Enter 10-digit mobile number"
                                                maxLength={10}
                                            />
                                            {errors.mobNumber && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.mobNumber}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2">
                                            <Label>Email Address <span className="text-red-500">*</span></Label>
                                            <Input
                                                type="email"
                                                value={patientData.email || ""}
                                                onChange={(e) => handleChange("email", e.target.value)}
                                                className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                                placeholder="Enter email address"
                                            />
                                            {errors.email && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.email}
                                                </p>
                                            )}
                                        </div>

                                        <div className="space-y-2 md:col-span-2">
                                            <Label>Password <span className="text-red-500">*</span></Label>
                                            <div className="relative">
                                                <Input
                                                    type={showPassword ? "text" : "password"}
                                                    value={patientData.password}
                                                    onChange={(e) => handleChange("password", e.target.value)}
                                                    className={`form-control w-full ${!isEditing ? 'readonly bg-gray-300' : ''}`}
                                                    placeholder="Enter password"
                                                />
                                                <button
                                                    type="button"
                                                    onClick={() => setShowPassword(!showPassword)}
                                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                                    disabled={!isEditing}
                                                >
                                                    {showPassword ? (
                                                        <EyeOff className="w-4 h-4" />
                                                    ) : (
                                                        <Eye className="w-4 h-4" />
                                                    )}
                                                </button>
                                            </div>
                                            {errors.password && (
                                                <p className="text-xs text-red-500 flex items-center gap-1">
                                                    <AlertCircle className="w-3 h-3" />
                                                    {errors.password}
                                                </p>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    );
}